// ! Bu araç @keyiflerolsun tarafından | @KekikAkademi için yazılmıştır.
package @@PKG@@
class HDStreamAble : PeaceMakerst() {
    override var name    = "HDStreamAble"
    override var mainUrl = "https://hdstreamable.com"
}
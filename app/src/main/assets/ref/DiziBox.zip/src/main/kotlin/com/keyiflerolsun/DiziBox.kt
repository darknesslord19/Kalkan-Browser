package com.keyiflerolsun

import android.util.Base64
import com.fasterxml.jackson.annotation.JsonProperty
import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.LoadResponse.Companion.addActors
import com.lagradost.cloudstream3.LoadResponse.Companion.addTrailer
import com.lagradost.cloudstream3.network.CloudflareKiller
import com.lagradost.cloudstream3.utils.*
import com.lagradost.cloudstream3.utils.AppUtils.tryParseJson
import com.lagradost.cloudstream3.utils.StringUtils.decodeUri
import okhttp3.Interceptor
import okhttp3.Response
import org.jsoup.Jsoup
import org.jsoup.nodes.Element

class DiziBox : MainAPI() {
    override var mainUrl              = "https://www.dizibox.live"
    override var name                 = "DiziBox"
    override val hasMainPage          = true
    override var lang                 = "tr"
    override val hasQuickSearch       = true
    override val supportedTypes       = setOf(TvType.TvSeries)

    override var sequentialMainPage            = true
    override var sequentialMainPageDelay       = 200L
    override var sequentialMainPageScrollDelay = 50L

    private val baseCookies = mapOf(
        "LockUser"      to "true",
        "isTrustedUser" to "true",
        "dbxu"          to "1744054959089"
    )

    companion object {
        private const val USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }

    private val baseHeaders = mapOf(
        "User-Agent" to USER_AGENT,
        "Referer"    to "$mainUrl/"
    )

    private val cloudflareKiller by lazy { CloudflareKiller() }
    private val interceptor      by lazy { CloudflareInterceptor(cloudflareKiller) }

    class CloudflareInterceptor(private val cloudflareKiller: CloudflareKiller) : Interceptor {
        override fun intercept(chain: Interceptor.Chain): Response {
            val request = chain.request().newBuilder()
                .header("User-Agent", USER_AGENT)
                .build()
            
            val response   = chain.proceed(request)
            val bodySample = response.peekBody(1024 * 1024).string()
            if (
                bodySample.contains("Güvenlik taramasından geçiriliyorsunuz")
                || bodySample.contains("cf-browser-verification")
                || bodySample.contains("Checking your browser")
                || bodySample.contains("just a moment", ignoreCase = true)
                || bodySample.contains("DDoS protection by Cloudflare")
            ) {
                response.close()
                return cloudflareKiller.intercept(chain)
            }
            return response
        }
    }

    override val mainPage = mainPageOf(
        "${mainUrl}/tum-bolumler/page/SAYFA/"                        to "Son Bölümler",
        "${mainUrl}/tum-bolumler/page/SAYFA/?tip=populer"            to "Popüler Diziler",
        "${mainUrl}/dizi-arsivi/page/SAYFA/"                         to "Yeni Eklenenler",
        "${mainUrl}/dizi-arsivi/page/SAYFA/?ulke[]=turkiye&yil=&imdb" to "Yerli Diziler",
        "${mainUrl}/dizi-arsivi/page/SAYFA/?tur[0]=aksiyon&yil&imdb" to "Aksiyon",
        "${mainUrl}/dizi-arsivi/page/SAYFA/?tur[0]=bilimkurgu&yil&imdb" to "Bilimkurgu",
        "${mainUrl}/dizi-arsivi/page/SAYFA/?tur[0]=komedi&yil&imdb"  to "Komedi",
        "${mainUrl}/dizi-arsivi/page/SAYFA/?tur[0]=dram&yil&imdb"    to "Dram",
        "${mainUrl}/dizi-arsivi/page/SAYFA/?tur[0]=fantastik&yil&imdb" to "Fantastik",
        "${mainUrl}/dizi-arsivi/page/SAYFA/?tur[0]=gerilim&yil&imdb" to "Gerilim",
        "${mainUrl}/dizi-arsivi/page/SAYFA/?tur[0]=korku&yil&imdb"   to "Korku",
        "${mainUrl}/dizi-arsivi/page/SAYFA/?tur[0]=romantik&yil&imdb" to "Romantik",
        "${mainUrl}/dizi-arsivi/page/SAYFA/?tur[0]=animasyon&yil&imdb" to "Animasyon"
    )

    override suspend fun getMainPage(page: Int, request: MainPageRequest): HomePageResponse {
        val rawUrl = request.data
        val url = if (page == 1) {
            if (rawUrl.contains("?")) {
                rawUrl.substringBefore("/page/SAYFA/") + "/?" + rawUrl.substringAfter("?")
            } else {
                rawUrl.substringBefore("/page/SAYFA/") + "/"
            }
        } else {
            rawUrl.replace("SAYFA", "$page")
        }

        val document = app.get(
            url,
            headers     = baseHeaders,
            cookies     = baseCookies,
            interceptor = interceptor,
            cacheTime   = 60
        ).document

        val home = document.select("article.detailed-article, article.article-episode-card")
            .mapNotNull { it.toMainPageResult() }

        val isHorizontal = request.name.contains("Bölümler") || request.name.contains("Popüler")
        return newHomePageResponse(listOf(HomePageList(request.name, home, isHorizontal)), home.isNotEmpty())
    }

    private fun Element.toMainPageResult(): SearchResponse? {
        val titleEl = this.selectFirst("h3 a, a.episode-card-title, div.post-title a")
        val title   = titleEl?.attr("title")?.takeIf { it.isNotBlank() }
            ?: titleEl?.text()?.trim()
            ?: this.selectFirst("img")?.attr("alt")?.trim()
            ?: return null

        val href = fixUrlNull(
            titleEl?.attr("href")
                ?: this.selectFirst("a[href]")?.attr("href")
                ?: this.attr("href")
        ) ?: return null

        val imgEl  = this.selectFirst("img.afis, img.main-cover")
            ?: this.selectFirst("a.figure-link img, figure img")
            ?: this.select("img").firstOrNull { 
                !it.hasClass("language-flag") && 
                !it.attr("src").contains("tr.png") && 
                !it.attr("src").contains("altyazi") && 
                !it.attr("src").contains("dublaj") 
            }
            ?: this.selectFirst("img")

        val imgUrl = fixUrlNull(
            imgEl?.attr("data-src")?.takeIf { it.isNotBlank() && !it.startsWith("data:") }
                ?: imgEl?.attr("data-lazy-src")?.takeIf { it.isNotBlank() && !it.startsWith("data:") }
                ?: imgEl?.attr("data-original")?.takeIf { it.isNotBlank() && !it.startsWith("data:") }
                ?: imgEl?.attr("src")?.takeIf { it.isNotBlank() && !it.startsWith("data:") }
        )
        val rating = this.selectFirst("span.label-imdb b")?.text()?.trim()

        return newTvSeriesSearchResponse(title, href, TvType.TvSeries) {
            this.posterUrl     = imgUrl
            this.posterHeaders = baseHeaders
            this.score         = Score.from10(rating)
        }
    }

    data class SearchApiResponse(@JsonProperty("results") val results: List<SearchResult> = emptyList())
    data class SearchResult(
        @JsonProperty("post_title")          val postTitle           : String  = "",
        @JsonProperty("permalink")           val permalink           : String  = "",
        @JsonProperty("attachment_thumbnail") val attachmentThumbnail: String? = null
    )

    override suspend fun search(query: String): List<SearchResponse> {
        val url      = "$mainUrl/wp-admin/admin-ajax.php?s=$query&action=dwls_search"
        val response = app.get(
            url,
            headers     = baseHeaders + mapOf(
                "X-Requested-With" to "XMLHttpRequest",
                "Referer"          to "$mainUrl/?s=$query"
            ),
            cookies     = baseCookies,
            interceptor = interceptor
        )
        if (!response.isSuccessful) return emptyList()

        val json = tryParseJson<SearchApiResponse>(response.text) ?: return emptyList()
        return json.results.mapNotNull { result ->
            val thumbnail = result.attachmentThumbnail?.replace("50x50", "200x290")
            newTvSeriesSearchResponse(result.postTitle, result.permalink, TvType.TvSeries) {
                this.posterUrl     = fixUrlNull(thumbnail)
                this.posterHeaders = baseHeaders
            }
        }
    }

    override suspend fun quickSearch(query: String): List<SearchResponse> = search(query)

    override suspend fun load(url: String): LoadResponse? {
        var document = app.get(
            url,
            headers     = baseHeaders,
            cookies     = baseCookies,
            interceptor = interceptor
        ).document

        val archiveLink = document.selectFirst("div#archive-box a.archive-title")?.attr("href")
        if (!archiveLink.isNullOrBlank()) {
            val redirectUrl = fixUrlNull(archiveLink) ?: url
            document = app.get(
                redirectUrl,
                headers     = baseHeaders,
                cookies     = baseCookies,
                interceptor = interceptor
            ).document
        }

        val title    = document.selectFirst("div.tv-overview h1 a")?.text()?.trim() ?: return null
        val posterImg = document.selectFirst("div.tv-overview figure img")
        val poster   = fixUrlNull(
            posterImg?.attr("data-src")?.takeIf { it.isNotBlank() && !it.startsWith("data:") }
                ?: posterImg?.attr("data-lazy-src")?.takeIf { it.isNotBlank() && !it.startsWith("data:") }
                ?: posterImg?.attr("data-original")?.takeIf { it.isNotBlank() && !it.startsWith("data:") }
                ?: posterImg?.attr("src")?.takeIf { it.isNotBlank() && !it.startsWith("data:") }
        )
        val plot     = document.selectFirst("div.tv-story p")?.text()?.trim()
        val year     = document.selectFirst("a[href*='/yil/']")?.text()?.trim()?.toIntOrNull()
        val tags     = document.select("a[href*='/tur/']").map { it.text() }
        val actors   = document.select("a[href*='/oyuncu/']").map { Actor(it.text()) }
        val trailer  = document.selectFirst("div.tv-overview iframe")?.attr("src")
        val rating   = document.selectFirst("span.label-imdb b")?.text()?.trim()

        val seasonLinks = document.select("div#seasons-list a").mapNotNull {
            fixUrlNull(it.attr("href"))
        }

        val episodeList = mutableListOf<Episode>()
        seasonLinks.forEach { seasonUrl ->
            val seasonDoc = app.get(
                seasonUrl,
                headers     = baseHeaders,
                cookies     = baseCookies,
                interceptor = interceptor
            ).document

            seasonDoc.select("article.grid-box").forEach epLoop@{ epElem ->
                val epTitleEl = epElem.selectFirst("div.post-title a.season-episode") ?: return@epLoop
                val epRawTitle = epTitleEl.text().trim()
                val epHref     = fixUrlNull(epTitleEl.attr("href")) ?: return@epLoop

                val dateEl   = epElem.selectFirst("small.date")
                val dateText = dateEl?.text()?.trim()?.let { d ->
                    d.replace("Ocak", "01").replace("Şubat", "02").replace("Mart", "03")
                     .replace("Nisan", "04").replace("Mayıs", "05").replace("Haziran", "06")
                     .replace("Temmuz", "07").replace("Ağustos", "08").replace("Eylül", "09")
                     .replace("Ekim", "10").replace("Kasım", "11").replace("Aralık", "12")
                }

                val sNum = Regex("""(\d+)\.? ?Sezon""").find(epRawTitle)?.groupValues?.get(1)?.toIntOrNull() ?: 1
                val eNum = Regex("""(\d+)\.? ?Bölüm""").find(epRawTitle)?.groupValues?.get(1)?.toIntOrNull()

                episodeList.add(newEpisode(epHref) {
                    this.name          = "Bölüm"
                    this.season        = sNum
                    this.episode       = eNum
                    this.posterUrl     = poster
                    if (dateText != null) {
                        val parts = dateText.split(" ")
                        if (parts.size >= 3) {
                            val formatted = "${parts[2]}-${parts[1].padStart(2, '0')}-${parts[0].padStart(2, '0')}"
                            addDate(formatted)
                        }
                    }
                })
            }
        }

        val sortedEpisodes = episodeList.sortedWith(compareBy({ it.season }, { it.episode }))

        return newTvSeriesLoadResponse(title, url, TvType.TvSeries, sortedEpisodes) {
            this.posterUrl     = poster
            this.posterHeaders = baseHeaders
            this.plot          = plot
            this.year          = year
            this.tags          = tags
            this.score         = Score.from10(rating)
            addActors(actors)
            addTrailer(trailer)
        }
    }

    override suspend fun loadLinks(
        data             : String,
        isCasting        : Boolean,
        subtitleCallback : (SubtitleFile) -> Unit,
        callback         : (ExtractorLink) -> Unit
    ): Boolean {
        val document = app.get(
            data,
            headers     = baseHeaders,
            cookies     = baseCookies,
            interceptor = interceptor
        ).document

        val iframeUrl = document.selectFirst("div#video-area iframe")?.attr("src")
            ?: return false

        val sources = mutableListOf(data)
        document.select("div.video-toolbar option[value]").forEach { opt ->
            val valUrl = opt.attr("value")
            if (!valUrl.startsWith("http") && !sources.contains(valUrl)) {
                sources.add(valUrl)
            }
        }

        sources.forEach { sourceUrl ->
            val sourceDoc = app.get(
                sourceUrl,
                headers     = baseHeaders,
                cookies     = baseCookies,
                interceptor = interceptor
            ).document

            val srcIframe = sourceDoc.selectFirst("div#video-area iframe")?.attr("src")
                ?: return@forEach

            processIframe(srcIframe, sourceUrl, data, subtitleCallback, callback)
        }

        return true
    }

    private suspend fun processIframe(
        iframeUrl        : String,
        sourceUrl        : String,
        referer          : String,
        subtitleCallback : (SubtitleFile) -> Unit,
        callback         : (ExtractorLink) -> Unit
    ) {
        when {
            iframeUrl.contains("moly.php") -> {
                loadExtractor(iframeUrl, sourceUrl, subtitleCallback, callback)
            }

            iframeUrl.contains("php?v=") -> {
                val playerUrl = iframeUrl.replace("php?v=", "php?wmode=opaque&v=")
                val playerDoc = app.get(
                    playerUrl,
                    referer     = sourceUrl,
                    headers     = baseHeaders,
                    cookies     = baseCookies,
                    interceptor = interceptor
                ).document

                val finalEmbed = playerDoc.selectFirst("div#Player iframe")?.attr("src")
                    ?: return

                val sheila = finalEmbed
                    .replace("/embed/", "/embed/sheila/")
                    .replace("vidmoly.me", "vidmoly.net")

                if (sheila.contains("dbx.molystream")) {
                    val m3u8Data = app.get(
                        sheila,
                        referer     = finalEmbed,
                        headers     = baseHeaders,
                        interceptor = interceptor
                    ).text
                    val m3u8Url = m3u8Data.lineSequence().firstOrNull { it.startsWith("http") }
                    if (m3u8Url != null) {
                        callback.invoke(
                            newExtractorLink(
                                source = name,
                                name   = name,
                                url    = m3u8Url,
                                type   = ExtractorLinkType.M3U8
                            ) {
                                this.headers = mapOf("Referer" to finalEmbed)
                                this.quality = Qualities.P1080.value
                            }
                        )
                    }
                } else {
                    loadExtractor(sheila, sourceUrl, subtitleCallback, callback)
                }
            }

            iframeUrl.contains("/player/king/king.php") -> {
                val kingUrl = iframeUrl.replace("king.php?v=", "king.php?wmode=opaque&v=")
                val subDoc  = app.get(
                    kingUrl,
                    referer     = referer,
                    headers     = baseHeaders,
                    cookies     = baseCookies,
                    interceptor = interceptor
                ).document
                val subFrame = subDoc.selectFirst("div#Player iframe")?.attr("src") ?: return

                val iDoc      = app.get(subFrame, referer = "$mainUrl/", headers = baseHeaders).text
                val cryptData = Regex("""CryptoJS\.AES\.decrypt\("(.*)","""""").find(iDoc)?.groupValues?.get(1) ?: return
                val cryptPass = Regex(""""","(.*)"\);""").find(iDoc)?.groupValues?.get(1) ?: return
                val decrypted = CryptoJS.decrypt(cryptPass, cryptData)
                val vidUrl    = Regex("""file: '(.*)',""").find(Jsoup.parse(decrypted).html())?.groupValues?.get(1) ?: return

                callback.invoke(
                    newExtractorLink(
                        source = name,
                        name   = name,
                        url    = vidUrl,
                        type   = ExtractorLinkType.M3U8
                    ) {
                        this.headers = mapOf("Referer" to vidUrl)
                        this.quality = Qualities.P1080.value
                    }
                )
            }

            iframeUrl.contains("/player/moly/moly.php") || iframeUrl.contains("/player/haydi.php") -> {
                val molyUrl = when {
                    iframeUrl.contains("moly.php") -> iframeUrl.replace("moly.php?h=", "moly.php?wmode=opaque&h=")
                    else                           -> iframeUrl.replace("haydi.php?v=", "haydi.php?wmode=opaque&v=")
                }
                var subDoc = app.get(
                    molyUrl,
                    referer     = referer,
                    headers     = baseHeaders,
                    cookies     = baseCookies,
                    interceptor = interceptor
                ).document

                val atobData = Regex("""unescape\("(.*)"\)""").find(subDoc.html())?.groupValues?.get(1)
                if (atobData != null) {
                    val decoded = String(Base64.decode(atobData.decodeUri(), Base64.DEFAULT), Charsets.UTF_8)
                    subDoc = Jsoup.parse(decoded)
                }

                val subFrame = subDoc.selectFirst("div#Player iframe")?.attr("src") ?: return
                loadExtractor(subFrame, "$mainUrl/", subtitleCallback, callback)
            }

            else -> {
                loadExtractor(iframeUrl, sourceUrl, subtitleCallback, callback)
            }
        }
    }
}

package com.gsrepo

import com.lagradost.cloudstream3.plugins.CloudstreamPlugin
import com.lagradost.cloudstream3.plugins.Plugin
import android.content.Context

@CloudstreamPlugin
class FilmIzleIlkPlugin: Plugin() {
    override fun load(context: Context) {
        registerMainAPI(FilmIzleIlk())
        registerExtractorAPI(FilmdeFilmExtractor())
    }
}
# Dizigom — CloudStream eklentisi

Darkness Tarayıcı ile **Dizigom** için 20.11.2026 01:59 tarihinde oluşturulan iskelet.

## İçindekiler

| Dosya | Ne işe yarar |
|---|---|
| `Dizigom/src/main/kotlin/.../DizigomProvider.kt` | Sağlayıcı: ana sayfa, arama, detay, video bağlantıları |
| `Dizigom/src/main/kotlin/.../DizigomEndpoints.kt` | Darkness'ın bulduğu 6 API ucu, Kotlin sabitleri olarak |
| `Dizigom/ENDPOINTS.md` | Aynı uçların ayrıntılı listesi (yöntem, durum, kaynak) |
| `Dizigom/build.gradle.kts` | Eklentinin adı, sürümü, dili, türleri |
| `.github/workflows/build.yml` | GitHub'da otomatik .cs3 derlemesi |

## Yapılacaklar

Darkness sayfa analizinden seçicileri, video çözme zincirini (iç içe iframe, packed JS, CryptoJS AES, base64, m3u8/mp4)
ve HLS başlıklarını otomatik doldurdu. Yine de şunlara göz at:

1. `DizigomProvider.kt` başındaki **Analiz özeti**ni oku: hangi kısımların bulunduğunu ve HLS/şifre durumunu gösterir.
   Bulunamayan kısımlar için genel yedek seçiciler kullanılır; sonuç boş çıkarsa `cardSelector`, `episodeSelector` değerlerini düzelt.
2. `search()` içindeki arama adresini kontrol et (Ağ isteği kaynağından tahmin edildi: https://www.gstatic.com/_/mss/search-next/_/js/k=search-next.aim.tr.Y_F1EiRMl7Q.2023.O/ck=search-next.aim.xvs4ctjB3Vc.L.B1.O/am=AIAQAAAAAAAAAMKCAQADDgAgAAAAAAAAAAAAAAAAEAAAAAACQAAAAAAAAAAAAAAAAAAAAACAAAAAAAIAAIBAAAAAQAAAAAAAAAIAAAEAEAAAAAAAAAggAAgAAAAAAAAABAAAAAAAAAAAAAAAAAAABAiABAGAFAAgAABCAAAAAAAAgAgAAAMAAAAEAAAABgABAAAQAAgAQABAAAAAAAAAGAhAAAAAAAAAAAAAAEAAAEAKAAAACAAAgIgAAAAICAAAEIAAAAAABABAIQAAQAEABAAAgAEAbAESAQIAAAAAAAgAAQACQwAAAAAAAAAAAAAAAAAAAOABJAACAAAAAAAAAAAAAAAAAPAG/d=1/exm=Aoijq,b/excm=Aiz46d,D1nDFc,DVhgpe,DYv9hf,E1OJWe,Ed3kAd,FWrJQc,FckSrf,GOIblc,GnLh6e,IMgdb,IvcIwd,LdMUzc,Lla5kf,Plq5zc,QG8Nu,RRnwfd,Rx97Ze,SJL2bc,U6xdnf,XmAqMd,Y3GM1,ayDvec,b4fE6b,bE9Rne,bFSsRb,bT5qhd,cw4ZOe,cxU6rb,dMpPMc,eucJfe,fWuSJe,frqn5c,hHUugd,hcoscf,iCKMW,iIDHec,jCUWrb,k2SZUc,kZjfGf,mH3LZe,n9Azi,nCphfe,nx4H1c,pGL8Nd,qwhOwf,rXUgd,rjxeEe,secKrf,swBmte,t4jSFb,tyP7Ic,wj3ibd,xgST2d,xyZB,yxVckb/ed=1/dg=2/ujg=1/rs=AE5fCmQLYfZqypC7gIHnkKUHrsHgqs9_wg/cb=loaded_g_0/ee=BjwMce:cXX2Wb;CG6uBf:fHvdNd;CIZTGb:QUpXJb;EmZ2Bf:zr1jrb;IsdWVc:qzxzOb;JXS8fb:k0T3Ub;K5nYTd:ZDZcre;KDb6nb:fE9n2;LEikZe:byfTOb,lsjVmc;MNkAde:KMCd1d;NJ1rfe:yGfSdd;NSEoX:lazG7b;NjIwef:YVgi7d;Np8Qkd:Dpx6qc;O53Aqe:sQbkGd;OjQStc:hApHFd;Pjplud:PoEs9b;QGR0gd:Mlhmy;RZKicf:PQXVv;RZtOEd:DvKcFe;SFghJd:YRZpK;ScI3Yc:e7Hzgb;TroZ1d:vVVzjb;UYRIEb:A9Y3ee,HzTAQc;VZN6W:CniFLb;WDGyFe:jcVOxd;YIZmRd:A1yn5d;YV5bee:W0fpg;ZSH6tc:QAvyLe;a56pNe:JEfCwb;aci7y:Z5Tr6c;cEt90b:ws9Tlc;dIoSBb:SpsfSb;dowIGb:ebZ3mb;dtl0hd:lLQWFe;eBAeSb:zbML3c;eBZ5Nd:audvde;eHDfl:ofjVkb;eJKchc:ATg1be;gTtPhb:RvPnwb;iFQyKf:vfuNJf;lOO0Vd:OTA3Ae;mtKMCc:ZG5Tfe;oGtAuc:sOXFj;oiBhre:OuMkRd;osNlFe:eRJvTc;qGV2uc:HHi04c;qQEoOc:KUM7Z;qaS3gd:yiLg6e;qafBPd:ovKuLd;qavrXe:I0C9u;qddgKe:xQtZb;ropkZ:hjoqoe;sTsDMc:H8cOfd,VF9yLb,kHVSUb,xkjGve;t4Ja1:LwyM3;teSRSb:BMLai;twgzJd:Ix7YEd;w9w86d:VvLVQd,XwhUEb,gKD90c,lWVZVe;wBUPed:va9PTd;wFpbG:JbGbBc;wR5FRb:siKnQd;yxTchf:KUM7Z/m=O1cPT,nfCumd,XqmSxe,POB4Jc,UTzWVc,BXN7nf,v6N5Sc,IAoFnf,uxSOtd,hWYCOd,v8wVVc,RFtMpc,a5f0he,bzV7h,RJMArf,kSwcXe,WtAF6b,CAwPlc,x96nxe,QQUMnc,u3Km8d,OZcXHe,bp6ZCb).
3. Video açılmıyorsa Darkness'da videoyu oynatıp **Araçlar → CS analizi** çalıştır ve iskeleti yeniden dışa aktar.
   DRM korumalı (Widevine/FairPlay) akışlar CloudStream'de oynatılamaz.
4. Çalıştığını gördüğünde `build.gradle.kts` içinde `status = 1` yap ve her güncellemede `version` sayısını artır.

## Derleme

**GitHub ile (önerilen):** Bu klasörün içeriğini boş bir GitHub deposuna yükle. Actions otomatik derler,
`.cs3` dosyalarını ve `repo.json`'u **builds** dalına koyar. CloudStream'de
*Ayarlar → Uzantılar → Depo ekle* kısmına şunu yaz:

```
https://raw.githubusercontent.com/KULLANICI/DEPO/builds/repo.json
```

**Kendi builder'ınla:** Sadece `Dizigom` klasörünü mevcut eklenti deponun köküne kopyala.

**Bilgisayarda:** Android SDK ve JDK 17 kuruluyken `gradle make` (çıktı: `Dizigom/build/Dizigom.cs3`).

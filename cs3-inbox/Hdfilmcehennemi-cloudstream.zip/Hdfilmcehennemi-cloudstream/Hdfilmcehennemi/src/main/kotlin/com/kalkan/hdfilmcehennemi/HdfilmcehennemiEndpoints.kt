package com.kalkan.hdfilmcehennemi

/**
 * Kalkan Tarayıcı'nın www.hdfilmcehennemi.nl üzerinde bulduğu API uçları (19.11.2026 06:11).
 * Aynı sitedeki uçlar mainUrl'e göre göreli yazılmıştır: "$mainUrl" + SABIT
 */
@Suppress("unused")
object HdfilmcehennemiEndpoints {
    /** GET · Canlı */
    const val FX7NYORDEESAZA6SC0AURW_JSON = "https://entitlements.jwplayer.com/Fx7nyoRdEeSaZA6sC0aurw.json"
    /** POST · Canlı · 200 · text/html */
    const val POST_VIDEO_EMBED_UB7GPNXIQGV_AH = "https://hdfilmcehennemi.mobi/video/embed/UB7gPnxIqGv/ah/"
    // Örnek gövde: hash=ee424afeb1dc9c1a4ba6cfca1061581b&e=255
    /** GET · Canlı · 200 · text/vtt */
    const val VTT_UB7GPNXIQGV_ENG_ATALENTFORMURDER_2026_WEBDL_TT14129116_S = "https://hdfilmcehennemi.mobi/vtt/2026/11/UB7gPnxIqGv-eng-atalentformurder-2026-webdl-tt14129116_subtitles01.eng.vtt"
    /** GET · Canlı · 200 · text/vtt */
    const val VTT_UB7GPNXIQGV_ENG_ATALENTFORMURDER_2026_WEBDL_TT14129116_S_2 = "https://hdfilmcehennemi.mobi/vtt/2026/11/UB7gPnxIqGv-eng-atalentformurder-2026-webdl-tt14129116_subtitles02.eng.vtt"
    /** GET · Canlı · 200 · text/vtt */
    const val VTT_UB7GPNXIQGV_FR_OS13050029_ATALENTFORMURDER2026WEBDLTT141 = "https://hdfilmcehennemi.mobi/vtt/2026/11/UB7gPnxIqGv-fr-os13050029-atalentformurder2026webdltt14129116mp4.vtt"
    /** GET · Canlı · 200 · text/vtt */
    const val VTT_UB7GPNXIQGV_SPA_ATALENTFORMURDER_2026_WEBDL_TT14129116_S = "https://hdfilmcehennemi.mobi/vtt/2026/11/UB7gPnxIqGv-spa-atalentformurder-2026-webdl-tt14129116_subtitles03.spa.vtt"
    /** GET · Canlı · 200 · text/vtt */
    const val VTT_UB7GPNXIQGV_TR_4987281_ATALENTFORMURDER_2026_WEBDL_TT141 = "https://hdfilmcehennemi.mobi/vtt/2026/11/UB7gPnxIqGv-tr-4987281-atalentformurder-2026-webdl-tt14129116_subtitles02engtr.vtt"
    /** GET · Canlı · 200 · application/json */
    const val V_8_39_3_TRANSLATIONS_TR_JSON = "https://ssl.p.jwpcdn.com/player/v/8.39.3/translations/tr.json"
    /** GET · Canlı · 200 · application/json */
    const val WWW_HDFILMCEHENNEMI_NL = "/?router=1"
    /** GET · Canlı · 200 · application/json */
    const val A_TALENT_FOR_MURDER = "/a-talent-for-murder/?router=1"
    /** POST · Canlı · 200 · text/html */
    const val POST_B_FO_696520627_1795054826_958OZEPGTAUYDKPHRKCTGTIFMBFU5 = "/cdn-cgi/challenge-platform/h/b/fo/696520627:1795054826:958OZePgTauydKPHrKCTgTIFMbfU5f6tFbrI4SWHitc/a5cc03683f069715/_vkOjdJi_HFImwSbVgS14RwJYzJW0SEXDUUTEyOnLWA-1795057737-1.2.1.1-aA3uw6_pIPab4YaPlm.0Z8ocEaY8cYC26xv4VscdMVrKym.Vd3vprhgIUUXlRDZx"
    // Örnek gövde: LJcMxAbR1staH0EBXSLLenLJbUUjYy96MV8fkPbhIICM87n7qcS+TyKJAaIYxGTUF1sSvvon9fUzKo7al$AhTDJlo1RNBDIVD-3mnDSuQkZNOLmHvJ$THhlfPQCRX3QM$Mefo7jJDJOhWPzWstrk0-UWWRYIyNUH
    /** GET · Canlı · 200 · application/json */
    const val HOPE_2026_HDFC_6 = "/hope-2026-hdfc-6/?router=1"
    /** GET · Canlı · 200 · text/html */
    const val SEARCH = "/search"
    /** GET · Canlı · 200 · application/json */
    const val THE_ODYSSEY_3 = "/the-odyssey-3/?router=1"
    /** GET · Canlı · 200 · application/json */
    const val YABANCIDIZIIZLE_15 = "/yabancidiziizle-15/?router=1"
}

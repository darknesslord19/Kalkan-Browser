package com.kalkan.hdfilmcehennemi

/**
 * Kalkan Tarayıcı'nın www.hdfilmcehennemi.nl üzerinde bulduğu API uçları (19.11.2026 06:39).
 * Aynı sitedeki uçlar mainUrl'e göre göreli yazılmıştır: "$mainUrl" + SABIT
 */
@Suppress("unused")
object HdfilmcehennemiEndpoints {
    /** GET · Canlı · 200 · application/json */
    const val WWW_HDFILMCEHENNEMI_NL = "/?router=1"
    /** GET · Canlı · 200 · application/json */
    const val HOPE_2026_HDFC_6 = "/hope-2026-hdfc-6/?router=1"
    /** GET · Canlı · 200 · text/html */
    const val SEARCH = "/search"
}

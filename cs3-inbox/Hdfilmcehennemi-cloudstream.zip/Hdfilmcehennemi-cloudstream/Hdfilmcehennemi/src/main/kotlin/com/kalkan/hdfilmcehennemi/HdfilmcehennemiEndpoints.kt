package com.kalkan.hdfilmcehennemi

/**
 * Kalkan Tarayıcı'nın www.hdfilmcehennemi.nl üzerinde bulduğu API uçları (19.11.2026 14:01).
 * Aynı sitedeki uçlar mainUrl'e göre göreli yazılmıştır: "$mainUrl" + SABIT
 */
@Suppress("unused")
object HdfilmcehennemiEndpoints {
    /** POST · Canlı · 200 · text/html */
    const val POST_B_FO_2571422757_1795083627_ZUY9TF7SWPWNOCRQLHUFM_QVFXEU = "/cdn-cgi/challenge-platform/h/b/fo/2571422757:1795083627:zuY9tf7sWpWnoCRqLhuFM-QVfXEUrJIr578G-MkLDX0/a5ceb554bbadfff5/hrMYUhwIr12V3M1kAbNZkAShwO1L.lX93riO2KNfGhs-1795085996-1.2.1.1-sAH_wHjY1efZ18Zx4.9znQpCULr8f64hgqouODbUSEDPLJHYkPVX5YQ3o_ihtpC3"
    // Örnek gövde: x7nZC$$0-EzHPuGWo3$+9Jv53podG53+n4$lCWgMIH0OKWSz8In1x4oNzAdUBLaNdc3sAl9Y49wWb$uISQKKbPx27K0dSsdZgyYdD6ogFes1jpplVwSgHQJEk6984Q0sK7VxZ57BaWQm5U6N$-pj-NzEF2NTsBd-
}

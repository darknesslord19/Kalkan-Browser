package com.kalkan.hdfilmcehennemi

/**
 * Kalkan Tarayıcı'nın www.hdfilmcehennemi.nl üzerinde bulduğu API uçları (19.11.2026 07:30).
 * Aynı sitedeki uçlar mainUrl'e göre göreli yazılmıştır: "$mainUrl" + SABIT
 */
@Suppress("unused")
object HdfilmcehennemiEndpoints {
    /** POST · Canlı */
    const val POST_G_COLLECT = "https://www.google-analytics.com/g/collect?v=2&tid=G-LR91MEQ0YR&gtm=45je6bh1v885388931za208zd885388931xf1&_p=1795062526952&gcd=13l3l3l3l1l1&npa=0&dma=0&_eu=AAAAAAQ&cid=609598849.1792885359&frm=0&ngs=1&pscdl=noapi&rcb=16&sr=407x904&uaa=&uab=&uafvl=&uam=&uamb=1&uap=Android&uapv=&uaw=0&ul=tr-tr&_s=1&tag_exp=115938466~115938468~118897920~118897930~120213116~120385423~120469145~120469153~121246026~121246034&sid=1795061827&sct=2&seg=1&dl=https%3A%2F%2Fwww.hdfilmcehennemi.nl%2F&dt=Hdfilmcehennemi%20%7C%20Film%20izle%20%7C%20HD%20Film%20izle&en=page_view&_ee=1&tfd=5901"
    /** POST · Canlı · 204 · text/plain */
    const val POST_CDN_CGI_RUM = "/cdn-cgi/rum?"
    // Örnek gövde: {"startTime":1795062526177,"pageloadId":"e4889ed2-1267-4c34-b0ee-6a0690960496","eventType":1,"nt":"navigate","location":"https://www.hdfilmcehennemi.nl/","versi
}

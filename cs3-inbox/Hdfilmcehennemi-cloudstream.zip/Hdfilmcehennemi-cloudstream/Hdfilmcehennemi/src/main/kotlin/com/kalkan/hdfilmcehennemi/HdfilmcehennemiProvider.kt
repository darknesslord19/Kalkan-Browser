package com.kalkan.hdfilmcehennemi

import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.*
import org.jsoup.nodes.Element

/**
 * Hdfilmcehennemi için CloudStream sağlayıcısı.
 * Kalkan Tarayıcı ile 19.11.2026 14:01 tarihinde oluşturuldu.
 *
 * Seçiciler Kalkan'ın sayfa analizinden dolduruldu. Analiz yapılmayan kısımlar için
 * genel yedekler kullanılır; çalışmayan bir yer olursa aşağıdaki seçici sabitlerini düzelt.
 * Kalkan'ın bulduğu uçlar: HdfilmcehennemiEndpoints.kt ve ENDPOINTS.md
 *
 * Analiz özeti:
 *  - Kartlar: 37 adet, seçici div.section-content
 *  - Bölümler: bulunamadı (film olarak ele alınır)
 *  - HLS: bu sayfada m3u8 yakalanmadı (videoyu oynatıp tekrar dışa aktar)
 */
class HdfilmcehennemiProvider : MainAPI() {
    override var mainUrl = "https://www.hdfilmcehennemi.nl"
    override var name = "Hdfilmcehennemi"
    override var lang = "tr"
    override val hasMainPage = true
    override val supportedTypes = setOf(TvType.Movie, TvType.TvSeries)

    // Ana sayfa bölümleri: adres to başlık. Adreste {page} varsa sayfa numarası yazılır,
    // yoksa 2. sayfadan itibaren /page/N/ eklenir (WordPress düzeni).
    override val mainPage = mainPageOf(
        "$mainUrl/" to "Ana sayfa",
        "$mainUrl/film-robotu-2/" to "Keşfet",
        "$mainUrl/category/film-izle-2/" to "Filmler",
        "$mainUrl/yabancidiziizle-15/" to "Diziler",
        "$mainUrl/yil/2025-filmleri-izle-3/" to "2025",
        "$mainUrl/yil/2024-2/" to "2024",
        "$mainUrl/yil/2023-yapimi-filmler-4/" to "2023",
        "$mainUrl/yil/2022-filmleri-izle-3/" to "2022",
        "$mainUrl/yil/2021-filmleri-izle-3/" to "2021",
    )

    // ---- Seçiciler (Kalkan analizi) ----
    private val cardSelector = "a:has(img)"
    private val posterAttr = "src"
    private val episodeSelector = ""

    override suspend fun getMainPage(page: Int, request: MainPageRequest): HomePageResponse {
        val url = when {
            request.data.contains("{page}") -> request.data.replace("{page}", page.toString())
            page > 1 -> request.data.trimEnd('/') + "/page/$page/"
            else -> request.data
        }
        val resp = fetch(url)
        var items = findCards(resp.document)
        if (items.isEmpty()) items = routerCards(url)
        if (items.isEmpty() && page <= 1) throw ErrorLoadingException("Kart bulunamadı (HTTP ${resp.code}, ${resp.text.length} bayt): ${resp.text.take(90).replace('\n', ' ')}")
        return newHomePageResponse(request, items, hasNext = items.isNotEmpty())
    }

    private val badPath = Regex("(?i)/(oyuncu|actor|cast|yonetmen|director|etiket|tag|author|yazar|user|uye|login|register|iletisim|contact|category|kategori|yil|ulke|page)(/|$)")

    /** Seçici işe yaramazsa ya da oyuncu/etiket gibi yanlış bağlantılar dönerse, görselli film bağlantılarını kendisi bulur. */
    private fun findCards(doc: org.jsoup.nodes.Document): List<SearchResponse> {
        val host = try { java.net.URI(mainUrl).host.removePrefix("www.") } catch (_: Exception) { "" }
        fun ok(r: SearchResponse): Boolean = try {
            val u = java.net.URI(r.url); u.host.removePrefix("www.") == host && u.path.length > 2 && !badPath.containsMatchIn(u.path)
        } catch (_: Exception) { false }
        val primary = doc.select(cardSelector).mapNotNull { it.toSearchResult() }.distinctBy { it.url }.filter { ok(it) }
        if (primary.size >= 3) return primary
        val generic = doc.select("a[href]:has(img)").mapNotNull { it.toSearchResult() }.distinctBy { it.url }.filter { ok(it) }
        return if (generic.size > primary.size) generic else primary
    }

    private val cfKiller by lazy { com.lagradost.cloudstream3.network.CloudflareKiller() }

    /** Önce düz istek; Cloudflare/403/503 engeli görürse CloudflareKiller ile yeniden dener. */
    private suspend fun fetch(url: String): com.lagradost.nicehttp.NiceResponse {
        val hdr = mapOf("Accept-Language" to "tr-TR,tr;q=0.9,en;q=0.8")
        var r = app.get(url, referer = mainUrl, headers = hdr)
        val blocked = r.code == 403 || r.code == 503 || r.text.contains("Just a moment", true) || r.text.contains("cf-browser-verification", true)
        if (blocked) r = app.get(url, referer = mainUrl, headers = hdr, interceptor = cfKiller)
        followDomain(r.url)
        return r
    }

    /** Site alan adı değiştirip yönlendiriyorsa (ör. .nl → .mobi) mainUrl'i yeni adrese çeker. */
    private fun followDomain(finalUrl: String) {
        try {
            val h = java.net.URI(finalUrl).host ?: return
            val cur = java.net.URI(mainUrl).host ?: return
            val brand = cur.removePrefix("www.").substringBefore('.').take(8)
            if (h != cur && h.contains(brand, true)) mainUrl = "https://$h"
        } catch (_: Exception) { }
    }

    private val xrwValue = "fetch"
    private val xhrHeaders: List<Map<String, String>> =
        listOf(emptyMap<String, String>()) + listOf(xrwValue, "XMLHttpRequest", "fetch").distinct().map { mapOf("X-Requested-With" to it) }
    private val streamRegex = Regex("(?i)\\.(m3u8|mp4)(\\?|\\$)|/master\\.txt")
    private val routerParam = "router=1"
    private val epRegex = Regex("(?i)(\\d+\\s*\\.?\\s*(bölüm|bolum|sezon|episode|season|ep)\\b|\\b(bölüm|bolum|episode|ep|sezon|season)[\\s-]*\\d+|\\d+\\s*x\\s*\\d+)")

    /** İçeriği JSON uç noktasından da veren (SPA) siteler için: adrese router parametresi ekleyip yanıttan HTML çıkarır. */
    private suspend fun routerBody(url: String): String {
        if (routerParam.isBlank()) return ""
        val u = url + (if (url.contains("?")) "&" else "?") + routerParam
        return try { app.get(u, referer = mainUrl, headers = mapOf("X-Requested-With" to xrwValue)).text } catch (_: Exception) { "" }
    }

    private suspend fun routerCards(url: String): List<SearchResponse> = parseSearch(routerBody(url))

    private suspend fun routerDoc(url: String): org.jsoup.nodes.Document? {
        val t = routerBody(url).trim()
        if (t.isEmpty()) return null
        if (!(t.startsWith("{") || t.startsWith("["))) return org.jsoup.Jsoup.parse(t, mainUrl)
        val strs = ArrayList<String>()
        try { jsonStrings(if (t.startsWith("[")) org.json.JSONArray(t) else org.json.JSONObject(t), strs) } catch (_: Exception) { return null }
        val html = strs.filter { it.contains("<") && it.contains(">") }.joinToString("\n")
        return if (html.isBlank()) null else org.jsoup.Jsoup.parse(html, mainUrl)
    }

    private val junkText = Regex("(?i)^(izle|film izle|devamı|detay|incele|oynat|play|tıkla|hd|dublaj|altyazı)$")
    private val junkImg = Regex("(?i)(logo|icon|dublaj|altyazi|flag|badge|avatar|blank|placeholder|loading|spinner|\\.svg|\\.gif)")

    /** Aynı adrese giden bağlantılar arasından (poster bağlantısında yazı olmayabilir) en uygun başlık metnini bulur. */
    private fun sameHrefText(a: Element): String? {
        val raw = a.attr("href")
        return a.ownerDocument()?.select("a[href]")?.filter { it.attr("href") == raw }
            ?.map { it.text().trim() }?.filter { it.length in 3..100 && !junkText.matches(it) }?.maxByOrNull { it.length }
    }

    /** Son çare başlık: adres sonundaki slug'dan ("odyssey-izle" → "Odyssey"). Geçerli adresli kart asla düşmez. */
    private fun slugTitle(href: String): String? {
        val slug = href.trimEnd('/').substringAfterLast('/').substringBefore('?').removeSuffix(".html")
        val t = slug.replace(Regex("(?i)-(izle|full|hd|film|filmi|izle-hd)$"), "").replace('-', ' ').trim()
        return t.takeIf { it.length >= 2 }?.replaceFirstChar { it.uppercase() }
    }

    private fun Element.toSearchResult(): SearchResponse? {
        val anchor = if (tagName() == "a") this else selectFirst("a") ?: return null
        val title = (selectFirst("h3")?.text())?.trim()?.takeIf { it.isNotBlank() }
            ?: sameHrefText(anchor)
            ?: selectFirst("img")?.attr("alt")?.trim()?.takeIf { it.isNotBlank() }
            ?: anchor.attr("title").trim().takeIf { it.isNotBlank() }
            ?: slugTitle(anchor.attr("href"))
            ?: return null
        val href = fixUrlNull(anchor.attr("href")) ?: return null
        val img = select("img").firstOrNull { im -> !junkImg.containsMatchIn(im.attr("data-src") + im.attr("data-original") + im.attr("src")) } ?: selectFirst("img")
        val poster = fixUrlNull(
            listOf("data-src", "data-original", "data-lazy-src", "data-lazy", posterAttr, "src")
                .mapNotNull { k -> img?.attr(k)?.trim()?.takeIf { it.isNotBlank() && !it.startsWith("data:") && !junkImg.containsMatchIn(it) } }
                .firstOrNull()
                ?: img?.attr("src")
        )
        return newMovieSearchResponse(title, href, TvType.Movie) {
            this.posterUrl = poster
        }
    }

    // Birincil arama boş dönerse sırayla denenen yaygın arama adresleri (%s = sorgu)
    private val searchFallbacks = listOf(
        "/?s=%s", "/search?q=%s", "/search/?q=%s", "/arama?q=%s", "/arama/?q=%s", "/ara?q=%s",
        "/index.php?do=search&subaction=search&story=%s", "/search/%s", "/arama/%s", "/ara/%s",
        "/?q=%s", "/?search=%s", "/search?query=%s", "/api/search?q=%s", "/ajax/search?q=%s"
    )

    private fun jsonStrings(node: Any?, out: MutableList<String>) {
        when (node) {
            is org.json.JSONObject -> node.keys().forEach { jsonStrings(node.opt(it), out) }
            is org.json.JSONArray -> for (i in 0 until node.length()) jsonStrings(node.opt(i), out)
            is String -> out.add(node)
        }
    }

    /** Arama yanıtını (HTML ya da JSON içinde HTML/nesne listesi) sonuç listesine çevirir. */
    private fun parseSearch(body: String): List<SearchResponse> {
        val t = body.trim()
        if (t.isEmpty()) return emptyList()
        val docs = ArrayList<org.jsoup.nodes.Document>()
        if (t.startsWith("{") || t.startsWith("[")) {
            val strs = ArrayList<String>()
            try { jsonStrings(if (t.startsWith("[")) org.json.JSONArray(t) else org.json.JSONObject(t), strs) } catch (_: Exception) {}
            val html = strs.filter { it.contains("<") && it.contains(">") }.joinToString("\n")
            if (html.isNotBlank()) docs.add(org.jsoup.Jsoup.parse(html, mainUrl))
            // Nesne listesi: {title/name, url/link/slug, poster/image}
            try {
                val arr = ArrayList<org.json.JSONObject>()
                fun walk(n: Any?) {
                    when (n) {
                        is org.json.JSONObject -> { if ((n.has("title") || n.has("name")) && (n.has("url") || n.has("link") || n.has("slug") || n.has("uri"))) arr.add(n) else n.keys().forEach { walk(n.opt(it)) } }
                        is org.json.JSONArray -> for (i in 0 until n.length()) walk(n.opt(i))
                    }
                }
                walk(if (t.startsWith("[")) org.json.JSONArray(t) else org.json.JSONObject(t))
                val res = arr.mapNotNull { o ->
                    val ttl = o.optString("title").ifBlank { o.optString("name") }.trim()
                    val raw = listOf("url", "link", "uri", "slug").map { o.optString(it) }.firstOrNull { it.isNotBlank() } ?: return@mapNotNull null
                    val href = fixUrlNull(raw) ?: return@mapNotNull null
                    val img = listOf("poster", "image", "img", "thumb", "thumbnail", "cover").map { o.optString(it) }.firstOrNull { it.isNotBlank() }
                    if (ttl.isBlank()) null else newMovieSearchResponse(ttl, href, TvType.Movie) { this.posterUrl = fixUrlNull(img) }
                }
                if (res.isNotEmpty()) return res.distinctBy { it.url }
            } catch (_: Exception) {}
        } else docs.add(org.jsoup.Jsoup.parse(t, mainUrl))
        for (d in docs) {
            val r = findCards(d)
            if (r.isNotEmpty()) return r
        }
        return emptyList()
    }

    override suspend fun search(query: String): List<SearchResponse> {
        // Arama ucu: Kalkan taramasında sitede gerçek arama yapılarak bulundu (/search?q=%s) · doğrulandı · UYARI: doğrulanamadı, arama çalışmayabilir
        val encoded = java.net.URLEncoder.encode(query, "UTF-8")
        val primaryBody = try {
            val url = "$mainUrl/search?q=${java.net.URLEncoder.encode(query, "UTF-8")}"
        val response = app.get(url, referer = mainUrl)
            response.text
        } catch (_: Exception) { "" }
        var results = parseSearch(primaryBody)
        if (results.isEmpty()) {
            for (p in searchFallbacks) {
                val u = mainUrl + p.replace("%s", encoded)
                for (h in xhrHeaders) {
                    val body = try { app.get(u, referer = mainUrl, headers = h).text } catch (_: Exception) { "" }
                    results = parseSearch(body)
                    if (results.isNotEmpty()) return results
                }
            }
        }
        return results
    }

    override suspend fun load(url: String): LoadResponse? {
        val document = fetch(url).document.let { d -> if (d.selectFirst("h1") == null) (routerDoc(url) ?: d) else d }

        val title = document.selectFirst("h1")?.text()?.trim()
            ?: document.selectFirst("meta[property=og:title]")?.attr("content")
            ?: return null
        val poster = fixUrlNull(document.selectFirst("meta[property=og:image]")?.attr("content"))
        val plot = document.selectFirst("meta[property=og:description]")?.attr("content")
        val year = Regex("(19|20)\\d{2}")
            .find(document.selectFirst("[class*=year], [class*=yil], [class*=release]")?.text() ?: "")?.value?.toIntOrNull()

        val episodes = if (episodeSelector.isBlank()) emptyList() else
            document.select(episodeSelector).filter { epRegex.containsMatchIn(it.text() + " " + it.attr("href")) }.mapIndexedNotNull { i, ep ->
                val href = fixUrlNull(ep.attr("href")) ?: return@mapIndexedNotNull null
                newEpisode(url = href, initializer = {
                    this.name = ep.text().trim().ifBlank { "Bölüm ${i + 1}" }
                    this.episode = i + 1
                })
            }.distinctBy { it.data }

        return if (episodes.size > 1) {
            newTvSeriesLoadResponse(title, url, TvType.TvSeries, episodes) {
                this.posterUrl = poster
                this.plot = plot
                this.year = year
            }
        } else {
            newMovieLoadResponse(title, url, TvType.Movie, url) {
                this.posterUrl = poster
                this.plot = plot
                this.year = year
            }
        }
    }

    // ---- Video çözümleme (sırayla): bilinen barındırıcılar, iç içe iframe'ler (2 seviye),
    // ---- packed JS, CryptoJS AES blokları, base64 gömülü linkler, doğrudan m3u8/mp4
    override suspend fun loadLinks(
        data: String,
        isCasting: Boolean,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        val page = fetch(data)
        var ok = scanSource(page.text, page.document, data, 0, subtitleCallback, callback)
        if (!ok) routerDoc(data)?.let { ok = scanSource(it.outerHtml(), it, data, 0, subtitleCallback, callback) }
        return ok
    }

    private suspend fun scanSource(
        raw: String,
        doc: org.jsoup.nodes.Document?,
        referer: String,
        depth: Int,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        var found = false
        var text = raw.replace("\\/", "/")

        // packed JS (eval(function(p,a,c,k,e,d)...)
        if (text.contains("eval(function(p,a,c,k,e,d)")) {
            runCatching { JsUnpacker(text).unpack() }.getOrNull()?.let { text += "\n" + it.replace("\\/", "/") }
        }

        if (emitStreams(text, referer, callback)) found = true

        // base64 içinde saklanan linkler
        Regex("[\"']([A-Za-z0-9+/=]{40,})[\"']").findAll(text).forEach { m ->
            val dec = runCatching { String(android.util.Base64.decode(m.groupValues[1], android.util.Base64.DEFAULT)) }.getOrNull()
            if (dec != null && dec.startsWith("http")) {
                if (loadExtractor(dec, referer, subtitleCallback, callback) || emitStreams(dec, referer, callback)) found = true
            }
        }

        // iframe / data-* gömülü oynatıcılar
        if (depth < 2) {
            val d = doc ?: org.jsoup.Jsoup.parse(text)
            val attrs = listOf("src", "data-src", "data-embed", "data-video", "data-player", "data-url")
            val frames = d.select("iframe, [data-embed], [data-video], [data-player]")
                .mapNotNull { el -> attrs.firstNotNullOfOrNull { k -> el.attr(k).takeIf { it.isNotBlank() } } }
                .map { fixUrl(it) }.distinct()
            for (frame in frames) {
                if (loadExtractor(frame, referer, subtitleCallback, callback)) { found = true; continue }
                val inner = runCatching { app.get(frame, referer = referer).text }.getOrNull()
                if (inner != null && scanSource(inner, null, frame, depth + 1, subtitleCallback, callback)) { found = true; continue }
                // Son çare: oynatıcıyı gerçek bir WebView'da çalıştırıp ağdaki m3u8/mp4 isteğini yakala
                // (karmaşık/gizlenmiş oynatıcı betiklerini kendimiz çözmek yerine tarayıcıya çözdürür)
                if (depth == 0 && !found) {
                    val got = runCatching {
                        app.get(frame, referer = referer, interceptor = com.lagradost.cloudstream3.network.WebViewResolver(streamRegex)).url
                    }.getOrNull()
                    if (got != null && streamRegex.containsMatchIn(got) && emitStreams(got, frame, callback)) found = true
                }
            }
        }
        return found
    }

    // HLS: AES-128 (açık anahtarlı) şifrelemeyi oynatıcı kendisi çözer; burada yalnızca
    // doğru Referer/Origin başlıklarını veriyoruz. DRM (Widevine/FairPlay) desteklenmez.
    private suspend fun emitStreams(src: String, referer: String, callback: (ExtractorLink) -> Unit): Boolean {
        var ok = false
        val origin = runCatching { java.net.URI(referer).let { "${it.scheme}://${it.host}" } }.getOrDefault(mainUrl)
        val hdr = mapOf("Referer" to referer, "Origin" to origin)
        Regex("https?:[^\"'\\s<>\\\\]+\\.m3u8[^\"'\\s<>\\\\]*").findAll(src).map { it.value }.distinct().forEach { u ->
            M3u8Helper.generateM3u8(name, u, referer, headers = hdr).forEach(callback)
            ok = true
        }
        Regex("https?:[^\"'\\s<>\\\\]+\\.mp4[^\"'\\s<>\\\\]*").findAll(src).map { it.value }.distinct().forEach { u ->
            callback(newExtractorLink(name, name, u, ExtractorLinkType.VIDEO) {
                this.referer = referer
                this.headers = hdr
                this.quality = Qualities.Unknown.value
            })
            ok = true
        }
        Regex("https?:[^\"'\\s<>\\\\]+/master\\.txt[^\"'\\s<>\\\\]*").findAll(src).map { it.value }.distinct().forEach { u ->
            M3u8Helper.generateM3u8(name, u, referer, headers = hdr).forEach(callback)
            ok = true
        }
        return ok
    }
}

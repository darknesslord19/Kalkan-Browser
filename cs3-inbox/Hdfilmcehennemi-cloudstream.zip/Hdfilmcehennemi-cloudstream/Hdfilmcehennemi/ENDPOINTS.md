# Odyssey izle — bulunan uçlar

Kalkan Tarayıcı · 19.11.2026 06:11 · https://www.hdfilmcehennemi.nl

| Yöntem | Adres | Kaynak | Durum | Not |
|---|---|---|---|---|
| GET | `https://entitlements.jwplayer.com/Fx7nyoRdEeSaZA6sC0aurw.json` | Canlı |  |  |
| POST | `https://hdfilmcehennemi.mobi/video/embed/UB7gPnxIqGv/ah/` | Canlı | 200 | text/html |
| GET | `https://hdfilmcehennemi.mobi/vtt/2026/11/UB7gPnxIqGv-eng-atalentformurder-2026-webdl-tt14129116_subtitles01.eng.vtt` | Canlı | 200 | text/vtt |
| GET | `https://hdfilmcehennemi.mobi/vtt/2026/11/UB7gPnxIqGv-eng-atalentformurder-2026-webdl-tt14129116_subtitles02.eng.vtt` | Canlı | 200 | text/vtt |
| GET | `https://hdfilmcehennemi.mobi/vtt/2026/11/UB7gPnxIqGv-fr-os13050029-atalentformurder2026webdltt14129116mp4.vtt` | Canlı | 200 | text/vtt |
| GET | `https://hdfilmcehennemi.mobi/vtt/2026/11/UB7gPnxIqGv-spa-atalentformurder-2026-webdl-tt14129116_subtitles03.spa.vtt` | Canlı | 200 | text/vtt |
| GET | `https://hdfilmcehennemi.mobi/vtt/2026/11/UB7gPnxIqGv-tr-4987281-atalentformurder-2026-webdl-tt14129116_subtitles02engtr.vtt` | Canlı | 200 | text/vtt |
| GET | `https://ssl.p.jwpcdn.com/player/v/8.39.3/translations/tr.json` | Canlı | 200 | application/json |
| GET | `https://www.hdfilmcehennemi.nl/?router=1` | Canlı | 200 | application/json, ×2 |
| GET | `https://www.hdfilmcehennemi.nl/a-talent-for-murder/?router=1` | Canlı | 200 | application/json |
| POST | `https://www.hdfilmcehennemi.nl/cdn-cgi/challenge-platform/h/b/fo/696520627:1795054826:958OZePgTauydKPHrKCTgTIFMbfU5f6tFbrI4SWHitc/a5cc03683f069715/_vkOjdJi_HFImwSbVgS14RwJYzJW0SEXDUUTEyOnLWA-1795057737-1.2.1.1-aA3uw6_pIPab4YaPlm.0Z8ocEaY8cYC26xv4VscdMVrKym.Vd3vprhgIUUXlRDZx` | Canlı | 200 | text/html, ×2 |
| GET | `https://www.hdfilmcehennemi.nl/hope-2026-hdfc-6/?router=1` | Canlı | 200 | application/json |
| GET | `https://www.hdfilmcehennemi.nl/search` | Canlı | 200 | text/html, ×3 |
| GET | `https://www.hdfilmcehennemi.nl/the-odyssey-3/?router=1` | Canlı | 200 | application/json |
| GET | `https://www.hdfilmcehennemi.nl/yabancidiziizle-15/?router=1` | Canlı | 200 | application/json |
| GET | `https://hdfilmcehennemi.mobi/Tema/v1/js/closeplayer/images/forward15.svg` | Canlı | 200 | image/svg+xml |
| GET | `https://srv12.cdnimages2799.shop/hls/atalentformurder-2026-webdl-tt14129116mp4-UB7gPnxIqGv.mp4/image000.jpg` | Canlı | 200 | image/jpeg |
| GET | `https://srv12.cdnimages2799.shop/hls/atalentformurder-2026-webdl-tt14129116mp4-UB7gPnxIqGv.mp4/image001.jpg` | Canlı | 200 | image/jpeg |
| GET | `https://srv12.cdnimages2799.shop/hls/atalentformurder-2026-webdl-tt14129116mp4-UB7gPnxIqGv.mp4/image002.jpg` | Canlı | 200 | image/jpeg |
| GET | `https://srv12.cdnimages2799.shop/hls/atalentformurder-2026-webdl-tt14129116mp4-UB7gPnxIqGv.mp4/image003.jpg` | Canlı | 200 | image/jpeg |
| GET | `https://srv12.cdnimages2831.shop/hls/atalentformurder-2026-webdl-tt14129116mp4-UB7gPnxIqGv.mp4/image004.jpg` | Canlı | 200 | image/jpeg |
| GET | `https://srv12.cdnimages2831.shop/hls/atalentformurder-2026-webdl-tt14129116mp4-UB7gPnxIqGv.mp4/image005.jpg` | Canlı | 200 | image/jpeg |
| GET | `https://srv12.cdnimages2831.shop/hls/atalentformurder-2026-webdl-tt14129116mp4-UB7gPnxIqGv.mp4/image006.jpg` | Canlı | 200 | image/jpeg |
| GET | `https://srv12.cdnimages2831.shop/hls/atalentformurder-2026-webdl-tt14129116mp4-UB7gPnxIqGv.mp4/image007.jpg` | Canlı | 200 | image/jpeg |
| GET | `https://srv12.cdnimages3469.shop/hls/atalentformurder-2026-webdl-tt14129116mp4-UB7gPnxIqGv.mp4/image008.jpg` | Canlı | 200 | image/jpeg |
| GET | `https://srv12.cdnimages3469.shop/hls/atalentformurder-2026-webdl-tt14129116mp4-UB7gPnxIqGv.mp4/image009.jpg` | Canlı | 200 | image/jpeg |
| GET | `https://srv12.cdnimages3469.shop/hls/atalentformurder-2026-webdl-tt14129116mp4-UB7gPnxIqGv.mp4/image010.jpg` | Canlı | 200 | image/jpeg |
| GET | `https://srv12.cdnimages3469.shop/hls/atalentformurder-2026-webdl-tt14129116mp4-UB7gPnxIqGv.mp4/image011.jpg` | Canlı | 200 | image/jpeg |
| GET | `https://srv12.cdnimages481.cyou/hls/atalentformurder-2026-webdl-tt14129116mp4-UB7gPnxIqGv.mp4/txt/master.txt?s=AREWFpBiOd8w-0tZioAyEgubiThmFEHo8pBOcloO1gIhaa-HTp_rep-o&o=255` | Canlı | 200 | application/vnd.apple.mpegurl |

## Örnek istek gövdeleri

**POST https://www.hdfilmcehennemi.nl/cdn-cgi/challenge-platform/h/b/fo/696520627:1795054826:958OZePgTauydKPHrKCTgTIFMbfU5f6tFbrI4SWHitc/a5cc03683f069715/_vkOjdJi_HFImwSbVgS14RwJYzJW0SEXDUUTEyOnLWA-1795057737-1.2.1.1-aA3uw6_pIPab4YaPlm.0Z8ocEaY8cYC26xv4VscdMVrKym.Vd3vprhgIUUXlRDZx**

```
LJcMxAbR1staH0EBXSLLenLJbUUjYy96MV8fkPbhIICM87n7qcS+TyKJAaIYxGTUF1sSvvon9fUzKo7al$AhTDJlo1RNBDIVD-3mnDSuQkZNOLmHvJ$THhlfPQCRX3QM$Mefo7jJDJOhWPzWstrk0-UWWRYIyNUHUN29ntS+28OTEsp+P-0BkRRZWdNKMdir2J6pKjDHTn0ln7l0kS0PjV06lPHXhLGbDmlCpb9$Mj-nBS2UkaCYlKjNCDo2GB6EOeLVW+c1u7c1Js-XT6ZvbY8-QTmafGBItXNk3w2BMr+IaAJhwXfq06AF0CIgcwxrHh56dgABmaZl232F3$jZb$zA26G5PjkQsbvziWys2nxPB2D1z1uJHvpHMIDUulLByrk0kgCwdJwKh9g+xIf$k0-oHI286SFFzDB2za3pEILEMakdseAmCiCHHTp2ODLX+cdPgp6Z7WgpY10uhFARpYyq$s7U3E6AYjeOYBKRHxyAUYrirDWwwQ0L8MnRFBnwUkSrvmkIe8RnePTsuQlhPk9kNkd5Gkxw7am5gOyFu0W7j3vP9SIOC5vFt3+sKqLS-hd6mxiBvVkDE5LPZZUG0un3
```

**POST https://hdfilmcehennemi.mobi/video/embed/UB7gPnxIqGv/ah/**

```
hash=ee424afeb1dc9c1a4ba6cfca1061581b&e=255
```

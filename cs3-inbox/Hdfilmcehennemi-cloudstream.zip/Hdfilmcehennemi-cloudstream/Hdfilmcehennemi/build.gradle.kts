// Sürüm numarası tam sayı olmalı; her güncellemede artır
version = 1

cloudstream {
    description = "www.hdfilmcehennemi.nl için CloudStream eklentisi"
    authors = listOf("Kalkan")

    /**
     * Durum:
     * 0: Çalışmıyor
     * 1: Çalışıyor
     * 2: Yavaş
     * 3: Sadece beta
     */
    status = 1

    tvTypes = listOf("Movie", "TvSeries", "Anime", "AsianDrama", "Cartoon", "Documentary", "Live", "Others")
    language = "tr"
    iconUrl = "https://www.google.com/s2/favicons?domain=hdfilmcehennemi.nl&sz=%size%"
}

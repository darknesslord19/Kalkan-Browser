package com.darkness.hdabla

/**
 * Darkness Tarayıcı'nın hdabla.net üzerinde bulduğu API uçları (20.11.2026 03:59).
 * Aynı sitedeki uçlar mainUrl'e göre göreli yazılmıştır: "$mainUrl" + SABIT
 */
@Suppress("unused")
object HdablaEndpoints {
    // Henüz uç bulunamadı. Araçlar → API uçları ile sayfada gezinip tekrar dışa aktar.
}

# Donkey — bulunan uçlar

Kalkan Tarayıcı · 19.11.2026 16:53 · https://donkey.to

| Yöntem | Adres | Kaynak | Durum | Not |
|---|---|---|---|---|
| GET | `https://api.themoviedb.org/3/configuration/countries?language=en-US` | Canlı | 200 | application/json |
| GET | `https://api.themoviedb.org/3/genre/movie/list?language=en-US` | Canlı | 200 | application/json |
| GET | `https://api.themoviedb.org/3/movie/1131943/images?api_key=xcKhS-fpOJRsp0vBPfYaZHHkS7pFXQTLhG81K-28O48` | Canlı | 200 | application/json, ×5 |
| GET | `https://api.themoviedb.org/3/movie/1400837?language=en-US` | Canlı | 200 | application/json, ×98 |
| GET | `https://api.themoviedb.org/3/movie/tt10545296?language=en-US` | Canlı | 200 | application/json |
| GET | `https://api.themoviedb.org/3/movie/tt1392170?language=en-US` | Canlı | 200 | application/json |
| GET | `https://api.themoviedb.org/3/movie/tt1951264?language=en-US` | Canlı | 200 | application/json |
| GET | `https://api.themoviedb.org/3/movie/tt1951265?language=en-US` | Canlı | 200 | application/json |
| GET | `https://api.themoviedb.org/3/movie/tt21285562?language=en-US` | Canlı | 200 | application/json |
| GET | `https://api.themoviedb.org/3/movie/tt22084616?language=en-US` | Canlı | 200 | application/json |
| GET | `https://api.themoviedb.org/3/movie/tt24818230?language=en-US` | Canlı | 200 | application/json |
| GET | `https://api.themoviedb.org/3/movie/tt27165187?language=en-US` | Canlı | 200 | application/json |
| GET | `https://api.themoviedb.org/3/movie/tt29256561?language=en-US` | Canlı |  |  |
| GET | `https://api.themoviedb.org/3/movie/tt32261958?language=en-US` | Canlı |  |  |
| GET | `https://api.themoviedb.org/3/movie/tt32558705?language=en-US` | Canlı | 200 | application/json |
| GET | `https://api.themoviedb.org/3/movie/tt33764258?language=en-US` | Canlı | 200 | application/json |
| GET | `https://api.themoviedb.org/3/movie/tt34206385?language=en-US` | Canlı | 200 | application/json |
| GET | `https://api.themoviedb.org/3/movie/tt35538033?language=en-US` | Canlı | 200 | application/json |
| GET | `https://api.themoviedb.org/3/movie/tt36586020?language=en-US` | Canlı | 200 | application/json |
| GET | `https://api.themoviedb.org/3/movie/tt37287335?language=en-US` | Canlı | 200 | application/json |
| GET | `https://api.themoviedb.org/3/movie/tt38213251?language=en-US` | Canlı | 200 | application/json |
| GET | `https://api.themoviedb.org/3/movie/tt4154796?language=en-US` | Canlı |  |  |
| GET | `https://api.themoviedb.org/3/movie/tt6611324?language=en-US` | Canlı | 200 | application/json |
| GET | `https://api.themoviedb.org/3/movie/tt7526136?language=en-US` | Canlı | 200 | application/json |
| GET | `https://api.themoviedb.org/3/trending/movie/day?language=en-US&limit=10` | Canlı | 200 | application/json |
| GET | `https://api.themoviedb.org/3/trending/tv/day?language=en-US&limit=10` | Canlı | 200 | application/json |
| GET | `https://api.themoviedb.org/3/tv/247718?language=en-US` | Canlı | 200 | application/json, ×63 |
| GET | `https://api.themoviedb.org/3/tv/288120/images?api_key=xcKhS-fpOJRsp0vBPfYaZHHkS7pFXQTLhG81K-28O48` | Canlı | 200 | application/json, ×5 |
| GET | `https://api.trakt.tv/movies/popular?limit=50` | Canlı | 200 | application/json |
| GET | `https://api.trakt.tv/movies/trending?limit=24` | Canlı | 200 | application/json, ×2 |
| GET | `https://api.trakt.tv/shows/trending?limit=50` | Canlı | 200 | application/json |
| GET | `https://donkey.to/featured?mediaType=movie&_rsc=1wtp7` | Canlı | 200 | text/x-component, ×2 |
| GET | `https://donkey.to/media/movie?_rsc=1wtp7` | Canlı | 200 | text/x-component |
| GET | `https://donkey.to/media/tv?_rsc=1wtp7` | Canlı | 200 | text/x-component |
| GET | `https://www.donkey.to/api/cached/imdb-rating?mediaId=1616687&mediaType=movie` | Canlı | 200 | application/json, ×62 |

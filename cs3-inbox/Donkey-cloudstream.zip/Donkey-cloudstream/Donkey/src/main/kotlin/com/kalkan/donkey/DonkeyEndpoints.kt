package com.kalkan.donkey

/**
 * Kalkan Tarayıcı'nın donkey.to üzerinde bulduğu API uçları (19.11.2026 16:49).
 * Aynı sitedeki uçlar mainUrl'e göre göreli yazılmıştır: "$mainUrl" + SABIT
 */
@Suppress("unused")
object DonkeyEndpoints {
    /** GET · Canlı · 200 · application/json */
    const val CONFIGURATION_COUNTRIES = "https://api.themoviedb.org/3/configuration/countries?language=en-US"
    /** GET · Canlı · 200 · application/json */
    const val GENRE_MOVIE_LIST = "https://api.themoviedb.org/3/genre/movie/list?language=en-US"
    /** GET · Canlı · 200 · application/json */
    const val MOVIE_IMAGES = "https://api.themoviedb.org/3/movie/1131943/images?api_key=xcKhS-fpOJRsp0vBPfYaZHHkS7pFXQTLhG81K-28O48"
    /** GET · Canlı · 200 · application/json */
    const val MOVIE = "https://api.themoviedb.org/3/movie/1400837?language=en-US"
    /** GET · Canlı · 200 · application/json */
    const val MOVIE_TT10545296 = "https://api.themoviedb.org/3/movie/tt10545296?language=en-US"
    /** GET · Canlı · 200 · application/json */
    const val MOVIE_TT1392170 = "https://api.themoviedb.org/3/movie/tt1392170?language=en-US"
    /** GET · Canlı · 200 · application/json */
    const val MOVIE_TT1951264 = "https://api.themoviedb.org/3/movie/tt1951264?language=en-US"
    /** GET · Canlı · 200 · application/json */
    const val MOVIE_TT1951265 = "https://api.themoviedb.org/3/movie/tt1951265?language=en-US"
    /** GET · Canlı · 200 · application/json */
    const val MOVIE_TT21285562 = "https://api.themoviedb.org/3/movie/tt21285562?language=en-US"
    /** GET · Canlı · 200 · application/json */
    const val MOVIE_TT22084616 = "https://api.themoviedb.org/3/movie/tt22084616?language=en-US"
    /** GET · Canlı · 200 · application/json */
    const val MOVIE_TT24818230 = "https://api.themoviedb.org/3/movie/tt24818230?language=en-US"
    /** GET · Canlı · 200 · application/json */
    const val MOVIE_TT27165187 = "https://api.themoviedb.org/3/movie/tt27165187?language=en-US"
    /** GET · Canlı */
    const val MOVIE_TT29256561 = "https://api.themoviedb.org/3/movie/tt29256561?language=en-US"
    /** GET · Canlı */
    const val MOVIE_TT32261958 = "https://api.themoviedb.org/3/movie/tt32261958?language=en-US"
    /** GET · Canlı · 200 · application/json */
    const val MOVIE_TT32558705 = "https://api.themoviedb.org/3/movie/tt32558705?language=en-US"
    /** GET · Canlı · 200 · application/json */
    const val MOVIE_TT33764258 = "https://api.themoviedb.org/3/movie/tt33764258?language=en-US"
    /** GET · Canlı · 200 · application/json */
    const val MOVIE_TT34206385 = "https://api.themoviedb.org/3/movie/tt34206385?language=en-US"
    /** GET · Canlı · 200 · application/json */
    const val MOVIE_TT35538033 = "https://api.themoviedb.org/3/movie/tt35538033?language=en-US"
    /** GET · Canlı · 200 · application/json */
    const val MOVIE_TT36586020 = "https://api.themoviedb.org/3/movie/tt36586020?language=en-US"
    /** GET · Canlı · 200 · application/json */
    const val MOVIE_TT37287335 = "https://api.themoviedb.org/3/movie/tt37287335?language=en-US"
    /** GET · Canlı · 200 · application/json */
    const val MOVIE_TT38213251 = "https://api.themoviedb.org/3/movie/tt38213251?language=en-US"
    /** GET · Canlı */
    const val MOVIE_TT4154796 = "https://api.themoviedb.org/3/movie/tt4154796?language=en-US"
    /** GET · Canlı · 200 · application/json */
    const val MOVIE_TT6611324 = "https://api.themoviedb.org/3/movie/tt6611324?language=en-US"
    /** GET · Canlı · 200 · application/json */
    const val MOVIE_TT7526136 = "https://api.themoviedb.org/3/movie/tt7526136?language=en-US"
    /** GET · Canlı · 200 · application/json */
    const val TRENDING_MOVIE_DAY = "https://api.themoviedb.org/3/trending/movie/day?language=en-US&limit=10"
    /** GET · Canlı · 200 · application/json */
    const val TRENDING_TV_DAY = "https://api.themoviedb.org/3/trending/tv/day?language=en-US&limit=10"
    /** GET · Canlı · 200 · application/json */
    const val TV = "https://api.themoviedb.org/3/tv/247718?language=en-US"
    /** GET · Canlı · 200 · application/json */
    const val TV_IMAGES = "https://api.themoviedb.org/3/tv/288120/images?api_key=xcKhS-fpOJRsp0vBPfYaZHHkS7pFXQTLhG81K-28O48"
    /** GET · Canlı · 200 · application/json */
    const val MOVIES_POPULAR = "https://api.trakt.tv/movies/popular?limit=50"
    /** GET · Canlı · 200 · application/json */
    const val MOVIES_TRENDING = "https://api.trakt.tv/movies/trending?limit=24"
    /** GET · Canlı · 200 · application/json */
    const val SHOWS_TRENDING = "https://api.trakt.tv/shows/trending?limit=50"
    /** GET · Canlı · 200 · text/x-component */
    const val FEATURED = "/featured?mediaType=movie&_rsc=1wtp7"
    /** GET · Canlı · 200 · text/x-component */
    const val MEDIA_MOVIE = "/media/movie?_rsc=1wtp7"
    /** GET · Canlı · 200 · text/x-component */
    const val MEDIA_TV = "/media/tv?_rsc=1wtp7"
    /** GET · Canlı · 200 · application/json */
    const val API_CACHED_IMDB_RATING = "https://www.donkey.to/api/cached/imdb-rating?mediaId=1616687&mediaType=movie"
}

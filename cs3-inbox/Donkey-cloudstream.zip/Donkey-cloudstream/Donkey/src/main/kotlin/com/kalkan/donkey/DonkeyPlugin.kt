package com.kalkan.donkey

import android.content.Context
import com.lagradost.cloudstream3.plugins.CloudstreamPlugin
import com.lagradost.cloudstream3.plugins.Plugin

@CloudstreamPlugin
class DonkeyPlugin : Plugin() {
    override fun load(context: Context) {
        // Bu eklentinin sağlayıcılarını CloudStream'e kaydeder
        registerMainAPI(DonkeyProvider())
    }
}

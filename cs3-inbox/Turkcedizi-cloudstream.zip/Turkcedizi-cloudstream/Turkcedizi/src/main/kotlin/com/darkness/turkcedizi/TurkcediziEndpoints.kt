package com.darkness.turkcedizi

/**
 * Darkness Tarayıcı'nın turkcedizi.com üzerinde bulduğu API uçları (21.11.2026 18:50).
 * Aynı sitedeki uçlar mainUrl'e göre göreli yazılmıştır: "$mainUrl" + SABIT
 */
@Suppress("unused")
object TurkcediziEndpoints {
    // Henüz uç bulunamadı. Araçlar → API uçları ile sayfada gezinip tekrar dışa aktar.
}

Bu eklenti Darkness bilgi bankasındaki çalışan referans kaynaktan üretildi (dizipal2150.com).

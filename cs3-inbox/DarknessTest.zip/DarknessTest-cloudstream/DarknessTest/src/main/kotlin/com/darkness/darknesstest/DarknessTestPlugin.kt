package com.darkness.darknesstest

import android.content.Context
import com.lagradost.cloudstream3.plugins.CloudstreamPlugin
import com.lagradost.cloudstream3.plugins.Plugin

@CloudstreamPlugin
class DarknessTestPlugin : Plugin() {
    override fun load(context: Context) {
        registerMainAPI(DarknessTest())
    }
}

package com.darkness.darknesstest

import android.util.Log
import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.network.CloudflareKiller
import com.lagradost.cloudstream3.utils.*
import com.lagradost.nicehttp.NiceResponse
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.net.URLEncoder

/**
 * DarknessTest — darkness_uretici.py ile 2026-11-20 tarihinde https://ornek.test analiz edilerek üretildi.
 *
 * Site değişirse önce aşağıdaki "ANALİZ SONUÇLARI" bölümündeki seçicileri güncelle.
 * Oynatma sırası: sayfadaki doğrudan m3u8/mp4 → gömülü oynatıcılar (iframe, data-*,
 * DooPlay) → CloudStream extractor'ları → oynatıcı sayfasında m3u8 arama →
 * gerçek tarayıcı (WebViewResolver) son çare olarak.
 */
class DarknessTest : MainAPI() {
    override var mainUrl = "https://ornek.test"
    override var name = "DarknessTest"
    override val hasMainPage = true
    override var lang = "tr"
    override val hasQuickSearch = false
    override val supportedTypes = setOf(TvType.Movie)

    // ------------------------------------------------------------ ANALİZ SONUÇLARI
    /** Liste/arama sayfasındaki tek bir içerik kartı. */
    private val cardSelector = "article.item"
    /** Kart içinde başlık (sırayla denenir; yoksa a[title] / img[alt]). */
    private val titleSelectors = listOf("h2")
    /** Afiş resminin adresinin bulunduğu özellikler (sırayla). */
    private val posterAttrs = listOf("data-src", "data-lazy-src", "data-original", "data-srcset", "srcset", "src")
    /** Arama adresi: {q} = aranan kelime. Boşsa arama kapalı. */
    private val searchUrl = ""
    /** Sayfalama: {url} = liste adresi, {page} = sayfa no. Boşsa tek sayfa. */
    private val pagePattern = ""
    /** Dizi sayfasındaki bölüm linkleri. */
    private val episodeSelector = ""
    /** Adreste bunlar geçiyorsa film / dizi kabul edilir. */
    private val movieHints = listOf("/film/")
    private val seriesHints = listOf()
    /** WordPress DooPlay teması (admin-ajax.php doo_player_ajax). */
    private val useDooPlay = false

    override val mainPage = mainPageOf(
        "$mainUrl/" to "Son Eklenenler",
        "$mainUrl/filmler/" to "Filmler"
    )

    // ------------------------------------------------------------ ağ
    private val ua =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36"
    private val cfKiller by lazy { CloudflareKiller() }

    private fun headers(referer: String = "$mainUrl/") = mapOf(
        "User-Agent" to ua,
        "Accept" to "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language" to "tr-TR,tr;q=0.9,en;q=0.7",
        "Referer" to referer,
    )

    private fun isChallenge(code: Int, body: String): Boolean =
        code in setOf(403, 429, 503) && (
            body.contains("Just a moment", true) || body.contains("cf-chl", true) ||
                body.contains("challenge-platform", true) || body.contains("cf_chl_opt", true)
            )

    /** GET; Cloudflare engeli görülürse bir kez CloudflareKiller ile yeniden dener. */
    private suspend fun get(url: String, referer: String = "$mainUrl/"): NiceResponse {
        val r = app.get(url, headers = headers(referer))
        if (!isChallenge(r.code, r.text)) return r
        Log.w(TAG, "CF_BLOCK code=${r.code} $url")
        return runCatching { app.get(url, headers = headers(referer), interceptor = cfKiller) }.getOrDefault(r)
    }

    // ------------------------------------------------------------ yardımcılar
    private fun abs(u: String?): String? {
        val s = u?.trim()?.replace("\\/", "/")?.takeIf {
            it.isNotBlank() && !it.startsWith("data:") && !it.startsWith("javascript", true) && !it.startsWith("#")
        } ?: return null
        val root = mainUrl.trimEnd('/')
        return when {
            s.startsWith("http://") || s.startsWith("https://") -> s
            s.startsWith("//") -> "https:$s"
            s.startsWith("/") -> root + s
            else -> "$root/$s"
        }
    }

    private fun originOf(u: String): String =
        Regex("""^(https?://[^/]+)""").find(u)?.groupValues?.getOrNull(1) ?: u

    private fun hostOf(u: String): String = originOf(u).substringAfter("://")

    private fun absTo(base: String, u: String): String {
        val s = u.trim().replace("\\/", "/")
        return when {
            s.startsWith("http://") || s.startsWith("https://") -> s
            s.startsWith("//") -> "https:$s"
            s.startsWith("/") -> originOf(base) + s
            else -> runCatching { java.net.URI(base).resolve(s).toString() }.getOrDefault(s)
        }
    }

    private fun Element.posterUrl(): String? {
        val img = if (tagName() == "img") this else (selectFirst("img") ?: return null)
        for (a in posterAttrs) {
            val v = img.attr(a).trim()
            if (v.isBlank()) continue
            val first = if (a.endsWith("srcset")) v.split(",").first().trim().split(" ").first() else v
            abs(first)?.let { return it }
        }
        return null
    }

    private fun isSeriesUrl(u: String) = seriesHints.any { u.contains(it, true) }
    private fun isMovieUrl(u: String) = movieHints.any { u.contains(it, true) }

    private fun Element.toCard(): SearchResponse? {
        val a = if (tagName() == "a") this else (selectFirst("a[href]") ?: return null)
        val href = abs(a.attr("href")) ?: return null
        val title = titleSelectors.firstNotNullOfOrNull { sel ->
            runCatching { selectFirst(sel) }.getOrNull()?.text()?.trim()?.takeIf { it.isNotBlank() }
        }
            ?: a.attr("title").trim().takeIf { it.isNotBlank() }
            ?: selectFirst("img")?.attr("alt")?.trim()?.takeIf { it.isNotBlank() }
            ?: return null
        val poster = posterUrl()
        val year = Regex("""\b(19|20)\d{2}\b""").find(text())?.value?.toIntOrNull()
        return if (isSeriesUrl(href) && !isMovieUrl(href)) {
            newTvSeriesSearchResponse(title, href, TvType.TvSeries) { posterUrl = poster; this.year = year }
        } else {
            newMovieSearchResponse(title, href, TvType.Movie) { posterUrl = poster; this.year = year }
        }
    }

    private fun Document.cards(): List<SearchResponse> =
        select(cardSelector).mapNotNull { it.toCard() }.distinctBy { it.url }

    private fun pagedUrl(base: String, page: Int): String {
        if (page <= 1 || pagePattern.isBlank()) return base
        val b = base.trimEnd('/')
        var p = pagePattern
        if (b.contains('?') && p.startsWith("{url}?")) p = p.replaceFirst("{url}?", "{url}&")
        return p.replace("{url}", b).replace("{page}", page.toString())
    }

    // ------------------------------------------------------------ ana sayfa / arama
    override suspend fun getMainPage(page: Int, request: MainPageRequest): HomePageResponse {
        if (page > 1 && pagePattern.isBlank()) {
            return newHomePageResponse(request.name, emptyList<SearchResponse>(), hasNext = false)
        }
        val url = pagedUrl(request.data, page)
        val items = runCatching { get(url).document.cards() }
            .onFailure { Log.e(TAG, "MAIN_ERR $url ${it.message}") }
            .getOrDefault(emptyList())
        Log.i(TAG, "MAIN ${request.name} page=$page items=${items.size} url=$url")
        return newHomePageResponse(request.name, items, hasNext = items.isNotEmpty() && pagePattern.isNotBlank())
    }

    override suspend fun search(query: String): List<SearchResponse> {
        if (searchUrl.isBlank()) return emptyList()
        val q = URLEncoder.encode(query.trim(), "UTF-8")
        val url = searchUrl.replace("{q}", q)
        val items = runCatching { get(url).document.cards() }
            .onFailure { Log.e(TAG, "SEARCH_ERR $url ${it.message}") }
            .getOrDefault(emptyList())
        Log.i(TAG, "SEARCH '$query' items=${items.size}")
        return items
    }

    // ------------------------------------------------------------ detay
    private val seasonRes = listOf(
        Regex("""(\d+)\s*[-_.]?\s*sezon""", RegexOption.IGNORE_CASE),
        Regex("""sezon\s*[-_]?\s*(\d+)""", RegexOption.IGNORE_CASE),
        Regex("""season\s*[-_]?\s*(\d+)""", RegexOption.IGNORE_CASE),
        Regex("""\b[sS](\d{1,2})[eE]\d{1,3}\b"""),
    )
    private val episodeRes = listOf(
        Regex("""(\d+)\s*[-_.]?\s*b[öo]l[üu]m""", RegexOption.IGNORE_CASE),
        Regex("""b[öo]l[üu]m\s*[-_]?\s*(\d+)""", RegexOption.IGNORE_CASE),
        Regex("""episode\s*[-_]?\s*(\d+)""", RegexOption.IGNORE_CASE),
        Regex("""\b[sS]\d{1,2}[eE](\d{1,3})\b"""),
    )

    private fun firstNum(res: List<Regex>, vararg texts: String): Int? =
        texts.firstNotNullOfOrNull { t ->
            res.firstNotNullOfOrNull { it.find(t)?.groupValues?.getOrNull(1)?.toIntOrNull() }
        }

    override suspend fun load(url: String): LoadResponse? {
        val doc = get(url).document
        val rawTitle = doc.selectFirst("h1")?.text()?.trim()?.takeIf { it.isNotBlank() }
            ?: doc.selectFirst("meta[property=og:title]")?.attr("content")?.trim()?.takeIf { it.isNotBlank() }
            ?: doc.title()
        val title = rawTitle
            .replace(Regex("""\s*[-|–]\s*[^-|–]*$"""), "")
            .replace(Regex("""\s+(izle|full hd izle|türkçe dublaj izle|altyazılı izle)\s*$""", RegexOption.IGNORE_CASE), "")
            .trim().ifBlank { rawTitle }
        val poster = abs(doc.selectFirst("meta[property=og:image]")?.attr("content"))
            ?: doc.selectFirst(".poster img, .film-poster img, img[class*=poster], .thumb img")?.posterUrl()
        val plot = doc.selectFirst("meta[property=og:description], meta[name=description]")?.attr("content")?.trim()
        val year = Regex("""\b(19|20)\d{2}\b""")
            .find(doc.select(".year, .date, .meta, .info, .details, [class*=year]").text())?.value?.toIntOrNull()
        val tags = doc.select("a[href*=/tur/], a[href*=/kategori/], a[href*=/genre/], a[href*=/category/], a[rel=tag]")
            .map { it.text().trim() }.filter { it.isNotBlank() && it.length < 30 }.distinct().take(8)

        val seen = HashSet<String>()
        val episodes = if (episodeSelector.isBlank()) emptyList() else doc.select(episodeSelector).mapNotNull { a ->
            val href = abs(a.attr("href")) ?: return@mapNotNull null
            if (href.trimEnd('/') == url.trimEnd('/') || !seen.add(href.trimEnd('/'))) return@mapNotNull null
            val text = a.text().trim()
            newEpisode(href) {
                this.season = firstNum(seasonRes, href, text) ?: 1
                this.episode = firstNum(episodeRes, href, text)
                this.name = a.attr("title").trim().ifBlank { text }.takeIf { it.isNotBlank() && it.length < 90 }
                this.posterUrl = a.posterUrl()
            }
        }.sortedWith(compareBy<Episode>({ it.season ?: 0 }, { it.episode ?: 0 }))

        Log.i(TAG, "LOAD $url episodes=${episodes.size}")
        if (episodes.isNotEmpty() || (isSeriesUrl(url) && !isMovieUrl(url))) {
            val eps = episodes.ifEmpty { listOf(newEpisode(url) { this.name = title }) }
            return newTvSeriesLoadResponse(title, url, TvType.TvSeries, eps) {
                this.posterUrl = poster; this.plot = plot; this.year = year; this.tags = tags
            }
        }
        return newMovieLoadResponse(title, url, TvType.Movie, url) {
            this.posterUrl = poster; this.plot = plot; this.year = year; this.tags = tags
        }
    }

    // ------------------------------------------------------------ oynatma
    private val fileRe = Regex(
        """["']?(?:file|src|source|url|hls)["']?\s*[:=]\s*["']([^"']+?\.(?:m3u8|mp4)(?:\?[^"']*)?)["']""",
        RegexOption.IGNORE_CASE,
    )
    private val mediaRe = Regex(
        """(?:https?:)?//[^\s"'<>\\]+?\.(?:m3u8|mp4)(?:\?[^\s"'<>\\]*)?""",
        RegexOption.IGNORE_CASE,
    )
    private val subRe = Regex(
        """["']?file["']?\s*:\s*["']([^"']+\.(?:vtt|srt)[^"']*)["'][^{}]*?["']?label["']?\s*:\s*["']([^"']+)["']""",
        RegexOption.IGNORE_CASE,
    )
    private val iframeJunk = listOf(
        "googletagmanager", "recaptcha", "facebook.com", "disqus", "twitter.com", "doubleclick",
        "youtube.com/embed", "youtube-nocookie", "instagram.com",
    )

    private fun unpacked(html: String): String = buildString {
        append(html.replace("\\/", "/"))
        if (html.contains("eval(function(p,a,c,k,e,")) {
            runCatching { getAndUnpack(html) }.getOrNull()?.let { append('\n').append(it.replace("\\/", "/")) }
        }
    }

    private fun mediaIn(html: String, base: String): List<String> {
        val text = unpacked(html)
        val out = LinkedHashSet<String>()
        fileRe.findAll(text).forEach { out += absTo(base, it.groupValues[1]) }
        mediaRe.findAll(text).forEach { out += absTo(base, it.value) }
        return out.filter {
            it.startsWith("http") && !it.contains("thumb", true) && !it.contains("preview", true) &&
                !it.contains("/ads", true) && !it.contains("trailer", true)
        }
    }

    private fun embedsIn(doc: Document): List<String> {
        val out = LinkedHashSet<String>()
        doc.select("iframe").forEach { f ->
            listOf("src", "data-src", "data-lazy-src").map { f.attr(it).trim() }
                .firstOrNull { it.isNotBlank() && !it.startsWith("about:") }
                ?.let { abs(it) }?.let { out += it }
        }
        val keys = listOf("data-iframe", "data-embed", "data-video", "data-link", "data-url", "data-frame", "data-src")
        doc.select("[data-iframe], [data-embed], [data-video], [data-link], [data-url], [data-frame]").forEach { e ->
            keys.map { e.attr(it).trim() }
                .filter { (it.startsWith("http") || it.startsWith("//")) && !Regex("""\.(jpe?g|png|webp|gif)(\?|$)""", RegexOption.IGNORE_CASE).containsMatchIn(it) }
                .forEach { u -> abs(u)?.let { out += it } }
        }
        return out.filter { u -> iframeJunk.none { u.contains(it, true) } }
    }

    private suspend fun dooPlayEmbeds(doc: Document, pageUrl: String): List<String> {
        val out = ArrayList<String>()
        for (o in doc.select("li.dooplay_player_option[data-post], li[data-post][data-nume][data-type]")) {
            val nume = o.attr("data-nume")
            if (nume.equals("trailer", true)) continue
            val r = runCatching {
                app.post(
                    "$mainUrl/wp-admin/admin-ajax.php",
                    data = mapOf(
                        "action" to "doo_player_ajax", "post" to o.attr("data-post"),
                        "nume" to nume, "type" to o.attr("data-type"),
                    ),
                    headers = headers(pageUrl) + ("X-Requested-With" to "XMLHttpRequest"),
                ).text
            }.getOrNull() ?: continue
            val embed = Regex(""""embed_url"\s*:\s*"([^"]+)"""").find(r)?.groupValues?.get(1)?.replace("\\/", "/")
                ?: continue
            val src = if (embed.contains("<iframe", true)) {
                Regex("""src=["']([^"']+)["']""").find(embed)?.groupValues?.get(1)
            } else embed
            abs(src)?.let { out += it }
        }
        Log.i(TAG, "DOOPLAY embeds=${out.size}")
        return out
    }

    private suspend fun emitMedia(url: String, referer: String, callback: (ExtractorLink) -> Unit) {
        val isHls = url.contains(".m3u8", true)
        callback(
            newExtractorLink(name, name, url, if (isHls) ExtractorLinkType.M3U8 else ExtractorLinkType.VIDEO) {
                this.referer = referer
                this.quality = Qualities.Unknown.value
                this.headers = mapOf("User-Agent" to ua, "Referer" to referer, "Origin" to originOf(referer))
            }
        )
    }

    /** Son çare: embed sayfasını gerçek tarayıcıda (WebView) açıp ağdaki m3u8/mp4 isteğini yakalar. */
    private suspend fun browserFallback(embed: String, pageUrl: String, callback: (ExtractorLink) -> Unit): Boolean {
        val re = Regex("""\.(m3u8|mp4)(\?|$)""", RegexOption.IGNORE_CASE)
        val got = runCatching {
            app.get(embed, referer = pageUrl, interceptor = com.lagradost.cloudstream3.network.WebViewResolver(re)).url
        }.getOrNull() ?: return false
        if (!re.containsMatchIn(got)) return false
        emitMedia(got, embed, callback)
        return true
    }

    override suspend fun loadLinks(
        data: String,
        isCasting: Boolean,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        val res = get(data)
        val doc = res.document
        var found = 0

        // 1) Sayfada doğrudan yayın adresi
        mediaIn(res.text, data).forEach { emitMedia(it, data, callback); found++ }

        // 2) Gömülü oynatıcılar
        val embeds = LinkedHashSet<String>()
        embeds += embedsIn(doc)
        if (useDooPlay || doc.selectFirst("li.dooplay_player_option") != null) embeds += dooPlayEmbeds(doc, data)
        Log.i(TAG, "LINKS page=$data direct=$found embeds=${embeds.size} hosts=${embeds.map { hostOf(it) }}")

        for (e in embeds) {
            val bare = e.substringBefore('?')
            if (bare.endsWith(".m3u8", true) || bare.endsWith(".mp4", true)) {
                emitMedia(e, data, callback); found++; continue
            }
            var got = false
            // 2a) CloudStream'in hazır extractor'ları (bilinen video sunucuları)
            runCatching { loadExtractor(e, data, subtitleCallback) { link -> got = true; callback(link) } }
            // 2b) Tanınmayan oynatıcı: sayfasında m3u8/mp4 ara (packed JS dahil)
            if (!got) {
                val html = runCatching { app.get(e, headers = headers(data)).text }.getOrNull().orEmpty()
                val media = mediaIn(html, e)
                media.forEach { emitMedia(it, e, callback) }
                subRe.findAll(unpacked(html)).forEach {
                    subtitleCallback(newSubtitleFile(it.groupValues[2], absTo(e, it.groupValues[1])))
                }
                got = media.isNotEmpty()
                Log.i(TAG, "EMBED ${hostOf(e)} media=${media.size}")
            }
            // 2c) Hiçbiri tutmadıysa gerçek tarayıcıda (WebView) yayını yakala
            if (!got) got = browserFallback(e, data, callback)
            if (got) found++
        }
        Log.i(TAG, "LINKS_DONE found=$found embeds=${embeds.size}")
        return found > 0
    }

    companion object {
        private const val TAG = "DARKNESSTEST"
    }
}

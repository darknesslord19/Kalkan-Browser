package com.kalkan.fullhdfilmizlesene

/**
 * Kalkan Tarayıcı'nın www.fullhdfilmizlesene.now üzerinde bulduğu API uçları (19.11.2026 17:37).
 * Aynı sitedeki uçlar mainUrl'e göre göreli yazılmıştır: "$mainUrl" + SABIT
 */
@Suppress("unused")
object FullhdfilmizleseneEndpoints {
    /** POST · Canlı */
    const val POST_G_COLLECT = "https://www.google-analytics.com/g/collect?v=2&tid=G-ZRR1WHXHVX&gtm=45je6bi0h2v9227274004za208zd9227274004xf1&_p=1795098981507&gcd=13l3l3l3l1l1&npa=0&dma=0&_eu=AAAAAAQ&cid=1604058359.1795057254&frm=0&ngs=1&pscdl=noapi&rcb=13&sr=407x904&uaa=&uab=&uafvl=&uam=&uamb=1&uap=Android&uapv=&uaw=0&ul=tr-tr&_s=1&tag_exp=115938465~115938469~118897920~118897930~120213116~120385422~120469145~120469153~121246026~121246034&sid=1795093824&sct=2&seg=1&dl=https%3A%2F%2Fwww.fullhdfilmizlesene.now%2F&dt=Film%20%C4%B0zle%20%7C%20Full%20HD%20Filmler%20%7C%20FullHDFilmizlesene&en=page_view&_ee=1&tfd=6022"
}

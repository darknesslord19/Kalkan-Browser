package com.kalkan.fullhdfilmizlesene

/**
 * Kalkan Tarayıcı'nın www.fullhdfilmizlesene.now üzerinde bulduğu API uçları (19.11.2026 06:35).
 * Aynı sitedeki uçlar mainUrl'e göre göreli yazılmıştır: "$mainUrl" + SABIT
 */
@Suppress("unused")
object FullhdfilmizleseneEndpoints {
    /** GET · Canlı · 200 · application/x-mpegURL */
    const val FF = "https://i1.pictabox.org/ff/NRDP0CU0bNQf0ZQ0lNwZmNgmYkfFYHAFit88h2z3NjOX9llD_dlZyxYZu8Xvr1b720"
    /** GET · Canlı · 200 · application/x-mpegURL */
    const val FL = "https://i1.pictabox.org/fl/NRDP0CU0bNQf0ZQ0lNwZmNgmYkfFYHAFit88h2z3NjOX9llD_dlZyxYZu8Xvr1"
    /** GET · Canlı · 200 · application/json */
    const val VOD_JW_8_38_10_TRANSLATIONS_TR_JSON = "https://vidmoxy.net/ifr/vod/jw-8.38.10/translations/tr.json"
}

package com.kalkan.fullhdfilmizlesene

/**
 * Kalkan Tarayıcı'nın www.fullhdfilmizlesene.now üzerinde bulduğu API uçları (19.11.2026 16:13).
 * Aynı sitedeki uçlar mainUrl'e göre göreli yazılmıştır: "$mainUrl" + SABIT
 */
@Suppress("unused")
object FullhdfilmizleseneEndpoints {
    /** POST · Canlı */
    const val POST_IFR_VOD_PLAYER_EVENT_PHP = "https://rapidvid.org/ifr/vod/player_event.php"
    /** GET · Canlı · 200 · text/html */
    const val VOD_V1X94213FAE = "https://rapidvid.org/vod/v1x94213fae?c=1"
    /** POST · Canlı · 200 · application/json */
    const val POST_WATCH_STATS_PHP = "https://rapidvid.org/watch-stats.php"
    // Örnek gövde: sid=53c59801a8517c54b2076c4412abf885&token=eyJjaCI6IjY4YzgyMzAwOWZkOGM5NmYyOGZmYTAyYmU4MTYxMDdlMWRmYzg2YTQwYjM0MjU1MWVlMjZiNmY0NjRjODY1ZGUiLCJkIjoibGg0U3FSNWQ4N
    /** GET · Canlı · 200 · application/x-mpegURL */
    const val MC = "https://s1.cdnimg8663.shop/mc/E3IupzEcozphH3EupaZhZwNlAv5KEHVgERjhZGN4ZUNhESIOGP5VYwV2AP1VER0d0zxL2EhnJ1aBQL2Zl5mnT9js0xi1vr1b720"
    /** GET · Canlı · 200 · application/x-mpegURL */
    const val MD = "https://s1.cdnimg8663.shop/md/E3IupzEcozphH3EupaZhZwNlAv5KEHVgERjhZGN4ZUNhESIOGP5VYwV2AP1VER0d0zxL2EhnJ1aBQL2Zl5mnT9js0xi1vr1b1080l0tra1"
    /** GET · Canlı · 200 · application/x-mpegURL */
    const val MK = "https://s1.cdnimg8663.shop/mk/E3IupzEcozphH3EupaZhZwNlAv5KEHVgERjhZGN4ZUNhESIOGP5VYwV2AP1VER0d0zxL2EhnJ1aBQL2Zl5mnT9js0xi1avr1"
    /** GET · Canlı · 200 · text/vtt */
    const val U_94213FAE_1_VTT = "https://subs.rapidvid.org/94213fae/4984907733bebc8f/1.vtt"
    /** GET · Canlı · 200 · text/vtt */
    const val U_94213FAE_2_VTT = "https://subs.rapidvid.org/94213fae/4984907733bebc8f/2.vtt"
    /** GET · Canlı · 200 · text/vtt */
    const val U_94213FAE_3_VTT = "https://subs.rapidvid.org/94213fae/4984907733bebc8f/3.vtt"
}

package com.kalkan.fullhdfilmizlesene

/**
 * Kalkan Tarayıcı'nın www.fullhdfilmizlesene.now üzerinde bulduğu API uçları (19.11.2026 17:08).
 * Aynı sitedeki uçlar mainUrl'e göre göreli yazılmıştır: "$mainUrl" + SABIT
 */
@Suppress("unused")
object FullhdfilmizleseneEndpoints {
    // Henüz uç bulunamadı. Araçlar → API uçları ile sayfada gezinip tekrar dışa aktar.
}

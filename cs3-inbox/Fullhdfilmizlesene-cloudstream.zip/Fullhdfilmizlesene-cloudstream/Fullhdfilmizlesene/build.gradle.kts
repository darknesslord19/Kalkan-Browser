// Sürüm numarası tam sayı olmalı; her güncellemede artır
version = 1

cloudstream {
    description = "www.fullhdfilmizlesene.now için CloudStream eklentisi"
    authors = listOf("Kalkan")

    /**
     * Durum:
     * 0: Çalışmıyor
     * 1: Çalışıyor
     * 2: Yavaş
     * 3: Sadece beta (normal CloudStream sürümünde listelenmeyebilir)
     */
    status = 1

    tvTypes = listOf("Movie", "TvSeries", "Anime", "AsianDrama", "Cartoon", "Documentary", "Live", "Others")
    language = "tr"
    iconUrl = "https://www.google.com/s2/favicons?domain=fullhdfilmizlesene.now&sz=%size%"
}

package com.kalkan.fullhdfilmizlesenex

/**
 * Kalkan Tarayıcı'nın www.fullhdfilmizlesene.now üzerinde bulduğu API uçları (19.11.2026 16:40).
 * Aynı sitedeki uçlar mainUrl'e göre göreli yazılmıştır: "$mainUrl" + SABIT
 */
@Suppress("unused")
object FullhdfilmizlesenexEndpoints {
    // Henüz uç bulunamadı. Araçlar → API uçları ile sayfada gezinip tekrar dışa aktar.
}

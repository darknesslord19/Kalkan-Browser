package com.kalkan.fullhdfilmizlesenex

import android.content.Context
import com.lagradost.cloudstream3.plugins.CloudstreamPlugin
import com.lagradost.cloudstream3.plugins.Plugin

@CloudstreamPlugin
class FullhdfilmizlesenexPlugin : Plugin() {
    override fun load(context: Context) {
        // Bu eklentinin sağlayıcılarını CloudStream'e kaydeder
        registerMainAPI(FullhdfilmizlesenexProvider())
        registerExtractorAPI(RapidVid())
        registerExtractorAPI(TurboImgz())
        registerExtractorAPI(VidMoxy())
        registerExtractorAPI(TRsTX())
        registerExtractorAPI(Sobreatsesuyp())
        registerExtractorAPI(TurkeyPlayer())
        registerExtractorAPI(CloseLoad())
        registerExtractorAPI(VidRameExtractor())
        registerExtractorAPI(Vidmixi())
        registerExtractorAPI(Vk())
        registerExtractorAPI(SibNet())
        registerExtractorAPI(OkRuSSL())
        registerExtractorAPI(OkRuHTTP())
        registerExtractorAPI(DzenRu())
        registerExtractorAPI(PixelDrain())
        registerExtractorAPI(ContentX())
        registerExtractorAPI(Hotlinger())
        registerExtractorAPI(FourCX())
        registerExtractorAPI(PlayRu())
        registerExtractorAPI(FourPlayRu())
        registerExtractorAPI(Pichive())
        registerExtractorAPI(FourPichive())
        registerExtractorAPI(SNplayer())
        registerExtractorAPI(PlayerKorea())
        registerExtractorAPI(VideoSeyred())
        registerExtractorAPI(PeaceMakerst())
        registerExtractorAPI(HDPlayerSystem())
        registerExtractorAPI(HDMomPlayer())
        registerExtractorAPI(HDStreamAble())
        registerExtractorAPI(SetPlay())
        registerExtractorAPI(FastPlay())
        registerExtractorAPI(TauVideo())
        registerExtractorAPI(Odnoklassniki())
        registerExtractorAPI(Drive())
    }
}

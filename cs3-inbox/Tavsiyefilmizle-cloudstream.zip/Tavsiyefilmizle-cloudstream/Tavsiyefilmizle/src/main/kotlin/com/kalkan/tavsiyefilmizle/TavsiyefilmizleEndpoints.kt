package com.kalkan.tavsiyefilmizle

/**
 * Kalkan Tarayıcı'nın tavsiyefilmizle.net üzerinde bulduğu API uçları (19.11.2026 14:51).
 * Aynı sitedeki uçlar mainUrl'e göre göreli yazılmıştır: "$mainUrl" + SABIT
 */
@Suppress("unused")
object TavsiyefilmizleEndpoints {
    // Henüz uç bulunamadı. Araçlar → API uçları ile sayfada gezinip tekrar dışa aktar.
}

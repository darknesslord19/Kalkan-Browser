package com.kalkan.tavsiyefilmizle

/**
 * Kalkan Tarayıcı'nın tavsiyefilmizle.net üzerinde bulduğu API uçları (19.11.2026 15:17).
 * Aynı sitedeki uçlar mainUrl'e göre göreli yazılmıştır: "$mainUrl" + SABIT
 */
@Suppress("unused")
object TavsiyefilmizleEndpoints {
    /** POST · Canlı · 200 · text/plain */
    const val POST_CDN_CGI_RUM = "/cdn-cgi/rum?"
    // Örnek gövde: {"startTime":1795090482722,"pageloadId":"c7c93e35-c096-4438-a1c7-198d9c4afc22","eventType":1,"nt":"navigate","location":"https://tavsiyefilmizle.net/","versions
    /** POST · Canlı */
    const val POST_G_COLLECT = "https://www.google-analytics.com/g/collect?v=2&tid=G-N0FH1HHWCX&gtm=45je6bh1v9229971166za208zd9229971166xf1&_p=1795090483434&gcd=13l3l3l3l1l1&npa=0&dma=0&_eu=AAAAAAQ&cid=1942746850.1795086972&frm=0&ngs=1&pscdl=noapi&rcb=17&sr=407x904&uaa=&uab=&uafvl=&uam=&uamb=1&uap=Android&uapv=&uaw=0&ul=tr-tr&_s=1&tag_exp=115938465~115938469~118897920~118897930~120213116~120385422~120469145~120469153~121246026~121246034~123785233&sid=1795089021&sct=2&seg=1&dl=https%3A%2F%2Ftavsiyefilmizle.net%2F&dt=Hd%20Film%20%C4%B0zle%2C%20T%C3%BCrk%C3%A7e%20Filmler%2C%20G%C3%BCncel%20Filmler%2C%20Full%20Film%20%C4%B0zle&en=page_view&_ee=1&tfd=6516"
}

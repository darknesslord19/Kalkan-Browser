package com.kalkan.tavsiyefilmizle

/**
 * Kalkan Tarayıcı'nın tavsiyefilmizle.net üzerinde bulduğu API uçları (19.11.2026 15:34).
 * Aynı sitedeki uçlar mainUrl'e göre göreli yazılmıştır: "$mainUrl" + SABIT
 */
@Suppress("unused")
object TavsiyefilmizleEndpoints {
    /** GET · Canlı · 200 · application/json */
    const val JWPLAYER_UNLIMITED_8_25_6_TRANSLATIONS_TR_JSON = "https://db187550c7dkf.cloudfront.net/jwplayer-unlimited-8.25.6/translations/tr.json"
    /** GET · Canlı */
    const val PAGEAD_ID = "https://googleads.g.doubleclick.net/pagead/id"
    /** GET · Canlı · 200 · text/plain */
    const val LIST_N0VJWTBVB0PPBEO3BUDZEERNL09SNCTQWUVVWS85EDLZB2VEB2S4AWD = "https://hotstream.club/list/N0VjWTBvb0ppbEo3bUdzeERNL09sNCtqWUVvWS85eDlZb2VEb2s4aWdJZTF0Q0o4YitkL3huNkJjME9jb2xhOEtPRFFKTXJxc1hEQUI0VzJaN3M3SGJYLy9YZmhuL1VNdzBNd1l5MUtybGFqUFFQWUtQVDlUTlVyVUZLeERSSmx3NVhOUy9OZnc5YlE5MWNnQmllYkFoQkh0RytDVFZtRmN0S1NReHk5N3p3PQ=="
    /** GET · Canlı · 200 · text/plain */
    const val M3U = "https://hotstream.club/m3u/c1IwS1Zqc2Fpa08rekJDaDNScTRveHF6UFZXSVdiRjdWWXh5WnJvRzdWN2FDbVNiTVVMRFNIOWs5c2NpUmwxaG1leGlZejJlaVEwQk1VSG52SjNFSlFIR29pckRDMXZjSXR6eFdOWlRSbnRRRXY4Uzl0RGNWRnlUOGpoOUloMmhZWkREdVZLbUErYzdPOEpDeFIxNWI4aUFMSjJhT0xnMm9UNG5raHpYODJRN1JoWFlJYkFVWEwrTjBIdHVBZzFleDA2QVRUSk4zL0xvWDMvZElUOW1lRTQ1WEhqT01CK2hOZjByb3pJa0VrdmU3Y1BVUlZuUkRHRkpzRVRnd1dYUFVNb2JBUDNIQzFSS0VUdXlrNG03d3RWa2UveisrWXFoTExQVHNXYng4a1k9"
    /** POST · Canlı · 200 · application/json+protobuf */
    const val POST_RPC_GOOGLE_INTERNAL_WAA_V1_WAA_GENERATEIT = "https://jnn-pa.googleapis.com/\$rpc/google.internal.waa.v1.Waa/GenerateIT"
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ = "https://seyret1.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE0rWTMyRXBEWWxJRXJtOGsyZWE2a1Y="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_2 = "https://seyret1.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE1IWll5Nk84OWRuUjNiazFoZ2JzSHM="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_3 = "https://seyret1.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE1xOXZScC9xcnBoV2RzSlkzdXhHdC8="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_4 = "https://seyret1.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE5yS3RXRkVvWU1ZcHhnR2RJem1YZ2Q="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_5 = "https://seyret1.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE9CZXora3hPM1B2b2t2a1VzVlpEQk8="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_6 = "https://seyret1.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaFA2QStRNTQ0WWttWDloVVpCbVI1Mis="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_7 = "https://seyret1.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaFA4cWJFbFY5WlhYTjVuTUtpNkVieTQ="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_8 = "https://seyret1.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaFB6Y3FFUFFzNHFQQWQ2K0VNMWtMajQ="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_9 = "https://seyret1.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaFBWUkZYc0lBbHk5ai84NGw1NEhLS0w="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_10 = "https://seyret2.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE14Sk9EbVUvcWh6NVd1c3p5Ylkwc3A="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_11 = "https://seyret2.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE14dGV6TkZBRGZtdEUwa1dTaFBDc2s="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_12 = "https://seyret2.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE1UYnhEZ2w5aUkxRFNiU0F4Q2Q3Y2M="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_13 = "https://seyret2.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE1VR0MzdzBCaUYxZ21jUmp2aDJRMnQ="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_14 = "https://seyret2.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE1lcGJ4RWlsTlIxMGpxK0tLNDNUTnI="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_15 = "https://seyret2.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE43ck0zelgyMmxDOFhJQzJRckVFRWI="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_16 = "https://seyret2.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE9MSld3YTlRRDZpbTk1cEtRaUgzbkU="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_17 = "https://seyret2.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE9RNVkvdG91dkJBdWxOaU5jRVp0SUg="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_18 = "https://seyret2.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE9rRER0VFg4Unl1c1dpd0U4L2cvSUU="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_19 = "https://seyret3.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE0vclJ1RGtESGt5SU5TTDlNNTVuSTA="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_20 = "https://seyret3.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE0vcmpZZlZnWDVqbXR3OGM2Mk1DdVE="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_21 = "https://seyret3.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE45Qy9vOXB6MjA3a1ZjTmt3WmdZU0c="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_22 = "https://seyret3.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE5US2hJSXhvVzhlT0VPL2tCTDE0eHU="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_23 = "https://seyret3.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE9FOXd6dWVvUGZmSVl4eEEzcG5vTEI="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_24 = "https://seyret3.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE9UWWpiRStFcG5HQkRFL25ZK1ZPRWg="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_25 = "https://seyret3.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaFA0WCsyaFdicmpWTzJGWGlYVC9mY1Q="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_26 = "https://seyret3.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaFB3bmpFNUUzNWRpNzJGaHJmaEdTTks="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_27 = "https://seyret3.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaFBHWk03QVBTNnowNGNsbVJ4ekloWVk="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_28 = "https://seyret4.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE03OVQ0eHoxNkhJbDNwL3VpOWVtY2s="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_29 = "https://seyret4.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE43OUN1R3NUWUdJcGdqN0h2Zk4vcDM="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_30 = "https://seyret4.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE4rVkNYMHRWVmZmZko0Y2hRSWtKeS8="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_31 = "https://seyret4.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE81VDFMZ0Y5dHhGRkNUQ21iRlZuYWQ="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_32 = "https://seyret4.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE85bzZnNEVZWDVOYUxsa2RWSWJFbW4="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_33 = "https://seyret4.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE95dWNtQkpGN0M1TDJudnkvWkdhZ28="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_34 = "https://seyret4.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE9sN1M5Rmc2M09zYWppVS8vYlA4WjQ="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_35 = "https://seyret4.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE9wdWlBTlNnQXVwL2Zwdi9nUWczbXM="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_36 = "https://seyret4.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaFBxVUR4WXpSb05TNC9aOUtXUWJXQlQ="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_37 = "https://seyret5.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE0ybFVxWHoyQlNUaHhDa2Z3MnNlSFY="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_38 = "https://seyret5.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE10L2Vtb0FvbkhwczVjQkxlRXRGMGQ="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_39 = "https://seyret5.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE1UQ3lGSEZQVGJHZEIvK0VDOVAzNTQ="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_40 = "https://seyret5.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE5QSjNwTFVtUSttYjFhZnJ3cTlSNjc="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_41 = "https://seyret5.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE5XNi80M1VONTY3Z2dWdnFneHc2clA="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_42 = "https://seyret5.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE5nY25YV1ZHTHR2SWViaHZhSXEyM0o="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_43 = "https://seyret5.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE95eGt0TW1qZkE4azhkOW00bXY4T2w="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_44 = "https://seyret5.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE9qQkE4Y3NlcS90ZkhBL2lqZU54ZHg="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_45 = "https://seyret5.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaFBKK1pIT2N2VFNDRUNjNTVobU9qVWs="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_46 = "https://seyret6.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE01VllQWTJ1N1Y5eXVJb2VsVEtJYWE="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_47 = "https://seyret6.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE40WWgzWEZERXVFOHRtLzVsbWhoems="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_48 = "https://seyret6.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE44OUJLSmdCc25jbEQxZWNPMnJ0Q1c="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_49 = "https://seyret6.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE4zRW1ISjQrS3ZsRys2VnJFQWlQajU="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_50 = "https://seyret6.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE52alNSRHMrMkV1VlNOU0F3T0ZSbUQ="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_51 = "https://seyret6.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE5jQTVzcHdzTk9oOW1XaW9oK2huNE8="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_52 = "https://seyret6.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaFB2cG04Z1VUMm5CQlA2bmlqYXo1NnQ="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_53 = "https://seyret6.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaFBPYlJRaENhNjB1ZVViYlA5dmhQUTI="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_54 = "https://seyret7.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE1GZEFMZWhnRXJzaENiakV3T3dFOW4="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_55 = "https://seyret7.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE1tVGlscWQzQ2doVzBoMnkwSWlUVDI="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_56 = "https://seyret7.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE4vYmhLSWhoYUtjRWVqdVdBSzloWFA="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_57 = "https://seyret7.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE8xOTFXZko3bWxSYkprU0ltNnF3VDE="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_58 = "https://seyret7.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE9FeFllRDFOWkFGYUZHYWdXMWJaWEw="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_59 = "https://seyret7.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE9YUFFWTlptaEJQaXhITTRHMHZDL3k="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_60 = "https://seyret7.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE9uRmFPQW5uVmNuaHNhYndNdzY3NVo="
    /** GET · Canlı · 200 · text/plain */
    const val PROCESS_WKZRV1VBEJFMM01UVLVTBETKTFDUSGLNBFRTTKLFT0O5BNVLD2MZ_61 = "https://seyret7.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE9yTU5JM2hoL2Q1cjFQbWVzaUdZeVM="
    /** GET · Canlı · 200 · application/json */
    const val SETTINGS = "https://syndication.twitter.com/settings?session_id=6e2cd5f2313a5a2d5054487ea6824baeb806da95"
    /** POST · Canlı · 200 · text/plain */
    const val POST_CDN_CGI_RUM = "/cdn-cgi/rum?"
    // Örnek gövde: {"startTime":1795090482722,"pageloadId":"c7c93e35-c096-4438-a1c7-198d9c4afc22","eventType":1,"nt":"navigate","location":"https://tavsiyefilmizle.net/","versions
    /** POST · Canlı */
    const val POST_G_COLLECT = "https://www.google-analytics.com/g/collect?v=2&tid=G-N0FH1HHWCX&gtm=45je6bh1v9229971166za208zd9229971166xf1&_p=1795090483434&gcd=13l3l3l3l1l1&npa=0&dma=0&_eu=AAAAAAQ&cid=1942746850.1795086972&frm=0&ngs=1&pscdl=noapi&rcb=17&sr=407x904&uaa=&uab=&uafvl=&uam=&uamb=1&uap=Android&uapv=&uaw=0&ul=tr-tr&_s=1&tag_exp=115938465~115938469~118897920~118897930~120213116~120385422~120469145~120469153~121246026~121246034~123785233&sid=1795089021&sct=2&seg=1&dl=https%3A%2F%2Ftavsiyefilmizle.net%2F&dt=Hd%20Film%20%C4%B0zle%2C%20T%C3%BCrk%C3%A7e%20Filmler%2C%20G%C3%BCncel%20Filmler%2C%20Full%20Film%20%C4%B0zle&en=page_view&_ee=1&tfd=6516"
    /** POST · Canlı · 200 · application/json */
    const val POST_YOUTUBEI_V1_LOG_EVENT = "https://www.youtube.com/youtubei/v1/log_event?alt=json"
    // Örnek gövde: {"context":{"client":{"hl":"tr","gl":"TR","clientName":56,"clientVersion":"2.20261118.01.00","configInfo":{"appInstallData":"CK_Y-9cGEMn2gBMQyvuAExCYktMcEMGP0Bw
    /** ? · Sayfa HTML */
    const val GETAD_PHP = "http://adserver.advrstcdn.com/getad.php"
    /** ? · Sayfa HTML */
    const val TRACK = "http://bongacams.com/track?"
    /** ? · Sayfa HTML */
    const val TRACK_2 = "http://join.brokestraightboys.com/track/"
    /** ? · jwplayer.core.controls.js */
    const val SHARER_SHARER_PHP = "http://www.facebook.com/sharer/sharer.php?u="
    /** ? · Sayfa HTML */
    const val INDIR_PHP = "http://www.installadz.com/indir.php"
    /** ? · base.js */
    const val STREAMING_METADATA_SEGMENT = "http://youtube.com/streaming/metadata/segment/102015"
    /** ? · base.js */
    const val STREAMING_OTF_DURATIONS = "http://youtube.com/streaming/otf/durations/112015"
    /** ? · Sayfa HTML */
    const val API_CLICK = "https://a.acebet.com/api/click?"
    /** ? · Sayfa HTML */
    const val REDIRECT_ASPX = "https://ads.betfair.com/redirect.aspx?"
    /** ? · Sayfa HTML */
    const val AFF_PHP = "https://billing.purevpn.com/aff.php"
    /** ? · Sayfa HTML */
    const val TRACK_3 = "https://bongacams10.com/track?"
    /** ? · Sayfa HTML */
    const val TRACK_4 = "https://bongacams2.com/track?"
    /** ? · jwplayer.core.controls.js */
    const val V2_MEDIA = "https://cdn.jwplayer.com/v2/media/"
    /** ? · jwplayer.js */
    const val DOCS_DEVELOPER_GUIDE_API_ERRORS_REFERENCE = "https://developer.jwplayer.com/jw-player/docs/developer-guide/api/errors-reference#"
    /** ? · Sayfa HTML */
    const val TC_PHP = "https://financeads.net/tc.php?"
    /** ? · Sayfa HTML */
    const val TRACK_5 = "https://join.bannedsextapes.com/track/"
    /** ? · Sayfa HTML */
    const val TRACK_6 = "https://join.playboyplus.com/track/"
    /** ? · Sayfa HTML */
    const val TRACK_7 = "https://join.sexworld3d.com/track/"
    /** ? · Sayfa HTML */
    const val TRACK_8 = "https://join.virtualtaboo.com/track/"
    /** ? · Sayfa HTML */
    const val REDIRECT_V2 = "https://kingredirect.com/redirect/v2/?ads="
    /** ? · Sayfa HTML */
    const val REDIRECT_V2_2 = "https://kingyonlendir.link/redirect/v2/?ads="
    /** ? · Sayfa HTML */
    const val TRACK_9 = "https://natour.naughtyamerica.com/track/"
    /** ? · widgets.js */
    const val WIDGETS_HUB_HTML = "https://platform.twitter.com/widgets/hub.html"
    /** ? · base.js */
    const val API_STORE = "https://redux.js.org/api/store#subscribelistener"
    /** ? · js */
    const val G_COLLECT = "https://stats.g.doubleclick.net/g/collect"
    /** ? · Sayfa HTML */
    const val COMMENTS_FEED = "/comments/feed/"
    /** ? · Sayfa HTML */
    const val EARN_PHP = "/earn.php?zone"
    /** ? · Sayfa HTML */
    const val FEED = "/feed/"
    /** ? · Sayfa HTML */
    const val JUMP_NEXT_PHP = "/jump/next.php?r="
    /** ? · Sayfa HTML */
    const val WP_ADMIN_ADMIN_AJAX_PHP = "/wp-admin/admin-ajax.php"
    /** ? · Sayfa HTML */
    const val WP_JSON = "/wp-json/"
    /** ? · Sayfa HTML */
    const val WP_JSON_OEMBED_1_0_EMBED = "/wp-json/oembed/1.0/embed?url=https%3A%2F%2Ftavsiyefilmizle.net%2Fasla-teslim-olma-izle%2F"
    /** ? · Sayfa HTML */
    const val WP_JSON_WP_V2_POSTS = "/wp-json/wp/v2/posts/9819"
    /** ? · Sayfa HTML */
    const val WP_LOGIN_PHP = "/wp-login.php"
    /** ? · Sayfa HTML */
    const val XMLRPC_PHP = "/xmlrpc.php"
    /** ? · Sayfa HTML */
    const val AFF_PHP_2 = "https://torguard.net/aff.php"
    /** ? · Sayfa HTML */
    const val EARN_PHP_2 = "https://track.bcvc.mobi/earn.php"
    /** ? · owl.carousel.min.js */
    const val API_V2_VIDEO = "https://vimeo.com/api/v2/video/"
    /** ? · owl.carousel.min.js */
    const val API_VIDEOS = "https://vzaar.com/api/videos/"
    /** ? · Sayfa HTML */
    const val CLICK_PHP = "https://www.avantlink.com/click.php"
    /** ? · Sayfa HTML */
    const val SIGNUP = "https://www.dating-finder.com/signup/?ai_d="
    /** ? · Sayfa HTML */
    const val PLUGINS_LIKE_PHP = "https://www.facebook.com/plugins/like.php?href=https://tavsiyefilmizle.net/asla-teslim-olma-izle/&amp"
    /** ? · Sayfa HTML */
    const val SHARER_PHP = "https://www.facebook.com/sharer.php?u="
    /** ? · Sayfa HTML */
    const val TC_PHP_2 = "https://www.financeads.net/tc.php?"
    /** ? · base.js */
    const val CERTIFICATEPROVISIONING_V1_DEVICECERTIFICATES_CREATE = "https://www.googleapis.com/certificateprovisioning/v1/devicecertificates/create?key=AIzaSyB-5OLKTx2iU5mko18DfdwK5611JIjbUhE"
    /** ? · js */
    const val CCM_COLLECT = "https://www.googletagmanager.com/ccm/collect"
    /** ? · js */
    const val CCM_S_COLLECT = "https://www.googletagmanager.com/ccm/s/collect"
    /** ? · js */
    const val G_COLLECT_2 = "https://www.googletagmanager.com/g/collect"
    /** ? · js */
    const val MC_COLLECT = "https://www.googletagmanager.com/mc/collect"
    /** ? · js */
    const val RMKT_COLLECT = "https://www.googletagmanager.com/rmkt/collect"
    /** ? · Sayfa HTML */
    const val ACCOUNT = "https://www.mrskin.com/account/"
    /** ? · Sayfa HTML */
    const val SIGNUP_LANDING = "https://www.nutaku.net/signup/landing/"
    /** ? · base.js */
    const val API = "https://www.youtube.com/api/"
    /** ? · base.js */
    const val API_DRM_FPS = "https://www.youtube.com/api/drm/fps?ek="
    /** ? · base.js */
    const val YOUTUBEI_V1 = "https://www.youtube.com/youtubei/v1/{param}"
    /** ? · base.js */
    const val API_DRM_FPS_2 = "https://youtube.com/api/drm/fps?ek=uninitialized"
    /** GET · Bilinen yol · 200 · text/html */
    const val WELL_KNOWN_APPLE_APP_SITE_ASSOCIATION = "/.well-known/apple-app-site-association"
    /** ? · robots.txt · Disallow */
    const val AUTHOR = "/author/"
    /** GET · Bilinen yol · 200 · application/xml */
    const val CROSSDOMAIN_XML = "/crossdomain.xml"
    /** GET · Bilinen yol · 200 · application/json · JSON yanıt */
    const val MANIFEST_JSON = "/manifest.json"
    /** GET · Bilinen yol · 200 · text/plain · 7 kural */
    const val ROBOTS_TXT = "/robots.txt"
    /** GET · Bilinen yol · 200 · text/xml */
    const val SITEMAP_XML = "/sitemap.xml"
    /** ? · robots.txt · Disallow */
    const val TAG = "/tag/"
    /** ? · robots.txt · Disallow */
    const val WP_CONTENT_PLUGINS = "/wp-content/plugins/"
    /** ? · robots.txt · Disallow */
    const val WP_CONTENT_THEMES = "/wp-content/themes/"
    /** ? · robots.txt · Disallow */
    const val WP_INCLUDES = "/wp-includes/"
    /** GET · Bilinen yol · 200 · application/json · WordPress REST · 400 uç */
    const val WP_JSON_2 = "/wp-json/"
    /** GET · WordPress · aioseo/v1 */
    const val WP_JSON_AIOSEO_V1 = "/wp-json/aioseo/v1"
    /** POST · WordPress · aioseo/v1 */
    const val POST_AIOSEO_V1_AI_AGENTS_GENERATE_APP_PASSWORD = "/wp-json/aioseo/v1/ai-agents/generate-app-password"
    /** POST · WordPress · aioseo/v1 */
    const val POST_AIOSEO_V1_AI_AGENTS_INSTALL_MCP_ADAPTER = "/wp-json/aioseo/v1/ai-agents/install-mcp-adapter"
    /** GET · WordPress · aioseo/v1 */
    const val V1_AI_AGENTS_MCP_ADAPTER_RELEASE = "/wp-json/aioseo/v1/ai-agents/mcp-adapter/release"
    /** POST · WordPress · aioseo/v1 */
    const val POST_AIOSEO_V1_AI_ASSISTANT = "/wp-json/aioseo/v1/ai/assistant"
    /** POST · WordPress · aioseo/v1 */
    const val POST_AIOSEO_V1_AI_AUTH = "/wp-json/aioseo/v1/ai/auth"
    /** POST · WordPress · aioseo/v1 */
    const val POST_AIOSEO_V1_AI_CREDITS = "/wp-json/aioseo/v1/ai/credits"
    /** POST · WordPress · aioseo/v1 */
    const val POST_AIOSEO_V1_AI_DEACTIVATE = "/wp-json/aioseo/v1/ai/deactivate"
    /** POST · WordPress · aioseo/v1 */
    const val POST_AIOSEO_V1_AI_FAQS = "/wp-json/aioseo/v1/ai/faqs"
    /** GET · WordPress · aioseo/v1 */
    const val AIOSEO_V1_AI_IMAGE_GENERATOR = "/wp-json/aioseo/v1/ai/image-generator"
    /** POST · WordPress · aioseo/v1 */
    const val POST_AIOSEO_V1_AI_IMAGE_GENERATOR = "/wp-json/aioseo/v1/ai/image-generator"
    /** DELETE · WordPress · aioseo/v1 */
    const val DELETE_AIOSEO_V1_AI_IMAGE_GENERATOR = "/wp-json/aioseo/v1/ai/image-generator"
    /** POST · WordPress · aioseo/v1 */
    const val POST_V1_AI_IMAGE_ALT = "/wp-json/aioseo/v1/ai/image/alt"
    /** POST · WordPress · aioseo/v1 */
    const val POST_AI_INSIGHTS_BRAND_TRACKER_SUBSCRIBE = "/wp-json/aioseo/v1/ai/insights/brand-tracker/subscribe"
    /** GET · WordPress · aioseo/v1 */
    const val V1_AI_INSIGHTS_REPORTS = "/wp-json/aioseo/v1/ai/insights/reports"
    /** POST · WordPress · aioseo/v1 */
    const val POST_V1_AI_INSIGHTS_REPORTS = "/wp-json/aioseo/v1/ai/insights/reports"
    /** GET · WordPress · aioseo/v1 */
    const val AI_INSIGHTS_REPORTS = "/wp-json/aioseo/v1/ai/insights/reports/(?P<uuid>[a-zA-Z0-9-]+)"
    /** DELETE · WordPress · aioseo/v1 */
    const val DELETE_AI_INSIGHTS_REPORTS = "/wp-json/aioseo/v1/ai/insights/reports/(?P<uuid>[a-zA-Z0-9-]+)"
    /** POST · WordPress · aioseo/v1 */
    const val POST_AI_INSIGHTS_REPORTS = "/wp-json/aioseo/v1/ai/insights/reports/(?P<uuid>[a-zA-Z0-9-]+)/regenerate"
    /** POST · WordPress · aioseo/v1 */
    const val POST_AIOSEO_V1_AI_KEY_POINTS = "/wp-json/aioseo/v1/ai/key-points"
    /** POST · WordPress · aioseo/v1 */
    const val POST_V1_AI_META_DESCRIPTION = "/wp-json/aioseo/v1/ai/meta/description"
    /** POST · WordPress · aioseo/v1 */
    const val POST_V1_AI_META_TITLE = "/wp-json/aioseo/v1/ai/meta/title"
    /** POST · WordPress · aioseo/v1 */
    const val POST_AIOSEO_V1_AI_SCHEMA = "/wp-json/aioseo/v1/ai/schema"
    /** POST · WordPress · aioseo/v1 */
    const val POST_AIOSEO_V1_AI_SOCIAL_POSTS = "/wp-json/aioseo/v1/ai/social-posts"
    /** POST · WordPress · aioseo/v1 */
    const val POST_V1_AI_TRUSEO_OPTIMIZE_POST = "/wp-json/aioseo/v1/ai/truseo/optimize-post"
    /** POST · WordPress · aioseo/v1 */
    const val POST_V1_AI_TRUSEO_SPELLING = "/wp-json/aioseo/v1/ai/truseo/spelling"
    /** POST · WordPress · aioseo/v1 */
    const val POST_V1_AI_TRUSEO_SUGGEST = "/wp-json/aioseo/v1/ai/truseo/suggest"
    /** POST · WordPress · aioseo/v1 */
    const val POST_WP_JSON_AIOSEO_V1_ANALYZE = "/wp-json/aioseo/v1/analyze"
    /** POST · WordPress · aioseo/v1 */
    const val POST_WP_JSON_AIOSEO_V1_ANALYZE_HEADLINE = "/wp-json/aioseo/v1/analyze-headline"
    /** POST · WordPress · aioseo/v1 */
    const val POST_AIOSEO_V1_ANALYZE_HEADLINE_DELETE = "/wp-json/aioseo/v1/analyze-headline/delete"
    /** POST · WordPress · aioseo/v1 */
    const val POST_AIOSEO_V1_ANALYZE_DELETE_SITE = "/wp-json/aioseo/v1/analyze/delete-site"
    /** POST · WordPress · aioseo/v1 */
    const val POST_WP_JSON_AIOSEO_V1_BACKUP = "/wp-json/aioseo/v1/backup"
    /** DELETE · WordPress · aioseo/v1 */
    const val DELETE_WP_JSON_AIOSEO_V1_BACKUP = "/wp-json/aioseo/v1/backup"
    /** POST · WordPress · aioseo/v1 */
    const val POST_AIOSEO_V1_BACKUP_RESTORE = "/wp-json/aioseo/v1/backup/restore"
    /** POST · WordPress · aioseo/v1 */
    const val POST_WP_JSON_AIOSEO_V1_CLEAR_LOG = "/wp-json/aioseo/v1/clear-log"
    /** POST · WordPress · aioseo/v1 */
    const val POST_WP_JSON_AIOSEO_V1_CONNECT = "/wp-json/aioseo/v1/connect"
    /** POST · WordPress · aioseo/v1 */
    const val POST_WP_JSON_AIOSEO_V1_CONNECT_PRO = "/wp-json/aioseo/v1/connect-pro"
    /** POST · WordPress · aioseo/v1 */
    const val POST_WP_JSON_AIOSEO_V1_CONNECT_URL = "/wp-json/aioseo/v1/connect-url"
    /** POST · WordPress · aioseo/v1 */
    const val POST_WP_JSON_AIOSEO_V1_CRAWL_CLEANUP = "/wp-json/aioseo/v1/crawl-cleanup"
    /** POST · WordPress · aioseo/v1 */
    const val POST_AIOSEO_V1_CRAWL_CLEANUP_BLOCK = "/wp-json/aioseo/v1/crawl-cleanup/block"
    /** POST · WordPress · aioseo/v1 */
    const val POST_AIOSEO_V1_CRAWL_CLEANUP_DELETE_BLOCKED = "/wp-json/aioseo/v1/crawl-cleanup/delete-blocked"
    /** POST · WordPress · aioseo/v1 */
    const val POST_AIOSEO_V1_CRAWL_CLEANUP_DELETE_UNBLOCKED = "/wp-json/aioseo/v1/crawl-cleanup/delete-unblocked"
    /** POST · WordPress · aioseo/v1 */
    const val POST_WP_JSON_AIOSEO_V1_EMAIL_DEBUG_INFO = "/wp-json/aioseo/v1/email-debug-info"
    /** POST · WordPress · aioseo/v1 */
    const val POST_AIOSEO_V1_EMAIL_SUMMARY_SEND = "/wp-json/aioseo/v1/email-summary/send"
    /** POST · WordPress · aioseo/v1 */
    const val POST_WP_JSON_AIOSEO_V1_HTACCESS = "/wp-json/aioseo/v1/htaccess"
    /** POST · WordPress · aioseo/v1 */
    const val POST_V1_INTEGRATION_SEMRUSH_AUTHENTICATE = "/wp-json/aioseo/v1/integration/semrush/authenticate"
    /** POST · WordPress · aioseo/v1 */
    const val POST_V1_INTEGRATION_SEMRUSH_KEYPHRASES = "/wp-json/aioseo/v1/integration/semrush/keyphrases"
    /** POST · WordPress · aioseo/v1 */
    const val POST_V1_INTEGRATION_SEMRUSH_REFRESH = "/wp-json/aioseo/v1/integration/semrush/refresh"
    /** POST · WordPress · aioseo/v1 */
    const val POST_V1_INTEGRATION_WPCODE_SNIPPETS = "/wp-json/aioseo/v1/integration/wpcode/snippets"
    /** POST · WordPress · aioseo/v1 */
    const val POST_WP_JSON_AIOSEO_V1_KEYPHRASES = "/wp-json/aioseo/v1/keyphrases"
    /** POST · WordPress · aioseo/v1 */
    const val POST_AIOSEO_V1_NOTIFICATION_BLOG_VISIBILITY_REMINDER = "/wp-json/aioseo/v1/notification/blog-visibility-reminder"
    /** POST · WordPress · aioseo/v1 */
    const val POST_AIOSEO_V1_NOTIFICATION_CONFLICTING_PLUGINS_REMINDER = "/wp-json/aioseo/v1/notification/conflicting-plugins-reminder"
    /** POST · WordPress · aioseo/v1 */
    const val POST_AIOSEO_V1_NOTIFICATION_DESCRIPTION_FORMAT_REMINDER = "/wp-json/aioseo/v1/notification/description-format-reminder"
    /** POST · WordPress · aioseo/v1 */
    const val POST_AIOSEO_V1_NOTIFICATION_EMAIL_REPORTS_ENABLE = "/wp-json/aioseo/v1/notification/email-reports-enable"
    /** POST · WordPress · aioseo/v1 */
    const val POST_AIOSEO_V1_NOTIFICATION_INSTALL_ADDONS_REMINDER = "/wp-json/aioseo/v1/notification/install-addons-reminder"
    /** POST · WordPress · aioseo/v1 */
    const val POST_AIOSEO_V1_NOTIFICATION_INSTALL_AIOSEO_IMAGE_SEO_REMINDE = "/wp-json/aioseo/v1/notification/install-aioseo-image-seo-reminder"
    /** POST · WordPress · aioseo/v1 */
    const val POST_AIOSEO_V1_NOTIFICATION_INSTALL_AIOSEO_LOCAL_BUSINESS_RE = "/wp-json/aioseo/v1/notification/install-aioseo-local-business-reminder"
    /** POST · WordPress · aioseo/v1 */
    const val POST_AIOSEO_V1_NOTIFICATION_INSTALL_AIOSEO_NEWS_SITEMAP_REMI = "/wp-json/aioseo/v1/notification/install-aioseo-news-sitemap-reminder"
    /** POST · WordPress · aioseo/v1 */
    const val POST_AIOSEO_V1_NOTIFICATION_INSTALL_AIOSEO_VIDEO_SITEMAP_REM = "/wp-json/aioseo/v1/notification/install-aioseo-video-sitemap-reminder"
    /** POST · WordPress · aioseo/v1 */
    const val POST_AIOSEO_V1_NOTIFICATION_INSTALL_MI_REMINDER = "/wp-json/aioseo/v1/notification/install-mi-reminder"
    /** POST · WordPress · aioseo/v1 */
    const val POST_AIOSEO_V1_NOTIFICATION_INSTALL_OM_REMINDER = "/wp-json/aioseo/v1/notification/install-om-reminder"
    /** POST · WordPress · aioseo/v1 */
    const val POST_WP_JSON_AIOSEO_V1_NOTIFICATION = "/wp-json/aioseo/v1/notification/v3-migration-schema-number-reminder"
    /** POST · WordPress · aioseo/v1 */
    const val POST_AIOSEO_V1_NOTIFICATIONS_DISMISS = "/wp-json/aioseo/v1/notifications/dismiss"
}

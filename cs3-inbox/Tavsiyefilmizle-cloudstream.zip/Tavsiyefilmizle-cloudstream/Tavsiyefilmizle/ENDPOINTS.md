# Tavsiyefilmizle — bulunan uçlar

Kalkan Tarayıcı · 19.11.2026 15:34 · https://tavsiyefilmizle.net

| Yöntem | Adres | Kaynak | Durum | Not |
|---|---|---|---|---|
| GET | `https://db187550c7dkf.cloudfront.net/jwplayer-unlimited-8.25.6/translations/tr.json` | Canlı | 200 | application/json |
| GET | `https://googleads.g.doubleclick.net/pagead/id` | Canlı |  | ×2 |
| GET | `https://hotstream.club/list/N0VjWTBvb0ppbEo3bUdzeERNL09sNCtqWUVvWS85eDlZb2VEb2s4aWdJZTF0Q0o4YitkL3huNkJjME9jb2xhOEtPRFFKTXJxc1hEQUI0VzJaN3M3SGJYLy9YZmhuL1VNdzBNd1l5MUtybGFqUFFQWUtQVDlUTlVyVUZLeERSSmx3NVhOUy9OZnc5YlE5MWNnQmllYkFoQkh0RytDVFZtRmN0S1NReHk5N3p3PQ==` | Canlı | 200 | text/plain |
| GET | `https://hotstream.club/m3u/c1IwS1Zqc2Fpa08rekJDaDNScTRveHF6UFZXSVdiRjdWWXh5WnJvRzdWN2FDbVNiTVVMRFNIOWs5c2NpUmwxaG1leGlZejJlaVEwQk1VSG52SjNFSlFIR29pckRDMXZjSXR6eFdOWlRSbnRRRXY4Uzl0RGNWRnlUOGpoOUloMmhZWkREdVZLbUErYzdPOEpDeFIxNWI4aUFMSjJhT0xnMm9UNG5raHpYODJRN1JoWFlJYkFVWEwrTjBIdHVBZzFleDA2QVRUSk4zL0xvWDMvZElUOW1lRTQ1WEhqT01CK2hOZjByb3pJa0VrdmU3Y1BVUlZuUkRHRkpzRVRnd1dYUFVNb2JBUDNIQzFSS0VUdXlrNG03d3RWa2UveisrWXFoTExQVHNXYng4a1k9` | Canlı | 200 | text/plain |
| POST | `https://jnn-pa.googleapis.com/$rpc/google.internal.waa.v1.Waa/GenerateIT` | Canlı | 200 | application/json+protobuf |
| GET | `https://seyret1.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE0rWTMyRXBEWWxJRXJtOGsyZWE2a1Y=` | Canlı | 200 | text/plain |
| GET | `https://seyret1.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE1IWll5Nk84OWRuUjNiazFoZ2JzSHM=` | Canlı | 200 | text/plain |
| GET | `https://seyret1.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE1xOXZScC9xcnBoV2RzSlkzdXhHdC8=` | Canlı | 200 | text/plain |
| GET | `https://seyret1.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE5yS3RXRkVvWU1ZcHhnR2RJem1YZ2Q=` | Canlı | 200 | text/plain |
| GET | `https://seyret1.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE9CZXora3hPM1B2b2t2a1VzVlpEQk8=` | Canlı | 200 | text/plain |
| GET | `https://seyret1.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaFA2QStRNTQ0WWttWDloVVpCbVI1Mis=` | Canlı | 200 | text/plain |
| GET | `https://seyret1.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaFA4cWJFbFY5WlhYTjVuTUtpNkVieTQ=` | Canlı | 200 | text/plain |
| GET | `https://seyret1.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaFB6Y3FFUFFzNHFQQWQ2K0VNMWtMajQ=` | Canlı | 200 | text/plain |
| GET | `https://seyret1.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaFBWUkZYc0lBbHk5ai84NGw1NEhLS0w=` | Canlı | 200 | text/plain |
| GET | `https://seyret2.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE14Sk9EbVUvcWh6NVd1c3p5Ylkwc3A=` | Canlı | 200 | text/plain |
| GET | `https://seyret2.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE14dGV6TkZBRGZtdEUwa1dTaFBDc2s=` | Canlı | 200 | text/plain |
| GET | `https://seyret2.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE1UYnhEZ2w5aUkxRFNiU0F4Q2Q3Y2M=` | Canlı | 200 | text/plain |
| GET | `https://seyret2.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE1VR0MzdzBCaUYxZ21jUmp2aDJRMnQ=` | Canlı | 200 | text/plain |
| GET | `https://seyret2.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE1lcGJ4RWlsTlIxMGpxK0tLNDNUTnI=` | Canlı | 200 | text/plain |
| GET | `https://seyret2.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE43ck0zelgyMmxDOFhJQzJRckVFRWI=` | Canlı | 200 | text/plain |
| GET | `https://seyret2.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE9MSld3YTlRRDZpbTk1cEtRaUgzbkU=` | Canlı | 200 | text/plain |
| GET | `https://seyret2.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE9RNVkvdG91dkJBdWxOaU5jRVp0SUg=` | Canlı | 200 | text/plain |
| GET | `https://seyret2.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE9rRER0VFg4Unl1c1dpd0U4L2cvSUU=` | Canlı | 200 | text/plain |
| GET | `https://seyret3.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE0vclJ1RGtESGt5SU5TTDlNNTVuSTA=` | Canlı | 200 | text/plain |
| GET | `https://seyret3.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE0vcmpZZlZnWDVqbXR3OGM2Mk1DdVE=` | Canlı | 200 | text/plain |
| GET | `https://seyret3.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE45Qy9vOXB6MjA3a1ZjTmt3WmdZU0c=` | Canlı | 200 | text/plain |
| GET | `https://seyret3.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE5US2hJSXhvVzhlT0VPL2tCTDE0eHU=` | Canlı | 200 | text/plain |
| GET | `https://seyret3.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE9FOXd6dWVvUGZmSVl4eEEzcG5vTEI=` | Canlı | 200 | text/plain |
| GET | `https://seyret3.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE9UWWpiRStFcG5HQkRFL25ZK1ZPRWg=` | Canlı | 200 | text/plain |
| GET | `https://seyret3.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaFA0WCsyaFdicmpWTzJGWGlYVC9mY1Q=` | Canlı | 200 | text/plain |
| GET | `https://seyret3.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaFB3bmpFNUUzNWRpNzJGaHJmaEdTTks=` | Canlı | 200 | text/plain |
| GET | `https://seyret3.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaFBHWk03QVBTNnowNGNsbVJ4ekloWVk=` | Canlı | 200 | text/plain |
| GET | `https://seyret4.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE03OVQ0eHoxNkhJbDNwL3VpOWVtY2s=` | Canlı | 200 | text/plain |
| GET | `https://seyret4.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE43OUN1R3NUWUdJcGdqN0h2Zk4vcDM=` | Canlı | 200 | text/plain |
| GET | `https://seyret4.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE4rVkNYMHRWVmZmZko0Y2hRSWtKeS8=` | Canlı | 200 | text/plain |
| GET | `https://seyret4.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE81VDFMZ0Y5dHhGRkNUQ21iRlZuYWQ=` | Canlı | 200 | text/plain |
| GET | `https://seyret4.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE85bzZnNEVZWDVOYUxsa2RWSWJFbW4=` | Canlı | 200 | text/plain |
| GET | `https://seyret4.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE95dWNtQkpGN0M1TDJudnkvWkdhZ28=` | Canlı | 200 | text/plain |
| GET | `https://seyret4.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE9sN1M5Rmc2M09zYWppVS8vYlA4WjQ=` | Canlı | 200 | text/plain |
| GET | `https://seyret4.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE9wdWlBTlNnQXVwL2Zwdi9nUWczbXM=` | Canlı | 200 | text/plain |
| GET | `https://seyret4.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaFBxVUR4WXpSb05TNC9aOUtXUWJXQlQ=` | Canlı | 200 | text/plain |
| GET | `https://seyret5.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE0ybFVxWHoyQlNUaHhDa2Z3MnNlSFY=` | Canlı | 200 | text/plain |
| GET | `https://seyret5.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE10L2Vtb0FvbkhwczVjQkxlRXRGMGQ=` | Canlı | 200 | text/plain |
| GET | `https://seyret5.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE1UQ3lGSEZQVGJHZEIvK0VDOVAzNTQ=` | Canlı | 200 | text/plain |
| GET | `https://seyret5.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE5QSjNwTFVtUSttYjFhZnJ3cTlSNjc=` | Canlı | 200 | text/plain |
| GET | `https://seyret5.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE5XNi80M1VONTY3Z2dWdnFneHc2clA=` | Canlı | 200 | text/plain |
| GET | `https://seyret5.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE5nY25YV1ZHTHR2SWViaHZhSXEyM0o=` | Canlı | 200 | text/plain |
| GET | `https://seyret5.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE95eGt0TW1qZkE4azhkOW00bXY4T2w=` | Canlı | 200 | text/plain |
| GET | `https://seyret5.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE9qQkE4Y3NlcS90ZkhBL2lqZU54ZHg=` | Canlı | 200 | text/plain |
| GET | `https://seyret5.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaFBKK1pIT2N2VFNDRUNjNTVobU9qVWs=` | Canlı | 200 | text/plain |
| GET | `https://seyret6.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE01VllQWTJ1N1Y5eXVJb2VsVEtJYWE=` | Canlı | 200 | text/plain |
| GET | `https://seyret6.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE40WWgzWEZERXVFOHRtLzVsbWhoems=` | Canlı | 200 | text/plain |
| GET | `https://seyret6.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE44OUJLSmdCc25jbEQxZWNPMnJ0Q1c=` | Canlı | 200 | text/plain |
| GET | `https://seyret6.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE4zRW1ISjQrS3ZsRys2VnJFQWlQajU=` | Canlı | 200 | text/plain |
| GET | `https://seyret6.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE52alNSRHMrMkV1VlNOU0F3T0ZSbUQ=` | Canlı | 200 | text/plain |
| GET | `https://seyret6.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE5jQTVzcHdzTk9oOW1XaW9oK2huNE8=` | Canlı | 200 | text/plain |
| GET | `https://seyret6.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaFB2cG04Z1VUMm5CQlA2bmlqYXo1NnQ=` | Canlı | 200 | text/plain |
| GET | `https://seyret6.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaFBPYlJRaENhNjB1ZVViYlA5dmhQUTI=` | Canlı | 200 | text/plain |
| GET | `https://seyret7.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE1GZEFMZWhnRXJzaENiakV3T3dFOW4=` | Canlı | 200 | text/plain |
| GET | `https://seyret7.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE1tVGlscWQzQ2doVzBoMnkwSWlUVDI=` | Canlı | 200 | text/plain |
| GET | `https://seyret7.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE4vYmhLSWhoYUtjRWVqdVdBSzloWFA=` | Canlı | 200 | text/plain |
| GET | `https://seyret7.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE8xOTFXZko3bWxSYkprU0ltNnF3VDE=` | Canlı | 200 | text/plain |
| GET | `https://seyret7.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE9FeFllRDFOWkFGYUZHYWdXMWJaWEw=` | Canlı | 200 | text/plain |
| GET | `https://seyret7.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE9YUFFWTlptaEJQaXhITTRHMHZDL3k=` | Canlı | 200 | text/plain |
| GET | `https://seyret7.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE9uRmFPQW5uVmNuaHNhYndNdzY3NVo=` | Canlı | 200 | text/plain |
| GET | `https://seyret7.store/process/WkZrV1VBejFMM01UVlVTbEtKTFduSGlnbFRtTklFT0o5bnVld2MzOElMTHdYaUhRQndjSjdZODZRNTI5dlNqVnhSaWdHZXc2S0RNNkM5blozR201SEw2ODh1N2VJdVduUFUwRkUzQjFzaE9yTU5JM2hoL2Q1cjFQbWVzaUdZeVM=` | Canlı | 200 | text/plain |
| GET | `https://syndication.twitter.com/settings?session_id=6e2cd5f2313a5a2d5054487ea6824baeb806da95` | Canlı | 200 | application/json |
| POST | `https://tavsiyefilmizle.net/cdn-cgi/rum?` | Canlı | 200 | text/plain |
| POST | `https://www.google-analytics.com/g/collect?v=2&tid=G-N0FH1HHWCX&gtm=45je6bh1v9229971166za208zd9229971166xf1&_p=1795090483434&gcd=13l3l3l3l1l1&npa=0&dma=0&_eu=AAAAAAQ&cid=1942746850.1795086972&frm=0&ngs=1&pscdl=noapi&rcb=17&sr=407x904&uaa=&uab=&uafvl=&uam=&uamb=1&uap=Android&uapv=&uaw=0&ul=tr-tr&_s=1&tag_exp=115938465~115938469~118897920~118897930~120213116~120385422~120469145~120469153~121246026~121246034~123785233&sid=1795089021&sct=2&seg=1&dl=https%3A%2F%2Ftavsiyefilmizle.net%2F&dt=Hd%20Film%20%C4%B0zle%2C%20T%C3%BCrk%C3%A7e%20Filmler%2C%20G%C3%BCncel%20Filmler%2C%20Full%20Film%20%C4%B0zle&en=page_view&_ee=1&tfd=6516` | Canlı |  |  |
| POST | `https://www.youtube.com/youtubei/v1/log_event?alt=json` | Canlı | 200 | application/json, ×2 |
| — | `http://adserver.advrstcdn.com/getad.php` | Sayfa HTML |  |  |
| — | `http://bongacams.com/track?` | Sayfa HTML |  |  |
| — | `http://join.brokestraightboys.com/track/` | Sayfa HTML |  |  |
| — | `http://www.facebook.com/sharer/sharer.php?u=` | jwplayer.core.controls.js |  |  |
| — | `http://www.installadz.com/indir.php` | Sayfa HTML |  |  |
| — | `http://youtube.com/streaming/metadata/segment/102015` | base.js |  |  |
| — | `http://youtube.com/streaming/otf/durations/112015` | base.js |  |  |
| — | `https://a.acebet.com/api/click?` | Sayfa HTML |  |  |
| — | `https://ads.betfair.com/redirect.aspx?` | Sayfa HTML |  |  |
| — | `https://billing.purevpn.com/aff.php` | Sayfa HTML |  |  |
| — | `https://bongacams10.com/track?` | Sayfa HTML |  |  |
| — | `https://bongacams2.com/track?` | Sayfa HTML |  |  |
| — | `https://cdn.jwplayer.com/v2/media/` | jwplayer.core.controls.js |  |  |
| — | `https://developer.jwplayer.com/jw-player/docs/developer-guide/api/errors-reference#` | jwplayer.js |  |  |
| — | `https://financeads.net/tc.php?` | Sayfa HTML |  |  |
| — | `https://join.bannedsextapes.com/track/` | Sayfa HTML |  |  |
| — | `https://join.playboyplus.com/track/` | Sayfa HTML |  |  |
| — | `https://join.sexworld3d.com/track/` | Sayfa HTML |  |  |
| — | `https://join.virtualtaboo.com/track/` | Sayfa HTML |  |  |
| — | `https://kingredirect.com/redirect/v2/?ads=` | Sayfa HTML |  |  |
| — | `https://kingyonlendir.link/redirect/v2/?ads=` | Sayfa HTML |  |  |
| — | `https://natour.naughtyamerica.com/track/` | Sayfa HTML |  |  |
| — | `https://platform.twitter.com/widgets/hub.html` | widgets.js |  |  |
| — | `https://redux.js.org/api/store#subscribelistener` | base.js |  |  |
| — | `https://stats.g.doubleclick.net/g/collect` | js |  |  |
| — | `https://tavsiyefilmizle.net/comments/feed/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/earn.php?zone` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/feed/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/jump/next.php?r=` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/wp-admin/admin-ajax.php` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/wp-json/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/wp-json/oembed/1.0/embed?url=https%3A%2F%2Ftavsiyefilmizle.net%2Fasla-teslim-olma-izle%2F` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/wp-json/wp/v2/posts/9819` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/wp-login.php` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/xmlrpc.php` | Sayfa HTML |  |  |
| — | `https://torguard.net/aff.php` | Sayfa HTML |  |  |
| — | `https://track.bcvc.mobi/earn.php` | Sayfa HTML |  |  |
| — | `https://vimeo.com/api/v2/video/` | owl.carousel.min.js |  |  |
| — | `https://vzaar.com/api/videos/` | owl.carousel.min.js |  |  |
| — | `https://www.avantlink.com/click.php` | Sayfa HTML |  |  |
| — | `https://www.dating-finder.com/signup/?ai_d=` | Sayfa HTML |  |  |
| — | `https://www.facebook.com/plugins/like.php?href=https://tavsiyefilmizle.net/asla-teslim-olma-izle/&amp` | Sayfa HTML |  |  |
| — | `https://www.facebook.com/sharer.php?u=` | Sayfa HTML |  |  |
| — | `https://www.financeads.net/tc.php?` | Sayfa HTML |  |  |
| — | `https://www.googleapis.com/certificateprovisioning/v1/devicecertificates/create?key=AIzaSyB-5OLKTx2iU5mko18DfdwK5611JIjbUhE` | base.js |  |  |
| — | `https://www.googletagmanager.com/ccm/collect` | js |  |  |
| — | `https://www.googletagmanager.com/ccm/s/collect` | js |  |  |
| — | `https://www.googletagmanager.com/g/collect` | js |  |  |
| — | `https://www.googletagmanager.com/mc/collect` | js |  |  |
| — | `https://www.googletagmanager.com/rmkt/collect` | js |  |  |
| — | `https://www.mrskin.com/account/` | Sayfa HTML |  |  |
| — | `https://www.nutaku.net/signup/landing/` | Sayfa HTML |  |  |
| — | `https://www.youtube.com/api/` | base.js |  |  |
| — | `https://www.youtube.com/api/drm/fps?ek=` | base.js |  |  |
| — | `https://www.youtube.com/youtubei/v1/{param}` | base.js |  |  |
| — | `https://youtube.com/api/drm/fps?ek=uninitialized` | base.js |  |  |
| GET | `https://tavsiyefilmizle.net/.well-known/apple-app-site-association` | Bilinen yol | 200 | text/html |
| — | `https://tavsiyefilmizle.net/author/` | robots.txt |  | Disallow |
| GET | `https://tavsiyefilmizle.net/crossdomain.xml` | Bilinen yol | 200 | application/xml |
| GET | `https://tavsiyefilmizle.net/manifest.json` | Bilinen yol | 200 | application/json, JSON yanıt |
| GET | `https://tavsiyefilmizle.net/robots.txt` | Bilinen yol | 200 | text/plain, 7 kural |
| GET | `https://tavsiyefilmizle.net/sitemap.xml` | Bilinen yol | 200 | text/xml |
| — | `https://tavsiyefilmizle.net/tag/` | robots.txt |  | Disallow |
| — | `https://tavsiyefilmizle.net/wp-content/plugins/` | robots.txt |  | Disallow |
| — | `https://tavsiyefilmizle.net/wp-content/themes/` | robots.txt |  | Disallow |
| — | `https://tavsiyefilmizle.net/wp-includes/` | robots.txt |  | Disallow |
| GET | `https://tavsiyefilmizle.net/wp-json/` | Bilinen yol | 200 | application/json, WordPress REST · 400 uç |
| GET | `https://tavsiyefilmizle.net/wp-json/aioseo/v1` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/ai-agents/generate-app-password` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/ai-agents/install-mcp-adapter` | WordPress |  | aioseo/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/ai-agents/mcp-adapter/release` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/ai/assistant` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/ai/auth` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/ai/credits` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/ai/deactivate` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/ai/faqs` | WordPress |  | aioseo/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/ai/image-generator` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/ai/image-generator` | WordPress |  | aioseo/v1 |
| DELETE | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/ai/image-generator` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/ai/image/alt` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/ai/insights/brand-tracker/subscribe` | WordPress |  | aioseo/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/ai/insights/reports` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/ai/insights/reports` | WordPress |  | aioseo/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/ai/insights/reports/(?P<uuid>[a-zA-Z0-9-]+)` | WordPress |  | aioseo/v1 |
| DELETE | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/ai/insights/reports/(?P<uuid>[a-zA-Z0-9-]+)` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/ai/insights/reports/(?P<uuid>[a-zA-Z0-9-]+)/regenerate` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/ai/key-points` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/ai/meta/description` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/ai/meta/title` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/ai/schema` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/ai/social-posts` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/ai/truseo/optimize-post` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/ai/truseo/spelling` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/ai/truseo/suggest` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/analyze` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/analyze-headline` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/analyze-headline/delete` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/analyze/delete-site` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/backup` | WordPress |  | aioseo/v1 |
| DELETE | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/backup` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/backup/restore` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/clear-log` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/connect` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/connect-pro` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/connect-url` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/crawl-cleanup` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/crawl-cleanup/block` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/crawl-cleanup/delete-blocked` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/crawl-cleanup/delete-unblocked` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/email-debug-info` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/email-summary/send` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/htaccess` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/integration/semrush/authenticate` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/integration/semrush/keyphrases` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/integration/semrush/refresh` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/integration/wpcode/snippets` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/keyphrases` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/notification/blog-visibility-reminder` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/notification/conflicting-plugins-reminder` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/notification/description-format-reminder` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/notification/email-reports-enable` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/notification/install-addons-reminder` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/notification/install-aioseo-image-seo-reminder` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/notification/install-aioseo-local-business-reminder` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/notification/install-aioseo-news-sitemap-reminder` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/notification/install-aioseo-video-sitemap-reminder` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/notification/install-mi-reminder` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/notification/install-om-reminder` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/notification/v3-migration-schema-number-reminder` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/notifications/dismiss` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/objects` | WordPress |  | aioseo/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/options` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/options` | WordPress |  | aioseo/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/ping` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/plugins/deactivate` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/plugins/install` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/plugins/upgrade` | WordPress |  | aioseo/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/post` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/post` | WordPress |  | aioseo/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/post/(?P<postId>[\d]+)/first-attached-image` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/post/(?P<postId>[\d]+)/process-content` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/posts-list/load-details-column` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/posts-list/update-details-column` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/reset-settings` | WordPress |  | aioseo/v1 |
| DELETE | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/search-statistics/auth` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/search-statistics/sitemap/delete` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/search-statistics/sitemap/ignore` | WordPress |  | aioseo/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/search-statistics/url/auth` | WordPress |  | aioseo/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/search-statistics/url/reauth` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/seo-alerts/test-email` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/seo-alerts/test-slack` | WordPress |  | aioseo/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/seo-analysis/competitors` | WordPress |  | aioseo/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/seo-checklist` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/seo-checklist/action` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/seo-checklist/bulk-complete` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/seo-checklist/bulk-uncomplete` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/seo-checklist/complete` | WordPress |  | aioseo/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/seo-checklist/completed` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/seo-checklist/fetch` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/seo-checklist/uncomplete` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/settings/dismiss-alert` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/settings/do-task` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/settings/export` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/settings/export-content` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/settings/hide-setup-wizard` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/settings/hide-upgrade-bar` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/settings/import` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/settings/import-plugins` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/settings/import/(?P<siteId>[\d]+)` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/settings/items-per-page` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/settings/semrush-country` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/settings/toggle-card` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/settings/toggle-radio` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/sitemap/deactivate-conflicting-plugins` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/sitemap/delete-static-files` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/sitemap/validate-html-sitemap-slug` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/spell-checker/download-dictionary` | WordPress |  | aioseo/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/spell-checker/safe-words` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/spell-checker/safe-words/add` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/spell-checker/safe-words/match-case` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/spell-checker/safe-words/remove` | WordPress |  | aioseo/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/tags` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/terms-list/load-details-column` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/terms-list/update-details-column` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/tools/delete-robots-txt` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/tools/import-robots-txt` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/truseo/posts/(?P<postId>[\d]+)` | WordPress |  | aioseo/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/user/(?P<userId>[\d]+)/image` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/wizard` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/writing-assistant/content-analysis` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/writing-assistant/disconnect` | WordPress |  | aioseo/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/writing-assistant/keyword/(?P<postId>[\d]+)` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/writing-assistant/process` | WordPress |  | aioseo/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/writing-assistant/report-history` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/writing-assistant/set-report-progress` | WordPress |  | aioseo/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/writing-assistant/user-info` | WordPress |  | aioseo/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/writing-assistant/user-options` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/aioseo/v1/writing-assistant/user-options` | WordPress |  | aioseo/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/batch/v1` | WordPress |  |  |
| GET | `https://tavsiyefilmizle.net/wp-json/litespeed/v1` | WordPress |  | litespeed/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/litespeed/v1/check_img` | WordPress |  | litespeed/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/litespeed/v1/guest/sync` | WordPress |  | litespeed/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/litespeed/v1/notify_img` | WordPress |  | litespeed/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/litespeed/v1/toggle_crawler_state` | WordPress |  | litespeed/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/litespeed/v1/tool/check_ip` | WordPress |  | litespeed/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/litespeed/v3` | WordPress |  | litespeed/v3 |
| POST | `https://tavsiyefilmizle.net/wp-json/litespeed/v3/cdn_status` | WordPress |  | litespeed/v3 |
| POST | `https://tavsiyefilmizle.net/wp-json/litespeed/v3/err_domains` | WordPress |  | litespeed/v3 |
| POST | `https://tavsiyefilmizle.net/wp-json/litespeed/v3/ip_validate` | WordPress |  | litespeed/v3 |
| POST | `https://tavsiyefilmizle.net/wp-json/litespeed/v3/ping` | WordPress |  | litespeed/v3 |
| POST | `https://tavsiyefilmizle.net/wp-json/litespeed/v3/wp_rest_echo` | WordPress |  | litespeed/v3 |
| GET | `https://tavsiyefilmizle.net/wp-json/oembed/1.0` | WordPress |  | oembed/1.0 |
| GET | `https://tavsiyefilmizle.net/wp-json/oembed/1.0/embed` | WordPress |  | oembed/1.0 |
| GET | `https://tavsiyefilmizle.net/wp-json/oembed/1.0/proxy` | WordPress |  | oembed/1.0 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp-abilities/v1` | WordPress |  | wp-abilities/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp-abilities/v1/abilities` | WordPress |  | wp-abilities/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp-abilities/v1/abilities/(?P<name>[a-zA-Z0-9\-\/]+)` | WordPress |  | wp-abilities/v1 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp-abilities/v1/abilities/(?P<name>[a-zA-Z0-9\-\/]+?)/run` | WordPress |  | wp-abilities/v1 |
| PUT | `https://tavsiyefilmizle.net/wp-json/wp-abilities/v1/abilities/(?P<name>[a-zA-Z0-9\-\/]+?)/run` | WordPress |  | wp-abilities/v1 |
| PATCH | `https://tavsiyefilmizle.net/wp-json/wp-abilities/v1/abilities/(?P<name>[a-zA-Z0-9\-\/]+?)/run` | WordPress |  | wp-abilities/v1 |
| DELETE | `https://tavsiyefilmizle.net/wp-json/wp-abilities/v1/abilities/(?P<name>[a-zA-Z0-9\-\/]+?)/run` | WordPress |  | wp-abilities/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp-abilities/v1/categories` | WordPress |  | wp-abilities/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp-abilities/v1/categories/(?P<slug>[a-z0-9]+(?:-[a-z0-9]+)*)` | WordPress |  | wp-abilities/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp-block-editor/v1` | WordPress |  | wp-block-editor/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp-block-editor/v1/export` | WordPress |  | wp-block-editor/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp-block-editor/v1/navigation-fallback` | WordPress |  | wp-block-editor/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp-block-editor/v1/url-details` | WordPress |  | wp-block-editor/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp-site-health/v1` | WordPress |  | wp-site-health/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp-site-health/v1/directory-sizes` | WordPress |  | wp-site-health/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp-site-health/v1/tests/authorization-header` | WordPress |  | wp-site-health/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp-site-health/v1/tests/background-updates` | WordPress |  | wp-site-health/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp-site-health/v1/tests/dotorg-communication` | WordPress |  | wp-site-health/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp-site-health/v1/tests/https-status` | WordPress |  | wp-site-health/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp-site-health/v1/tests/loopback-requests` | WordPress |  | wp-site-health/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp-site-health/v1/tests/page-cache` | WordPress |  | wp-site-health/v1 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/block-directory/search` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/block-patterns/categories` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/block-patterns/patterns` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/block-renderer/(?P<name>[a-z0-9-]+/[a-z0-9-]+)` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/block-renderer/(?P<name>[a-z0-9-]+/[a-z0-9-]+)` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/block-types` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/block-types/(?P<namespace>[a-zA-Z0-9_-]+)/(?P<name>[a-zA-Z0-9_-]+)` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/blocks` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/blocks` | WordPress |  | wp/v2 |
| PUT | `https://tavsiyefilmizle.net/wp-json/wp/v2/blocks/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| PATCH | `https://tavsiyefilmizle.net/wp-json/wp/v2/blocks/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/blocks/(?P<id>[\d]+)/autosaves` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/blocks/(?P<parent>[\d]+)/autosaves/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| DELETE | `https://tavsiyefilmizle.net/wp-json/wp/v2/blocks/(?P<parent>[\d]+)/revisions/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/categories` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/categories` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/categories/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/categories/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| PUT | `https://tavsiyefilmizle.net/wp-json/wp/v2/categories/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| PATCH | `https://tavsiyefilmizle.net/wp-json/wp/v2/categories/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| DELETE | `https://tavsiyefilmizle.net/wp-json/wp/v2/categories/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/comments` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/comments` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/comments/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/comments/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| PUT | `https://tavsiyefilmizle.net/wp-json/wp/v2/comments/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| PATCH | `https://tavsiyefilmizle.net/wp-json/wp/v2/comments/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| DELETE | `https://tavsiyefilmizle.net/wp-json/wp/v2/comments/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/font-collections` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/font-collections/(?P<slug>[\/\w-]+)` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/font-families` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/font-families` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/font-families/(?P<font_family_id>[\d]+)/font-faces` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/font-families/(?P<font_family_id>[\d]+)/font-faces/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| DELETE | `https://tavsiyefilmizle.net/wp-json/wp/v2/font-families/(?P<font_family_id>[\d]+)/font-faces/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| PUT | `https://tavsiyefilmizle.net/wp-json/wp/v2/font-families/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| PATCH | `https://tavsiyefilmizle.net/wp-json/wp/v2/font-families/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/global-styles/(?P<id>[\/\d+]+)` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/global-styles/(?P<id>[\/\d+]+)` | WordPress |  | wp/v2 |
| PUT | `https://tavsiyefilmizle.net/wp-json/wp/v2/global-styles/(?P<id>[\/\d+]+)` | WordPress |  | wp/v2 |
| PATCH | `https://tavsiyefilmizle.net/wp-json/wp/v2/global-styles/(?P<id>[\/\d+]+)` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/global-styles/themes/(?P<stylesheet>[^\/:<>\*\?"\\|]+(?:\/[^\/:<>\*\?"\\|]+)?)` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/media` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/media` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/media/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| PUT | `https://tavsiyefilmizle.net/wp-json/wp/v2/media/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| PATCH | `https://tavsiyefilmizle.net/wp-json/wp/v2/media/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| DELETE | `https://tavsiyefilmizle.net/wp-json/wp/v2/media/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/media/(?P<id>[\d]+)/edit` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/menu-items` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/menu-items` | WordPress |  | wp/v2 |
| PUT | `https://tavsiyefilmizle.net/wp-json/wp/v2/menu-items/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| PATCH | `https://tavsiyefilmizle.net/wp-json/wp/v2/menu-items/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| DELETE | `https://tavsiyefilmizle.net/wp-json/wp/v2/menu-items/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/menu-items/(?P<id>[\d]+)/autosaves` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/menu-items/(?P<parent>[\d]+)/autosaves/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/menu-locations` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/menu-locations/(?P<location>[\w-]+)` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/menus` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/menus` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/menus/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/menus/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| PUT | `https://tavsiyefilmizle.net/wp-json/wp/v2/menus/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| PATCH | `https://tavsiyefilmizle.net/wp-json/wp/v2/menus/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| DELETE | `https://tavsiyefilmizle.net/wp-json/wp/v2/menus/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/navigation` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/navigation` | WordPress |  | wp/v2 |
| PUT | `https://tavsiyefilmizle.net/wp-json/wp/v2/navigation/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| PATCH | `https://tavsiyefilmizle.net/wp-json/wp/v2/navigation/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/navigation/(?P<id>[\d]+)/autosaves` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/navigation/(?P<parent>[\d]+)/autosaves/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| DELETE | `https://tavsiyefilmizle.net/wp-json/wp/v2/navigation/(?P<parent>[\d]+)/revisions/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/pages` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/pages` | WordPress |  | wp/v2 |
| PUT | `https://tavsiyefilmizle.net/wp-json/wp/v2/pages/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| PATCH | `https://tavsiyefilmizle.net/wp-json/wp/v2/pages/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/pages/(?P<id>[\d]+)/autosaves` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/pages/(?P<parent>[\d]+)/autosaves/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| DELETE | `https://tavsiyefilmizle.net/wp-json/wp/v2/pages/(?P<parent>[\d]+)/revisions/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/pattern-directory/patterns` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/plugins` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/plugins` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/plugins/(?P<plugin>[^.\/]+(?:\/[^.\/]+)?)` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/plugins/(?P<plugin>[^.\/]+(?:\/[^.\/]+)?)` | WordPress |  | wp/v2 |
| PUT | `https://tavsiyefilmizle.net/wp-json/wp/v2/plugins/(?P<plugin>[^.\/]+(?:\/[^.\/]+)?)` | WordPress |  | wp/v2 |
| PATCH | `https://tavsiyefilmizle.net/wp-json/wp/v2/plugins/(?P<plugin>[^.\/]+(?:\/[^.\/]+)?)` | WordPress |  | wp/v2 |
| DELETE | `https://tavsiyefilmizle.net/wp-json/wp/v2/plugins/(?P<plugin>[^.\/]+(?:\/[^.\/]+)?)` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/posts` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/posts` | WordPress |  | wp/v2 |
| PUT | `https://tavsiyefilmizle.net/wp-json/wp/v2/posts/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| PATCH | `https://tavsiyefilmizle.net/wp-json/wp/v2/posts/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/posts/(?P<id>[\d]+)/autosaves` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/posts/(?P<parent>[\d]+)/autosaves/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| DELETE | `https://tavsiyefilmizle.net/wp-json/wp/v2/posts/(?P<parent>[\d]+)/revisions/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/search` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/settings` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/settings` | WordPress |  | wp/v2 |
| PUT | `https://tavsiyefilmizle.net/wp-json/wp/v2/settings` | WordPress |  | wp/v2 |
| PATCH | `https://tavsiyefilmizle.net/wp-json/wp/v2/settings` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/sidebars` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/sidebars/(?P<id>[\w-]+)` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/sidebars/(?P<id>[\w-]+)` | WordPress |  | wp/v2 |
| PUT | `https://tavsiyefilmizle.net/wp-json/wp/v2/sidebars/(?P<id>[\w-]+)` | WordPress |  | wp/v2 |
| PATCH | `https://tavsiyefilmizle.net/wp-json/wp/v2/sidebars/(?P<id>[\w-]+)` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/statuses` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/statuses/(?P<status>[\w-]+)` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/tags` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/tags` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/tags/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/tags/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| PUT | `https://tavsiyefilmizle.net/wp-json/wp/v2/tags/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| PATCH | `https://tavsiyefilmizle.net/wp-json/wp/v2/tags/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| DELETE | `https://tavsiyefilmizle.net/wp-json/wp/v2/tags/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/taxonomies` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/taxonomies/(?P<taxonomy>[\w-]+)` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/template-parts` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/template-parts` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/template-parts/(?P<id>([^\/:<>\*\?"\\|]+(?:\/[^\/:<>\*\?"\\|]+)?)[\/\w%-]+)` | WordPress |  | wp/v2 |
| DELETE | `https://tavsiyefilmizle.net/wp-json/wp/v2/template-parts/(?P<id>([^\/:<>\*\?"\\|]+(?:\/[^\/:<>\*\?"\\|]+)?)[\/\w%-]+)` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/template-parts/(?P<id>([^\/:<>\*\?"\\|]+(?:\/[^\/:<>\*\?"\\|]+)?)[\/\w%-]+)` | WordPress |  | wp/v2 |
| PUT | `https://tavsiyefilmizle.net/wp-json/wp/v2/template-parts/(?P<id>([^\/:<>\*\?"\\|]+(?:\/[^\/:<>\*\?"\\|]+)?)[\/\w%-]+)` | WordPress |  | wp/v2 |
| PATCH | `https://tavsiyefilmizle.net/wp-json/wp/v2/template-parts/(?P<id>([^\/:<>\*\?"\\|]+(?:\/[^\/:<>\*\?"\\|]+)?)[\/\w%-]+)` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/template-parts/lookup` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/templates` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/templates` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/templates/(?P<id>([^\/:<>\*\?"\\|]+(?:\/[^\/:<>\*\?"\\|]+)?)[\/\w%-]+)` | WordPress |  | wp/v2 |
| DELETE | `https://tavsiyefilmizle.net/wp-json/wp/v2/templates/(?P<id>([^\/:<>\*\?"\\|]+(?:\/[^\/:<>\*\?"\\|]+)?)[\/\w%-]+)` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/templates/(?P<id>([^\/:<>\*\?"\\|]+(?:\/[^\/:<>\*\?"\\|]+)?)[\/\w%-]+)` | WordPress |  | wp/v2 |
| PUT | `https://tavsiyefilmizle.net/wp-json/wp/v2/templates/(?P<id>([^\/:<>\*\?"\\|]+(?:\/[^\/:<>\*\?"\\|]+)?)[\/\w%-]+)` | WordPress |  | wp/v2 |
| PATCH | `https://tavsiyefilmizle.net/wp-json/wp/v2/templates/(?P<id>([^\/:<>\*\?"\\|]+(?:\/[^\/:<>\*\?"\\|]+)?)[\/\w%-]+)` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/templates/lookup` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/themes` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/themes/(?P<stylesheet>[^\/:<>\*\?"\\|]+(?:\/[^\/:<>\*\?"\\|]+)?)` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/types` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/types/(?P<type>[\w-]+)` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/users` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/users` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/users/(?P<user_id>(?:[\d]+\|me))/application-passwords/(?P<uuid>[\w\-]+)` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/users/(?P<user_id>(?:[\d]+\|me))/application-passwords/(?P<uuid>[\w\-]+)` | WordPress |  | wp/v2 |
| PUT | `https://tavsiyefilmizle.net/wp-json/wp/v2/users/(?P<user_id>(?:[\d]+\|me))/application-passwords/(?P<uuid>[\w\-]+)` | WordPress |  | wp/v2 |
| PATCH | `https://tavsiyefilmizle.net/wp-json/wp/v2/users/(?P<user_id>(?:[\d]+\|me))/application-passwords/(?P<uuid>[\w\-]+)` | WordPress |  | wp/v2 |
| DELETE | `https://tavsiyefilmizle.net/wp-json/wp/v2/users/(?P<user_id>(?:[\d]+\|me))/application-passwords/(?P<uuid>[\w\-]+)` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/users/me` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/users/me` | WordPress |  | wp/v2 |
| PUT | `https://tavsiyefilmizle.net/wp-json/wp/v2/users/me` | WordPress |  | wp/v2 |
| PATCH | `https://tavsiyefilmizle.net/wp-json/wp/v2/users/me` | WordPress |  | wp/v2 |
| DELETE | `https://tavsiyefilmizle.net/wp-json/wp/v2/users/me` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/widget-types` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/widget-types/(?P<id>[a-zA-Z0-9_-]+)` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/widget-types/(?P<id>[a-zA-Z0-9_-]+)/render` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/widgets` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/widgets` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/widgets/(?P<id>[\w\-]+)` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/widgets/(?P<id>[\w\-]+)` | WordPress |  | wp/v2 |
| PUT | `https://tavsiyefilmizle.net/wp-json/wp/v2/widgets/(?P<id>[\w\-]+)` | WordPress |  | wp/v2 |
| PATCH | `https://tavsiyefilmizle.net/wp-json/wp/v2/widgets/(?P<id>[\w\-]+)` | WordPress |  | wp/v2 |
| DELETE | `https://tavsiyefilmizle.net/wp-json/wp/v2/widgets/(?P<id>[\w\-]+)` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/wp_pattern_category` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/wp_pattern_category` | WordPress |  | wp/v2 |
| GET | `https://tavsiyefilmizle.net/wp-json/wp/v2/wp_pattern_category/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| POST | `https://tavsiyefilmizle.net/wp-json/wp/v2/wp_pattern_category/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| PUT | `https://tavsiyefilmizle.net/wp-json/wp/v2/wp_pattern_category/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| PATCH | `https://tavsiyefilmizle.net/wp-json/wp/v2/wp_pattern_category/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| DELETE | `https://tavsiyefilmizle.net/wp-json/wp/v2/wp_pattern_category/(?P<id>[\d]+)` | WordPress |  | wp/v2 |
| — | `https://tavsiyefilmizle.net/{*}?{*}` | robots.txt |  | Disallow |
| GET | `https://hotstream.club/cry.js` | Canlı | 200 | application/javascript |
| — | `http://adultfriendfinder.com/go/` | Sayfa HTML |  |  |
| — | `http://cam4com.go2cloud.org/aff_c?` | Sayfa HTML |  |  |
| — | `http://gmpg.org/xfn/11` | Sayfa HTML |  |  |
| — | `http://izlenzi.com/campaign/` | Sayfa HTML |  |  |
| — | `http://pinterest.com/pin/create/button/?url=` | jwplayer.core.controls.js |  |  |
| — | `http://tfp.sapphirum.com/ref?` | Sayfa HTML |  |  |
| — | `http://tools.ietf.org/html/rfc1950` | base.js |  |  |
| — | `http://tumblr.com/widgets/share/tool?canonicalUrl=` | jwplayer.core.controls.js |  |  |
| — | `http://twitter.com/intent/tweet?url=` | jwplayer.core.controls.js |  |  |
| — | `http://wavded.github.com/humane-js/` | humane.min.js |  |  |
| — | `http://www.adultempire.com/unlimited/promo?` | Sayfa HTML |  |  |
| — | `http://www.friendlyduck.com/AF_` | Sayfa HTML |  |  |
| — | `http://www.reddit.com/submit?url=` | jwplayer.core.controls.js |  |  |
| — | `http://www.youtube.com/videoplayback` | base.js |  |  |
| — | `http://youtube.com/drm/2012/10/10` | base.js |  |  |
| — | `http://youtube.com/yt/2012/10/10` | base.js |  |  |
| — | `https://aads.com/campaigns/` | Sayfa HTML |  |  |
| — | `https://ab.advertiserurl.com/aff/` | Sayfa HTML |  |  |
| — | `https://accounts.google.com/AddSession` | base.js |  |  |
| — | `https://accounts.google.com/ServiceLogin` | base.js |  |  |
| — | `https://ad.doubleclick.net/activity` | js |  |  |
| — | `https://ad.zanox.com/ppc/` | Sayfa HTML |  |  |
| — | `https://adservice.google.com/pagead/regclk` | js |  |  |
| — | `https://adultfriendfinder.com/go/` | Sayfa HTML |  |  |
| — | `https://antiagingbed.com/discount/` | Sayfa HTML |  |  |
| — | `https://ap.octopuspop.com/click/` | Sayfa HTML |  |  |
| — | `https://camfapr.com/landing/click/` | Sayfa HTML |  |  |
| — | `https://cdn.jwplayer.com/players/` | jwplayer.core.controls.js |  |  |
| — | `https://chaturbate.com/in/?` | Sayfa HTML |  |  |
| — | `https://click.linksynergy.com/fs-bin/` | Sayfa HTML |  |  |
| — | `https://cloudflareinsights.com/cdn-cgi/rum` | vce701823e78c4301a35b7e07294d87301792088 |  |  |
| — | `https://db187550c7dkf.cloudfront.net/dist/` | provider.hlsjs.js |  |  |
| — | `https://docs.google.com/get_video_info` | base.js |  |  |
| — | `https://fastestvpn.com/lifetime-special-deal?a_aid=` | Sayfa HTML |  |  |
| — | `https://fc.lc/ref/` | Sayfa HTML |  |  |
| — | `https://get.surfshark.net/aff_c?` | Sayfa HTML |  |  |
| — | `https://go.markets.com/visit/?bta=` | Sayfa HTML |  |  |
| — | `https://go.nordvpn.net/aff` | Sayfa HTML |  |  |
| — | `https://google-liveplayer.appspot.com/get_video_info` | base.js |  |  |
| — | `https://hotstream.club/embed/TmBWhH8Fh9GfoUk` | Sayfa HTML |  |  |
| — | `https://ilovemyfreedoms.com/landing-` | Sayfa HTML |  |  |
| — | `https://img.youtube.com/vi/` | owl.carousel.min.js |  |  |
| — | `https://jdrucker.com/gold` | Sayfa HTML |  |  |
| — | `https://jjgirls.com/sex/Chaturbate` | Sayfa HTML |  |  |
| — | `https://jwplayer.com/learn-more?e=` | jwplayer.core.controls.js |  |  |
| — | `https://mediaserver.entainpartners.com/renderBanner.do?` | Sayfa HTML |  |  |
| — | `https://mylead.global/stl/` | Sayfa HTML |  |  |
| — | `https://ogp.me/ns#` | Sayfa HTML |  |  |
| — | `https://paid.outbrain.com/network/redir?` | Sayfa HTML |  |  |
| — | `https://platform.twitter.com/jot.html` | widgets.js |  |  |
| — | `https://platform.twitter.com/widgets/follow_button.1227a5674072e080ffb1ba14ac0c1079.{{lang}}.html` | widgets.js |  |  |
| — | `https://platform.twitter.com/widgets/tweet_button.1227a5674072e080ffb1ba14ac0c1079.tr.html#dnt=false&amp` | Sayfa HTML |  |  |
| — | `https://platform.twitter.com/widgets/tweet_button.1227a5674072e080ffb1ba14ac0c1079.{{lang}}.html` | widgets.js |  |  |
| — | `https://platform.twitter.com/widgets/widget_iframe.1227a5674072e080ffb1ba14ac0c1079.html?origin=https%3A%2F%2Ftavsiyefilmizle.net` | Sayfa HTML |  |  |
| — | `https://play.google.com/books/volumes/{param}/content/media` | base.js |  |  |
| — | `https://play.google.com/log?format=json&hasfast=true` | base.js |  |  |
| — | `https://player.vimeo.com/video/` | owl.carousel.min.js |  |  |
| — | `https://playnano.online/offerwalls/?ref=` | Sayfa HTML |  |  |
| — | `https://prf.hn/click/` | Sayfa HTML |  |  |
| — | `https://rapidgator.net/article/premium/ref/` | Sayfa HTML |  |  |
| — | `https://raw.githubusercontent.com/stefanpenner/es6-promise/master/LICENSE` | widgets.js |  |  |
| — | `https://redux.js.org/tutorials/fundamentals/part-4-store#middleware` | base.js |  |  |
| — | `https://redux.js.org/tutorials/fundamentals/part-6-async-logic#using-the-redux-thunk-middleware` | base.js |  |  |
| — | `https://shiftnetwork.infusionsoft.com/go/` | Sayfa HTML |  |  |
| — | `https://startgaming.net/tienda/` | Sayfa HTML |  |  |
| — | `https://static.cloudflareinsights.com/beacon.min.js/vce701823e78c4301a35b7e07294d87301792088814092` | Sayfa HTML |  |  |
| — | `https://static.cloudflareinsights.com/cdn-cgi/rum?{param}` | vce701823e78c4301a35b7e07294d87301792088 |  |  |
| — | `https://static.fleshlight.com/images/banners/` | Sayfa HTML |  |  |
| — | `https://stellarcashflow.net/trck/` | Sayfa HTML |  |  |
| — | `https://streamate.com/landing/click/` | Sayfa HTML |  |  |
| — | `https://support.google.com/youtube/answer/3037019#check_ad_blockers&zippy=%2Ccheck-your-extensions-including-ad-blockers` | base.js |  |  |
| — | `https://support.google.com/youtube?p=videoError` | base.js |  |  |
| — | `https://syndication.twitter.com/i/jot` | widgets.js |  |  |
| — | `https://tavsiyefilmizle.net/%e0%b0%b0%e0%b0%a3%e0%b0%ac%e0%b0%be%e0%b0%b2%e0%b0%bf-izle/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/adref` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/amazonda-dehset-izle/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/apex-2026/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/asla-teslim-olma-izle/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/beast-2026/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/bize-bisey-olmaz-sezon-1/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/camref` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/cinayet-kitabi-izle-s/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/creativeref` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/gardiyan-2-izle/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/kategori/aile/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/kategori/aksiyon/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/kategori/animasyon/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/kategori/belgesel/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/kategori/bilim-kurgu/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/kategori/dizi/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/kategori/dram/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/kategori/fantastik/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/kategori/gerilim/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/kategori/gizem/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/kategori/komedi/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/kategori/korku/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/kategori/macera/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/kategori/muzik/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/kategori/romantik/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/kategori/savas/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/kategori/suc/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/kategori/tarih/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/kategori/tv-film/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/kategori/vahsi-bati/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/kavgacilar-izle/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/odyssey-izle/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/oflu-hoca-6-2026/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/oyuncu/callista-arum/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/oyuncu/derby-romero/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/oyuncu/donny-alamsyah/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/oyuncu/lukman-sardi/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/oyuncu/sulthan-hamonangan/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/player?autoplay=true` | owl.carousel.min.js |  |  |
| — | `https://tavsiyefilmizle.net/ramayana-efsanenin-dogusu-izle-s/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/super-mario-galaxy-filmi/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/the-3-killer-pigs-izle/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/ulke/endonezya/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/uye-ol/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/v-h-s-mixtape-izle/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/wp-admin/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/yil/2026/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/yonetmen/sidharta-tata/` | Sayfa HTML |  |  |
| — | `https://tavsiyefilmizle.net/yuzuklerin-efendisi-guc-yuzukleri-the-rings-of-power-3-sezon-2026-s/` | Sayfa HTML |  |  |
| — | `https://track.fiverr.com/visit/` | Sayfa HTML |  |  |
| — | `https://twittercommunity.com/t/deprecating-widget-settings/102295` | widgets.js |  |  |
| — | `https://twittercommunity.com/t/removing-support-for-embedded-like-collection-and-moment-timelines/150313` | widgets.js |  |  |
| — | `https://twittercommunity.com/t/update-on-the-embedded-grid-display-type/119564` | widgets.js |  |  |
| — | `https://wct.link/click?` | Sayfa HTML |  |  |
| — | `https://www.brazzersnetwork.com/landing/` | Sayfa HTML |  |  |
| — | `https://www.brighteonstore.com/products/` | Sayfa HTML |  |  |
| — | `https://www.cloudways.com/en/?id` | Sayfa HTML |  |  |
| — | `https://www.facebook.com/tr/` | js |  |  |
| — | `https://www.friendlyduck.com/AF_` | Sayfa HTML |  |  |
| — | `https://www.geekbuying.com/dynamic-ads/` | Sayfa HTML |  |  |
| — | `https://www.get-express-vpn.com/offer/` | Sayfa HTML |  |  |
| — | `https://www.goldenfrog.com/vyprvpn?offer_id=` | Sayfa HTML |  |  |
| — | `https://www.google.com/ccm/geo` | js |  |  |
| — | `https://www.google.com/gmp/conversion` | js |  |  |
| — | `https://www.google.com/js/bg/` | fNEcmtENESnIjy2AD1K5nOvWjmOOVLlCMb5QAaKl |  |  |
| — | `https://www.googleadservices.com/pagead/aclk?` | Sayfa HTML |  |  |
| — | `https://www.googletagmanager.com/_/service_worker/` | js |  |  |
| — | `https://www.googletagmanager.com/a` | js |  |  |
| — | `https://www.googletagmanager.com/ag/g/c` | js |  |  |
| — | `https://www.googletagmanager.com/as` | js |  |  |
| — | `https://www.googletagmanager.com/as/d` | js |  |  |
| — | `https://www.googletagmanager.com/as/d/ccm/conversion` | js |  |  |
| — | `https://www.googletagmanager.com/as/p/c` | js |  |  |
| — | `https://www.googletagmanager.com/ccm/conversion` | js |  |  |
| — | `https://www.googletagmanager.com/ccm/form-data` | js |  |  |
| — | `https://www.googletagmanager.com/d` | js |  |  |
| — | `https://www.googletagmanager.com/d/ccm/form-data` | js |  |  |
| — | `https://www.googletagmanager.com/ddm/activity` | js |  |  |
| — | `https://www.googletagmanager.com/debug/bootstrap?id=` | js |  |  |
| — | `https://www.googletagmanager.com/g` | js |  |  |
| — | `https://www.googletagmanager.com/g/d` | js |  |  |
| — | `https://www.googletagmanager.com/g/d/ccm/conversion` | js |  |  |
| — | `https://www.googletagmanager.com/ga/g/c` | js |  |  |
| — | `https://www.googletagmanager.com/gs` | js |  |  |
| — | `https://www.googletagmanager.com/gs/ccm/conversion` | js |  |  |
| — | `https://www.googletagmanager.com/gtag/destination` | js |  |  |
| — | `https://www.googletagmanager.com/gtag/js?id=G-N0FH1HHWCX` | Sayfa HTML |  |  |
| — | `https://www.googletagmanager.com/measurement/conversion` | js |  |  |
| — | `https://www.googletagmanager.com/measurement/enhanced` | js |  |  |
| — | `https://www.googletagmanager.com/pagead/1p-conversion` | js |  |  |
| — | `https://www.googletagmanager.com/pagead/conversion` | js |  |  |
| — | `https://www.googletagmanager.com/pagead/form-data` | js |  |  |
| — | `https://www.googletagmanager.com/pagead/gen_204?id=tcfe` | js |  |  |
| — | `https://www.googletagmanager.com/pagead/set_partitioned_cookie` | js |  |  |
| — | `https://www.googletagmanager.com/pagead/uconversion` | js |  |  |
| — | `https://www.googletagmanager.com/pagead/viewthroughconversion` | js |  |  |
| — | `https://www.googletagmanager.com/static/service_worker/` | js |  |  |
| — | `https://www.googletagmanager.com/sw_iframe.html` | js |  |  |
| — | `https://www.googletagmanager.com/td` | js |  |  |
| — | `https://www.googletagmanager.com/travel/flights/click/conversion` | js |  |  |
| — | `https://www.googletagmanager.com/wp-content` | js |  |  |
| — | `https://www.jwplayer.com/tos/` | jwplayer.js |  |  |
| — | `https://www.linkedin.com/cws/share?url=` | jwplayer.core.controls.js |  |  |
| — | `https://www.mrskin.com/tour` | Sayfa HTML |  |  |
| — | `https://www.youtube.com/UKS.{param}` | base.js |  |  |
| — | `https://www.youtube.com/UNKNOWN_PATH` | base.js |  |  |
| — | `https://www.youtube.com/aclk` | base.js |  |  |
| — | `https://www.youtube.com/client_streamz/bg/cec` | base.js |  |  |
| — | `https://www.youtube.com/client_streamz/bg/ec` | base.js |  |  |
| — | `https://www.youtube.com/client_streamz/bg/el` | base.js |  |  |
| — | `https://www.youtube.com/client_streamz/bg/frs` | base.js |  |  |
| — | `https://www.youtube.com/client_streamz/bg/od/n` | base.js |  |  |
| — | `https://www.youtube.com/client_streamz/bg/od/p` | base.js |  |  |
| — | `https://www.youtube.com/client_streamz/bg/po/csc` | base.js |  |  |
| — | `https://www.youtube.com/client_streamz/bg/po/ctav` | base.js |  |  |
| — | `https://www.youtube.com/client_streamz/bg/po/cwsc` | base.js |  |  |
| — | `https://www.youtube.com/client_streamz/bg/wrl` | base.js |  |  |
| — | `https://www.youtube.com/clip/{param}` | base.js |  |  |
| — | `https://www.youtube.com/embed/` | owl.carousel.min.js |  |  |
| — | `https://www.youtube.com/embed/o0d1IA85D9o` | Sayfa HTML |  |  |
| — | `https://www.youtube.com/embed/{param}` | base.js |  |  |
| — | `https://www.youtube.com/generate_204` | base.js |  |  |
| — | `https://www.youtube.com/getDatasyncIdsEndpoint` | base.js |  |  |
| — | `https://www.youtube.com/google.internal.waa.v1.Waa/Create` | base.js |  |  |
| — | `https://www.youtube.com/google.internal.waa.v1.Waa/GenerateIT` | base.js |  |  |
| — | `https://www.youtube.com/ibw/` | base.js |  |  |
| — | `https://www.youtube.com/iframe_api` | js |  |  |
| — | `https://www.youtube.com/mp4` | base.js |  |  |
| — | `https://www.youtube.com/n/{param}` | base.js |  |  |
| — | `https://www.youtube.com/playable` | base.js |  |  |
| — | `https://www.youtube.com/range/` | base.js |  |  |
| — | `https://www.youtube.com/s/player/` | base.js |  |  |
| — | `https://www.youtube.com/supported_browsers` | base.js |  |  |
| — | `https://www.youtube.com/videogoodput` | base.js |  |  |
| — | `https://www.youtube.com/vtt` | base.js |  |  |
| — | `https://www.youtube.com/watch` | base.js |  |  |
| — | `https://www.youtube.com/webm` | base.js |  |  |
| — | `https://www.youtube.com/x-flv` | base.js |  |  |
| — | `https://www.youtube.com/youtubeoptions` | base.js |  |  |
| — | `https://www.youtube.com/{param}` | base.js |  |  |
| — | `https://x.com/intent/` | widgets.js |  |  |
| — | `https://youtu.be/{param}` | base.js |  |  |
| — | `https://youtubei.googleapis.com/youtubei/{param}/player` | base.js |  |  |

## Örnek istek gövdeleri

**POST https://www.youtube.com/youtubei/v1/log_event?alt=json**

```
{"context":{"client":{"hl":"tr","gl":"TR","clientName":56,"clientVersion":"2.20261118.01.00","configInfo":{"appInstallData":"CK_Y-9cGEMn2gBMQyvuAExCYktMcEMGP0BwQ7fvSHBDeitMcEL22rgUQnOXSHBDcrdIcEI7k0RwQrJbTHBDqjNMcELjkzhwQ2vfOHBCHrM4cENOK0xwQueCAExCfz4ATEMzfrgUQtrWAExDwntMcEN68zhwQr_DSHBDw3tEcEIHNzhwQmY2xBRD2q7AFEM-p0xwQ2MPTHBD82tIcELy30xwQrt7RHBD1ldMcEKa_0xwQpKnRHBDL-9IcEK7WzxwQ6fLSHBDxtNAcEKef0xwQ06TSHBC9irAFEOSVsAUQntCwBRCXr9IcEJmv0hwQvKTQHBD2wNMcENmp0xwQ67DTHBCV2dIcEJzp0hwQ5brTHBC-utMcEJjC0xwQ_J3THBDWn9McEM-o0RwQn4nSHBCSqdMcELiV0xwQsPjRHBCJsM4cEL740hwQpa3THBDOkNMcEPb30RwQ-5TTHBDrzdAcEPuq0xw
```

**POST https://tavsiyefilmizle.net/cdn-cgi/rum?**

```
{"startTime":1795090482722,"pageloadId":"c7c93e35-c096-4438-a1c7-198d9c4afc22","eventType":1,"nt":"navigate","location":"https://tavsiyefilmizle.net/","versions":{"fl":"2024.11.0","js":"2026.10.1","timings":2},"bi":{"be":"Blink","bev":"157","bv":"157"},"memory":{"totalJSHeapSize":10000000,"usedJSHeapSize":10000000,"jsHeapSizeLimit":3760000000},"firstPaint":944,"firstContentfulPaint":944,"timingsV2":{"nextHopProtocol":"h3","domainLookupStart":39,"domainLookupEnd":76,"connectStart":76,"connectEnd":327,"secureConnectionStart":82,"requestStart":328,"responseStart":568,"responseEnd":577,"domInterac
```

# Tavsiyefilmizle — bulunan uçlar

Kalkan Tarayıcı · 19.11.2026 15:17 · https://tavsiyefilmizle.net

| Yöntem | Adres | Kaynak | Durum | Not |
|---|---|---|---|---|
| POST | `https://tavsiyefilmizle.net/cdn-cgi/rum?` | Canlı | 200 | text/plain |
| POST | `https://www.google-analytics.com/g/collect?v=2&tid=G-N0FH1HHWCX&gtm=45je6bh1v9229971166za208zd9229971166xf1&_p=1795090483434&gcd=13l3l3l3l1l1&npa=0&dma=0&_eu=AAAAAAQ&cid=1942746850.1795086972&frm=0&ngs=1&pscdl=noapi&rcb=17&sr=407x904&uaa=&uab=&uafvl=&uam=&uamb=1&uap=Android&uapv=&uaw=0&ul=tr-tr&_s=1&tag_exp=115938465~115938469~118897920~118897930~120213116~120385422~120469145~120469153~121246026~121246034~123785233&sid=1795089021&sct=2&seg=1&dl=https%3A%2F%2Ftavsiyefilmizle.net%2F&dt=Hd%20Film%20%C4%B0zle%2C%20T%C3%BCrk%C3%A7e%20Filmler%2C%20G%C3%BCncel%20Filmler%2C%20Full%20Film%20%C4%B0zle&en=page_view&_ee=1&tfd=6516` | Canlı |  |  |

## Örnek istek gövdeleri

**POST https://tavsiyefilmizle.net/cdn-cgi/rum?**

```
{"startTime":1795090482722,"pageloadId":"c7c93e35-c096-4438-a1c7-198d9c4afc22","eventType":1,"nt":"navigate","location":"https://tavsiyefilmizle.net/","versions":{"fl":"2024.11.0","js":"2026.10.1","timings":2},"bi":{"be":"Blink","bev":"157","bv":"157"},"memory":{"totalJSHeapSize":10000000,"usedJSHeapSize":10000000,"jsHeapSizeLimit":3760000000},"firstPaint":944,"firstContentfulPaint":944,"timingsV2":{"nextHopProtocol":"h3","domainLookupStart":39,"domainLookupEnd":76,"connectStart":76,"connectEnd":327,"secureConnectionStart":82,"requestStart":328,"responseStart":568,"responseEnd":577,"domInterac
```

# Hdfilmdiziizle — bulunan uçlar

Darkness Tarayıcı · 20.11.2026 17:27 · https://www.hdfilmdiziizle.com

| Yöntem | Adres | Kaynak | Durum | Not |
|---|---|---|---|---|
| GET | `https://db187550c7dkf.cloudfront.net/jwplayer-unlimited-8.25.6/translations/tr.json` | Canlı | 200 | application/json |
| POST | `https://www.hdfilmdiziizle.com/wp-admin/admin-ajax.php` | Canlı | 200 | text/html |
| GET | `https://www.hdfilmdiziizle.com/wp-content/plugins/playhd/ufilm-stream.php?token=5Ry6dVB0Ez%2BM98RLQF6HMGW0y7GCerPiwS3Izoioe%2F7QgNG3kMKMFnUfGJkGC%2BhGdF56G6ELdt0VfDKNrfv3Qw%3D%3D&player=H35Gw6h2R8nzRxB9W0U%2BvUjoyUxU%2F%2Bp8orlY8deueESHa0PlbPjdFPVuMp63O2G7&proxy=aHR0cHM6Ly9ob3RzdHJlYW0uY2x1Yi9jcnkuanM` | Canlı | 200 | application/vnd.apple.mpegurl, ×2 |

## Örnek istek gövdeleri

**POST https://www.hdfilmdiziizle.com/wp-admin/admin-ajax.php**

```
action=get_source_url&post_id=35208&source=ufilm_url
```

// ! Bu araç @keyiflerolsun tarafından | @KekikAkademi için yazılmıştır.
package com.darkness.hdfilmdiziizle
class HDStreamAble : PeaceMakerst() {
    override var name    = "HDStreamAble"
    override var mainUrl = "https://hdstreamable.com"
}
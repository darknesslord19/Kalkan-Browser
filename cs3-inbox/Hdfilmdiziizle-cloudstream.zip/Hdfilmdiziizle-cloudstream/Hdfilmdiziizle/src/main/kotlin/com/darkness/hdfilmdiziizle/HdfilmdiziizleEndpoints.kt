package com.darkness.hdfilmdiziizle

/**
 * Darkness Tarayıcı'nın www.hdfilmdiziizle.com üzerinde bulduğu API uçları (20.11.2026 18:09).
 * Aynı sitedeki uçlar mainUrl'e göre göreli yazılmıştır: "$mainUrl" + SABIT
 */
@Suppress("unused")
object HdfilmdiziizleEndpoints {
    /** POST · Canlı */
    const val POST_G_COLLECT = "https://www.google-analytics.com/g/collect?v=2&tid=G-CH2FZMCDMC&gtm=45je6bh1v9244955402za208zd9244955402xf1&_p=1795187279907&gcd=13l3l3l3l1l1&npa=0&dma=0&_eu=AAAAAAQ&cid=1300307754.1795184758&frm=0&ngs=1&pscdl=noapi&rcb=0&sr=407x904&uaa=&uab=&uafvl=&uam=&uamb=1&uap=Android&uapv=&uaw=0&ul=tr-tr&_s=1&tag_exp=115616986~115938466~115938468~120213116~120385423~120469145~120469153~121246026~121246034&sid=1795187279&sct=2&seg=0&dl=https%3A%2F%2Fwww.hdfilmdiziizle.com%2F&dt=HD%20Film%20izle%20%7C%20Yabanc%C4%B1%20Dizi%20izle%20%E2%80%93%20Hdfilmdiziizle&en=page_view&_ss=1&_ee=1&tfd=1468"
    /** POST · Canlı · 200 · text/plain */
    const val POST_CDN_CGI_RUM = "/cdn-cgi/rum?"
    // Örnek gövde: {"startTime":1795187278510,"pageloadId":"de182981-ac5a-4d03-8e48-ab570030963e","eventType":1,"nt":"navigate","location":"https://www.hdfilmdiziizle.com/","versi
}

package com.darkness.hdfilmdiziizle

/**
 * Darkness Tarayıcı'nın www.hdfilmdiziizle.com üzerinde bulduğu API uçları (20.11.2026 17:27).
 * Aynı sitedeki uçlar mainUrl'e göre göreli yazılmıştır: "$mainUrl" + SABIT
 */
@Suppress("unused")
object HdfilmdiziizleEndpoints {
    /** GET · Canlı · 200 · application/json */
    const val JWPLAYER_UNLIMITED_8_25_6_TRANSLATIONS_TR_JSON = "https://db187550c7dkf.cloudfront.net/jwplayer-unlimited-8.25.6/translations/tr.json"
    /** POST · Canlı · 200 · text/html */
    const val POST_WP_ADMIN_ADMIN_AJAX_PHP = "/wp-admin/admin-ajax.php"
    // Örnek gövde: action=get_source_url&post_id=35208&source=ufilm_url
    /** GET · Canlı · 200 · application/vnd.apple.mpegurl */
    const val WP_CONTENT_PLUGINS_PLAYHD_UFILM_STREAM_PHP = "/wp-content/plugins/playhd/ufilm-stream.php?token=5Ry6dVB0Ez%2BM98RLQF6HMGW0y7GCerPiwS3Izoioe%2F7QgNG3kMKMFnUfGJkGC%2BhGdF56G6ELdt0VfDKNrfv3Qw%3D%3D&player=H35Gw6h2R8nzRxB9W0U%2BvUjoyUxU%2F%2Bp8orlY8deueESHa0PlbPjdFPVuMp63O2G7&proxy=aHR0cHM6Ly9ob3RzdHJlYW0uY2x1Yi9jcnkuanM"
}

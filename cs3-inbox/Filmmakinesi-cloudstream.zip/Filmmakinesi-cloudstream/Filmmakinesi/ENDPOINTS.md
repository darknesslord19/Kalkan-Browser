Bu eklenti Kalkan bilgi bankasındaki çalışan referans kaynaktan üretildi (filmmakinesi.to).

package com.darkness.hdfilmdiziizlepc

import android.content.Context
import com.lagradost.cloudstream3.plugins.CloudstreamPlugin
import com.lagradost.cloudstream3.plugins.Plugin

@CloudstreamPlugin
class HdfilmdiziizlePcPlugin : Plugin() {
    override fun load(context: Context) {
        registerMainAPI(HdfilmdiziizlePc())
    }
}

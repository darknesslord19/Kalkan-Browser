version = 1

cloudstream {
    authors     = listOf("Darkness")
    language    = "tr"
    description = "Hdfilmdiziizle PC - Film / Dizi (hdfilmdiziizle.com)"

    status  = 1
    tvTypes = listOf("Movie", "TvSeries")

    iconUrl = "https://www.google.com/s2/favicons?domain=hdfilmdiziizle.com&sz=%size%"
}

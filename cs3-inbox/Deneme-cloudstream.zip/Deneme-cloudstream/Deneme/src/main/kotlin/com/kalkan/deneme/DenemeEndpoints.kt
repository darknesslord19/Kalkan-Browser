package com.kalkan.deneme

object DenemeEndpoints {
    const val SEARCH = "/?s="
}

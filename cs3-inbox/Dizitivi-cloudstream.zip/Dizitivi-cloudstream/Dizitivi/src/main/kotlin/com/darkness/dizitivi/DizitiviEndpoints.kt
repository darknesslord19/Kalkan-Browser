package com.darkness.dizitivi

/**
 * Darkness Tarayıcı'nın dizitivi.org üzerinde bulduğu API uçları (20.11.2026 02:22).
 * Aynı sitedeki uçlar mainUrl'e göre göreli yazılmıştır: "$mainUrl" + SABIT
 */
@Suppress("unused")
object DizitiviEndpoints {
    // Henüz uç bulunamadı. Araçlar → API uçları ile sayfada gezinip tekrar dışa aktar.
}

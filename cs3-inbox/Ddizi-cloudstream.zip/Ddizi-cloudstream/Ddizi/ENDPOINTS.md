Bu eklenti Darkness bilgi bankasındaki çalışan referans kaynaktan üretildi (www.ddizi.tel).

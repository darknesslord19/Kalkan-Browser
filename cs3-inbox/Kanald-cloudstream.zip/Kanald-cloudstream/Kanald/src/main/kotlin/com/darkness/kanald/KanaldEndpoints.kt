package com.darkness.kanald

/**
 * Darkness Tarayıcı'nın www.kanald.com.tr üzerinde bulduğu API uçları (20.11.2026 03:48).
 * Aynı sitedeki uçlar mainUrl'e göre göreli yazılmıştır: "$mainUrl" + SABIT
 */
@Suppress("unused")
object KanaldEndpoints {
    /** HEAD · Canlı · 200 · text/html */
    const val HEAD_WWW_KANALD_COM_TR = "/"
}

# Kanald — bulunan uçlar

Darkness Tarayıcı · 20.11.2026 03:48 · https://www.kanald.com.tr

| Yöntem | Adres | Kaynak | Durum | Not |
|---|---|---|---|---|
| HEAD | `https://www.kanald.com.tr/` | Canlı | 200 | text/html, ×2 |
| GET | `https://static.kanald.com.tr/epg/today.json.gz` | Canlı | 200 | application/json, ×2 |
